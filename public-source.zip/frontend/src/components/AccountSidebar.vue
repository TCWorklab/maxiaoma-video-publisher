<template>
  <aside class="account-sidebar">
    <div class="sidebar-header">
      <span class="sidebar-title">账号管理</span>
      <span class="sidebar-count">{{ totalCount }}</span>
    </div>

    <div class="group-list">
      <!-- 空态:edit 模式下没有已选账号时,显示提示 -->
      <div v-if="mode === 'edit' && visibleAccountGroups.length === 0" class="empty-hint">
        <p>暂无选中账号</p>
        <p class="empty-sub">点击下方「账号设置」开始</p>
      </div>

      <div
        v-for="group in visibleAccountGroups"
        :key="group.key"
        :class="['group-wrap', { 'is-selected': selectedPlatform === group.key }]"
      >
        <div class="group-header cursor-pointer" @click="$emit('toggle-group', group.key)">
          <el-icon
            class="expand-icon"
            :class="{ 'is-expanded': expandedGroups.has(group.key) }"
            :style="{ color: selectedPlatform === group.key ? group.color : '' }"
          >
            <component :is="ArrowRight" />
          </el-icon>
          <span class="platform-badge">
            <img v-if="group.logo" :src="group.logo" :alt="group.name" class="platform-badge-img">
            <template v-else>{{ group.letter }}</template>
          </span>
          <span class="group-name">{{ group.name }}</span>
          <span class="group-count">{{ mode === 'readonly' ? group.accounts.length : group.accounts.filter(a => publishAccountIds.has(a.id)).length }}</span>
        </div>

        <transition
          name="slide"
          @enter="onSlideEnter"
          @leave="onSlideLeave"
        >
          <div v-show="expandedGroups.has(group.key)" class="group-accounts">
            <div
              v-for="account in group.accounts.filter(a => mode === 'readonly' ? true : publishAccountIds.has(a.id))"
              :key="account.id"
              :class="['account-item cursor-pointer', {
                active: selectedAccountId === account.id,
                'has-override': hasAccountOverride(account.id)
              }]"
              @click="$emit('select-account', account, group)"
            >
              <div class="account-avatar" :style="{ borderColor: group.color }">
                <img v-if="account.avatar" :src="proxyAvatar(account.avatar)" :alt="account.name">
                <img v-else :src="getDefaultAvatar(account.name)" :alt="account.name">
              </div>
              <span class="account-name">{{ account.name }}</span>
              <span :class="['dot', account.status === '正常' ? 'on' : 'off']"></span>
              <el-icon v-if="hasAccountOverride(account.id) && mode === 'edit'" class="override-icon" title="已自定义配置"><StarFilled /></el-icon>
              <el-icon v-if="mode === 'edit'" class="account-remove" @click.stop="$emit('remove-account', account.id)"><Close /></el-icon>
            </div>
            <div v-if="(mode === 'readonly' ? group.accounts : group.accounts.filter(a => publishAccountIds.has(a.id))).length === 0" class="no-accounts">暂无账号</div>
          </div>
        </transition>
      </div>
    </div>

    <div v-if="mode === 'edit'" class="sidebar-footer">
      <div class="add-btn cursor-pointer" @click="$emit('open-account-dialog')">+ 账号设置</div>
    </div>
  </aside>
</template>

<script setup>
import { computed } from 'vue'
import { ArrowRight, StarFilled, Close } from '@element-plus/icons-vue'
import { useAppStore } from '@/stores/app'
import { getDefaultAvatar, proxyAvatar } from '@/utils/avatar'

const appStore = useAppStore()

const props = defineProps({
  mode: {
    type: String,
    default: 'edit',
    validator: v => ['edit', 'readonly'].includes(v),
  },
  accountGroups: { type: Array, required: true },
  totalCount: { type: Number, required: true },
  selectedPlatform: { type: String, default: null },
  selectedAccountId: { type: [Number, String], default: null },
  expandedGroups: { type: Set, required: true },
  publishAccountIds: { type: Set, required: true },
  hasAccountOverride: { type: Function, required: true },
})

defineEmits(['toggle-group', 'select-account', 'remove-account', 'open-account-dialog'])

// 过滤逻辑:
// 1. 永远过滤掉被渠道黑名单禁用的平台分组
// 2. edit 模式下,只显示「该平台下有 publishAccountIds 中已选账号」的分组(默认空,选了账号才出现)
// 3. readonly 模式下,显示所有非黑名单平台分组(用于历史详情查看等场景)
// group.key 已经是平台 key(如 'xiaohongshu'),无需再走 platformNameToKey
const visibleAccountGroups = computed(() =>
  props.accountGroups.filter(group => {
    if (!group.key || appStore.isPlatformDisabled(group.key)) return false
    if (props.mode === 'edit') {
      // edit 模式:必须有已选账号才显示分组
      return group.accounts.some(a => props.publishAccountIds.has(a.id))
    }
    return true
  })
)

// 展开/收起过渡:动态设置 max-height,避免硬编码上限导致内容被裁剪
function onSlideEnter(el) {
  el.style.maxHeight = el.scrollHeight + 'px'
}
function onSlideLeave(el) {
  el.style.maxHeight = el.scrollHeight + 'px'
  // 强制重排后再改为 0,确保 leave 动画能播放
  void el.offsetHeight
  el.style.maxHeight = '0px'
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables.scss' as *;

.account-sidebar {
  width: 232px;
  flex-shrink: 0;
  background: linear-gradient(180deg, $bg-elevated 0%, $bg-base 100%);
  border-right: 1px solid rgba($overlay-rgb, 0.06);
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 16px 16px;

    .sidebar-title {
      font-size: 16px;
      font-weight: 700;
      color: #e2e8f0;
    }

    .sidebar-count {
      font-size: 11px;
      color: #a78bfa;
      background: rgba($brand-start, 0.12);
      padding: 3px 10px;
      border-radius: 12px;
      font-weight: 700;
    }
  }

  .group-list {
    flex: 1;
    overflow-y: auto;
    padding: 4px 0;

    &::-webkit-scrollbar { width: 3px; }
    &::-webkit-scrollbar-thumb { background: rgba($brand-start, 0.15); border-radius: 2px; }
  }

  .group-wrap {
    margin: 2px 10px;
    border-radius: 10px;
    transition: all 0.2s ease;
    border: 1px solid transparent;

    &.is-selected {
      background: rgba($brand-start, 0.1);
      border-color: rgba($brand-start, 0.2);
      margin: 2px 9px;
    }
  }

  .group-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 11px 12px;
    border-radius: 10px;
    transition: all 0.2s ease;
    user-select: none;

    &:hover { background: rgba($overlay-rgb, 0.03); }

    .expand-icon {
      font-size: 12px;
      color: $text-muted;
      // 旋转动画:展开时 90°,收起时 0°,与下方 .group-accounts 的 slide 过渡协调
      transform: rotate(0deg);
      transition: transform 240ms cubic-bezier(0.4, 0, 0.2, 1), color 0.2s ease;

      &.is-expanded {
        transform: rotate(90deg);
      }
    }

    .platform-badge {
      width: 34px;
      height: 34px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 14px;
      font-weight: 700;
      flex-shrink: 0;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);

      .platform-badge-img {
        width: 24px;
        height: 24px;
        object-fit: contain;
      }
    }

    .group-name {
      flex: 1;
      font-size: 15px;
      color: $text-secondary;
      font-weight: 600;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .group-count {
      font-size: 11px;
      color: #a78bfa;
      background: rgba($brand-start, 0.1);
      padding: 2px 8px;
      border-radius: 8px;
      font-weight: 600;
    }
  }

  .group-accounts {
    padding: 0 12px 8px 48px;

    .no-accounts {
      font-size: 12px;
      color: $text-muted;
      padding: 6px 0;
    }
  }

  .group-list > .empty-hint {
    padding: 48px 16px;
    text-align: center;
    color: $text-muted;
    font-size: 13px;

    p {
      margin: 0 0 6px;
    }

    .empty-sub {
      font-size: 11px;
      opacity: 0.7;
    }
  }

  .slide-enter-active, .slide-leave-active {
    // max-height 由 JS 钩子动态设置,这里只负责 transition 曲线和 padding 过渡
    transition: max-height 260ms cubic-bezier(0.4, 0, 0.2, 1),
                opacity 200ms ease,
                padding 200ms ease;
    overflow: hidden;
  }
  .slide-enter-from, .slide-leave-to {
    opacity: 0;
    max-height: 0;
    padding-top: 0;
    padding-bottom: 0;
  }
  .slide-enter-to, .slide-leave-from {
    opacity: 1;
    // max-height 由 onSlideEnter/onSlideLeave 动态写入实际 scrollHeight
    padding-top: 0;
    padding-bottom: 8px;
  }

  .account-item {
    display: flex;
    align-items: center;
    gap: 8px;
    // padding-left: 5px 抵消选中态左侧 3px 紫色色条,避免文字位置跳动
    padding: 7px 8px 7px 5px;
    border-radius: 8px;
    transition: all 0.2s ease;
    border: 1px solid transparent;

    &:hover {
      background: rgba($overlay-rgb, 0.04);
      border-color: rgba($overlay-rgb, 0.04);
    }

    &.active {
      // 选中态:加深紫色背景 + 紫色边框 + 左侧 3px 紫色色条,多重视觉锚点更醒目
      background: rgba($brand-start, 0.22);
      border-color: rgba($brand-start, 0.45);
      box-shadow: inset 3px 0 0 0 $brand-start, 0 1px 4px rgba($brand-start, 0.15);

      // 文字加深+加粗, 亮色模式从 text-secondary(#64748b) 提到 brand-start
      // 在浅紫底上对比度足够, 不会再"发白"; 暗色模式仍清晰
      .account-name {
        color: $brand-start;
        font-weight: 600;
      }

      // avatar 加紫色描边,呼应选中态
      .account-avatar {
        border-color: $brand-start;
      }

      // 状态点也点亮
      .dot.on { box-shadow: 0 0 8px rgba($success-color, 0.7); }
    }

    .account-avatar {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba($brand-start, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      color: #c4b5fd;
      font-weight: 700;
      flex-shrink: 0;
      border: 2px solid transparent;
      transition: all 0.2s ease;
      overflow: hidden;

      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }

    .account-name {
      flex: 1;
      font-size: 12px;
      color: $text-secondary;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-weight: 500;
    }

    .dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      flex-shrink: 0;

      &.on { background: $success-color; box-shadow: 0 0 6px rgba($success-color, 0.5); }
      &.off { background: $danger-color; box-shadow: 0 0 6px rgba($danger-color, 0.5); }
    }

    .account-remove {
      font-size: 16px;
      color: $text-muted;
      opacity: 0;
      transition: all 0.15s ease;
      flex-shrink: 0;
      margin-left: 4px;
      cursor: pointer;

      &:hover { color: $danger-color; opacity: 1 !important; }
    }

    &:hover .account-remove { opacity: 0.5; }

    &.has-override {
      background: rgba($warning-color, 0.06);
      border-color: rgba($warning-color, 0.1);
      .account-name { font-weight: 600; }
    }

    .override-icon {
      font-size: 12px;
      color: #f59e0b;
      flex-shrink: 0;
    }
  }

  .sidebar-footer {
    padding: 12px 10px;
    border-top: 1px solid rgba($overlay-rgb, 0.04);

    .add-btn {
      border: 1.5px dashed rgba($brand-start, 0.25);
      border-radius: 10px;
      padding: 10px;
      text-align: center;
      font-size: 13px;
      font-weight: 600;
      color: #a78bfa;
      transition: all 0.2s ease;

      &:hover {
        border-color: rgba($brand-start, 0.5);
        color: #c4b5fd;
        background: rgba($brand-start, 0.08);
      }
    }
  }
}

.cursor-pointer { cursor: pointer; }
</style>

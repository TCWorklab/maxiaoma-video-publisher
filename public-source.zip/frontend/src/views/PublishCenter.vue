<template>
  <div class="publish-center">
    <!-- ========== LEFT SIDEBAR ========== -->
    <AccountSidebar
      :mode="'edit'"
      :account-groups="accountGroups"
      :total-count="totalCount"
      :selected-platform="selectedPlatform"
      :selected-account-id="selectedAccountId"
      :expanded-groups="expandedGroups"
      :publish-account-ids="publishAccountIds"
      :has-account-override="hasAccountOverride"
      @toggle-group="toggleGroup"
      @select-account="selectAccount"
      @remove-account="removePublishAccount"
      @open-account-dialog="accountDialogVisible = true"
    />

    <!-- ========== RIGHT MAIN AREA ========== -->
    <main class="publish-main">
      <div class="main-body">
      <!-- Left: form + content -->
      <div class="main-form-col">
      <!-- Top bar -->
      <div class="main-header">
        <div class="header-left">
          <span class="page-title">发布视频</span>
          <span
            v-if="currentPlatformConfig"
            class="platform-tag"
            :style="{ background: currentPlatformConfig.bgColor, color: currentPlatformConfig.color }"
          >
            {{ currentPlatformConfig.name }} · 个性化设置
          </span>
        </div>
        <div class="header-right">
          <el-button :icon="Document" @click="saveDraft" class="header-btn">
            {{ currentDraftId ? '更新草稿' : '保存草稿' }}
          </el-button>
          <el-button :icon="MagicStick" @click="oneClickDialogOpen = true" class="header-btn">
            一键填写
          </el-button>
          <el-button :icon="Setting" @click="batchSetDialogOpen = true" :disabled="publishAccountIds.size === 0" class="header-btn">
            批量设置
          </el-button>
          <el-button type="primary" :icon="Promotion" @click="startBatchPublish" :disabled="batchSubmitting" class="header-btn header-btn--primary">
            {{ batchSubmitting ? '提交中...' : '批量发布' }}
          </el-button>
        </div>
      </div>

      <!-- ===== 视频队列栏（批量发布）===== -->
      <VideoQueueBar
        :videos="videoQueueItems"
        :current="currentVideoIndex"
        @select="switchVideo"
        @add="openAddVideosDialog"
        @remove="removeVideoAt"
      />

      <!-- Scrollable content -->
      <div class="main-content">
        <!-- ===== PUBLIC CONFIG ===== -->
        <div class="config-section">
          <div class="section-bar">
            <div class="bar purple"></div>
            <span class="section-label">公共配置</span>
            <span class="hint">所有账号共享</span>
            <template v-if="currentPlatformConfig && publishAccountIds.size > 0">
              <el-checkbox
                v-model="platformChecked[selectedPlatform]"
                @change="onPlatformCheckChange"
              >
                {{ currentPlatformConfig.name }} 渠道个性化
              </el-checkbox>
              <el-checkbox
                v-if="selectedAccountId"
                v-model="accountChecked[selectedAccountId]"
                :disabled="!platformChecked[selectedPlatform]"
                @change="onAccountCheckChange"
              >
                {{ getAccountName(selectedAccountId) }} 账号个性化
              </el-checkbox>
            </template>
          </div>

          <!-- Cover Section -->
          <div class="media-section cover-section">
            <div class="section-label">封面</div>
            <div class="cover-grid">
              <CoverCard
                label="竖版封面"
                :ratios="['3:4', '9:16']"
                v-model:active-ratio="coverPortraitActiveRatio"
                :model-value="coverPortraitActiveCover"
                :has-video="!!(currentEditTarget.videoPortrait || currentEditTarget.videoLandscape)"
                :cropping="isCoverCropping"
                :crop-stage="coverCropStage"
                @update:modelValue="onPortraitCoverChange"
                @edit="openCoverEditor('portrait', coverPortraitActiveRatio)"
                @open-library="selectFromLibrary('cover', 'portrait')"
              />
              <CoverCard
                label="横版封面"
                :ratios="['4:3', '16:9']"
                v-model:active-ratio="coverLandscapeActiveRatio"
                :model-value="coverLandscapeActiveCover"
                :has-video="!!(currentEditTarget.videoPortrait || currentEditTarget.videoLandscape)"
                :cropping="isCoverCropping"
                :crop-stage="coverCropStage"
                @update:modelValue="onLandscapeCoverChange"
                @edit="openCoverEditor('landscape', coverLandscapeActiveRatio)"
                @open-library="selectFromLibrary('cover', 'landscape')"
              />
            </div>
          </div>

          <CoverEditorDialog
            ref="coverEditorRef"
            :orientation="coverEditOrientation"
            :video-landscape="editorSource.videoLandscape"
            :video-portrait="editorSource.videoPortrait"
            :cover-primary="editorSource.coverPrimary"
            :cover-secondary="editorSource.coverSecondary"
            @cover-saved="onCoverSaved"
          />
        </div>

        <!-- Divider -->
        <div class="divider"></div>

        <!-- ===== PLATFORM-SPECIFIC SETTINGS ===== -->
        <div v-if="currentPlatformConfig && publishAccountIds.size > 0" class="config-section">
          <div class="section-bar">
            <div class="bar" :style="{ background: currentPlatformConfig.color }"></div>
            <span class="section-label">
              {{ currentPlatformConfig.name }}
              {{ selectedAccountId ? '· ' + getAccountName(selectedAccountId) : '· 默认设置' }}
            </span>
            <span class="hint">{{ selectedAccountId ? '仅对该账号生效' : '对该分组所有未自定义的账号生效' }}</span>
          </div>

          <div v-if="selectedAccountId && hasAccountOverride(selectedAccountId)" style="margin-bottom: 12px;">
            <el-button size="small" @click="resetAccountOverride(selectedAccountId)">恢复为渠道默认</el-button>
          </div>

          <div v-if="selectedPlatform === 'xiaohongshu'" class="xhs-warning">
            <el-icon><WarningFilled /></el-icon>
            <span>由于小红书反检测机制比较恶心，如果出现被警告的情况！请立即停止使用小红书渠道！</span>
          </div>

          <div class="platform-title-desc">
            <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
              <div class="setting-label" :style="{ color: currentPlatformConfig.color }">标题</div>
              <el-input
                v-model="form.title"
                :placeholder="currentPlatformConfig.key === 'jingmai' ? '添加一个亮眼的标题吧，5~27个字' : currentPlatformConfig.key === 'dayu' ? '请输入标题（5~60个字）' : '请输入标题...'"
                :maxlength="currentPlatformConfig.key === 'jingmai' ? 27 : currentPlatformConfig.key === 'dayu' ? 60 : 100"
                show-word-limit
              />
            </div>
            <div
              v-if="!currentPlatformConfig.hideFields || !currentPlatformConfig.hideFields.includes('description')"
              class="setting-card"
              :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }"
            >
              <div class="setting-label" :style="{ color: currentPlatformConfig.color }">描述</div>
              <el-input
                v-model="form.description"
                type="textarea"
                :rows="5"
                placeholder="请输入描述..."
                :maxlength="currentPlatformConfig.key === 'dayu' ? 200 : 2000"
                show-word-limit
              />
            </div>
          </div>

          <!-- 通用标签输入 -->
          <div
            v-if="!currentPlatformConfig.hideFields || !currentPlatformConfig.hideFields.includes('tags')"
            class="setting-card"
            :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }"
          >
            <div class="setting-label" :style="{ color: currentPlatformConfig.color }">标签</div>
            <div class="setting-hint">{{ selectedPlatform === 'douyin' ? '官方活动 + 标签最多 5 个，按回车确认' : selectedPlatform === 'kuaishou' ? '输入标签内容，按回车确认（最多 4 个）' : '输入标签内容，按回车确认' }}</div>
              <el-input
                v-model="tagInput"
                placeholder="输入标签内容，按回车添加"
                @keyup.enter="addTag"
                clearable
              />
              <div v-if="form.tags && form.tags.length > 0" class="tags-list">
                <el-tag
                  v-for="(tag, index) in form.tags"
                  :key="index"
                  closable
                  @close="removeTag(index)"
                  size="small"
                  :disable-transitions="false"
                >#{{ tag }}</el-tag>
              </div>
              <!-- B 站专属:是否保留系统生成的标签 -->
              <div v-if="selectedPlatform === 'bilibili'" class="tag-option-row">
                <el-switch v-model="form.biliKeepSystemTags" size="small" />
                <span class="tag-option-label">保留系统生成标签</span>
                <span class="tag-option-hint">关闭后,发布会先清空 B 站自动生成的标签,再填入上面自己的标签</span>
              </div>
          </div>

          <!-- 淘宝光合:关联商品/店铺(独占一整行,放在标签下面) -->
          <div
            v-if="selectedPlatform === 'taobao_guanghe'"
            class="setting-card"
            :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }"
          >
            <div class="setting-label" :style="{ color: currentPlatformConfig.color }">关联商品/店铺</div>
            <div class="guanghe-link-field">
              <div class="radio-row">
                <label class="radio-item cursor-pointer">
                  <input
                    type="radio"
                    :name="(selectedAccountId || selectedPlatform) + '-guangheLinkType'"
                    value="product"
                    v-model="form.guangheLinkType"
                    class="cursor-pointer"
                  />
                  <span
                    :class="['radio-text', { on: form.guangheLinkType === 'product' }]"
                    :style="form.guangheLinkType === 'product' ? { borderColor: currentPlatformConfig.color, color: currentPlatformConfig.color } : {}"
                  >商品</span>
                </label>
                <label class="radio-item cursor-pointer">
                  <input
                    type="radio"
                    :name="(selectedAccountId || selectedPlatform) + '-guangheLinkType'"
                    value="shop"
                    v-model="form.guangheLinkType"
                    class="cursor-pointer"
                  />
                  <span
                    :class="['radio-text', { on: form.guangheLinkType === 'shop' }]"
                    :style="form.guangheLinkType === 'shop' ? { borderColor: currentPlatformConfig.color, color: currentPlatformConfig.color } : {}"
                  >店铺</span>
                </label>
              </div>

              <div class="guanghe-items-field">
                <div class="guanghe-selected-list">
                  <div
                    v-for="(item, i) in currentGuangheItems"
                    :key="i + '_' + (item.title || item)"
                    class="guanghe-selected-card"
                  >
                    <div class="img-wrap">
                      <img
                        v-if="item.image"
                        :src="item.image"
                        referrerpolicy="no-referrer"
                      />
                      <div v-else class="placeholder">
                        {{ (item.title || item || '?').toString().slice(0, 1) }}
                      </div>
                    </div>
                    <div class="info">
                      <div class="title" :title="item.title || item">{{ item.title || item }}</div>
                    </div>
                    <div class="guanghe-selected-remove" @click="removeGuangheItem(currentGuangheFieldKey, i)">
                      <el-icon><Close /></el-icon>
                    </div>
                  </div>
                  <div
                    v-if="currentGuangheItems.length < 6"
                    class="guanghe-add-card"
                    @click="openGuanghePicker()"
                  >
                    <el-icon><Plus /></el-icon>
                    <span>添加{{ form.guangheLinkType === 'shop' ? '店铺' : '商品' }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 京东(京麦):关联挂件(商品/小说,独占一整行,放在标签下面) -->
          <div
            v-if="selectedPlatform === 'jingmai'"
            class="setting-card"
            :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }"
          >
            <div class="setting-label" :style="{ color: currentPlatformConfig.color }">关联挂件</div>
            <div class="guanghe-link-field">
              <div class="radio-row">
                <label class="radio-item cursor-pointer">
                  <input
                    type="radio"
                    :name="(selectedAccountId || selectedPlatform) + '-jdRelatedType'"
                    value=""
                    v-model="form.jdRelatedType"
                    class="cursor-pointer"
                  />
                  <span
                    :class="['radio-text', { on: form.jdRelatedType === '' }]"
                    :style="form.jdRelatedType === '' ? { borderColor: currentPlatformConfig.color, color: currentPlatformConfig.color } : {}"
                  >不关联</span>
                </label>
                <label class="radio-item cursor-pointer">
                  <input
                    type="radio"
                    :name="(selectedAccountId || selectedPlatform) + '-jdRelatedType'"
                    value="product"
                    v-model="form.jdRelatedType"
                    class="cursor-pointer"
                  />
                  <span
                    :class="['radio-text', { on: form.jdRelatedType === 'product' }]"
                    :style="form.jdRelatedType === 'product' ? { borderColor: currentPlatformConfig.color, color: currentPlatformConfig.color } : {}"
                  >商品</span>
                </label>
                <label class="radio-item cursor-pointer">
                  <input
                    type="radio"
                    :name="(selectedAccountId || selectedPlatform) + '-jdRelatedType'"
                    value="novel"
                    v-model="form.jdRelatedType"
                    class="cursor-pointer"
                  />
                  <span
                    :class="['radio-text', { on: form.jdRelatedType === 'novel' }]"
                    :style="form.jdRelatedType === 'novel' ? { borderColor: currentPlatformConfig.color, color: currentPlatformConfig.color } : {}"
                  >小说</span>
                </label>
              </div>

              <!-- 商品选择 -->
              <div v-if="form.jdRelatedType === 'product'" class="guanghe-items-field">
                <div class="guanghe-selected-list">
                  <div
                    v-for="(item, i) in (form.jdProducts || [])"
                    :key="(item.id || item.title || '') + '_' + i"
                    class="guanghe-selected-card"
                  >
                    <div class="img-wrap">
                      <img
                        v-if="item.image"
                        :src="item.image"
                        referrerpolicy="no-referrer"
                      />
                      <div v-else class="placeholder">
                        {{ (item.title || '?').toString().slice(0, 1) }}
                      </div>
                    </div>
                    <div class="info">
                      <div class="title" :title="item.title">{{ item.title }}</div>
                    </div>
                    <div class="guanghe-selected-remove" @click="removeJdProduct(i)">
                      <el-icon><Close /></el-icon>
                    </div>
                  </div>
                  <div
                    v-if="(form.jdProducts || []).length < 10"
                    class="guanghe-add-card"
                    @click="openJdPicker()"
                  >
                    <el-icon><Plus /></el-icon>
                    <span>添加商品 ({{ (form.jdProducts || []).length }}/10)</span>
                  </div>
                </div>
              </div>

              <!-- 小说选择(下拉搜索) -->
              <div v-else-if="form.jdRelatedType === 'novel'" class="jd-novel-select">
                <RemoteSearchSelect
                  v-model="form.jdNovel"
                  :data="form.jdNovelData"
                  :fetcher="fetchJdNovels"
                  :field-map="jdNovelFieldMap"
                  search-mode="backend"
                  placeholder="输入小说名称搜索"
                  search-placeholder="输入关键词,按回车搜索小说"
                  @change="handleJdNovelChange"
                />
              </div>
            </div>
          </div>

          <!-- 平台特有配置（抖音专属卡片 + settingsFields 合并到同一网格） -->
          <div class="settings-grid">
            <!-- 抖音专属卡片 -->
            <template v-if="selectedPlatform === 'douyin'">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">官方活动</div>
                <DouyinActivitySelect :account-id="selectedAccountId" v-model="form.activityId" @change="handleDouyinActivityChange" />
              </div>

              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">关联热点</div>
                <RemoteSearchSelect
                  v-model="form.hotspotId"
                  :data="form.hotspotData"
                  :fetcher="fetchDouyinHotspots"
                  :field-map="douyinHotspotFieldMap"
                  search-mode="backend"
                  placeholder="输入热点词搜索"
                  search-placeholder="输入热点词,按回车搜索"
                  @change="handleDouyinHotspotChange"
                />
              </div>

              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">添加标签</div>
                <DouyinTagSelect :account-id="selectedAccountId" v-model="form.selectedTag" @change="handleDouyinTagSelect" />
              </div>

              <div v-if="selectedAccountId" class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">添加合集</div>
                <RemoteSearchSelect
                  v-model="form.mixId"
                  :data="form.mixData"
                  :fetcher="fetchDouyinMixes"
                  :field-map="{ label: 'mix_name', key: 'mix_id', desc: 'desc', cover: 'cover_url.url_list.0' }"
                  search-mode="frontend"
                  empty-behavior="load-all"
                  placeholder="选择合集"
                  @change="handleDouyinMixChange"
                />
              </div>
            </template>

            <!-- 小红书专属卡片(合集为账号级,选中账号后才显示) -->
            <template v-if="selectedPlatform === 'xiaohongshu' && selectedAccountId">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">加入合集</div>
                <RemoteSearchSelect
                  v-model="form.collectionName"
                  :data="form.collectionData"
                  :fetcher="fetchXhsCollections"
                  :field-map="xhsCollectionFieldMap"
                  search-mode="frontend"
                  empty-behavior="load-all"
                  placeholder="输入合集名称搜索"
                  search-placeholder="输入合集名称,按回车搜索"
                  @change="handleXhsCollectionChange"
                />
              </div>
            </template>

            <!-- B 站专属卡片(合集为账号级,选中账号后才显示) -->
            <template v-if="selectedPlatform === 'bilibili' && selectedAccountId">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">选择合集</div>
                <RemoteSearchSelect
                  v-model="form.biliCollectionName"
                  :data="form.biliCollectionData"
                  :fetcher="fetchBiliCollections"
                  :field-map="{ label: 'name' }"
                  search-mode="frontend"
                  empty-behavior="load-all"
                  placeholder="输入合集名称搜索"
                  search-placeholder="输入合集名称,按回车搜索"
                  @change="handleBiliCollectionChange"
                />
              </div>
            </template>

            <!-- 视频号平台级字段(选中平台就显示,无需先选账号) -->
            <template v-if="selectedPlatform === 'channels'">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">活动</div>
                <RemoteSearchSelect
                  v-model="form.channelsActivityName"
                  :data="form.channelsActivityData"
                  :fetcher="fetchChannelsActivities"
                  :field-map="channelsActivityFieldMap"
                  search-mode="backend"
                  empty-behavior="block"
                  placeholder="输入活动名称搜索"
                  search-placeholder="输入活动关键词,按回车搜索"
                  @change="handleChannelsActivityChange"
                />
              </div>
            </template>

            <!-- 视频号账号级字段(选中账号后才显示) -->
            <template v-if="selectedPlatform === 'channels' && selectedAccountId">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">选择合集</div>
                <RemoteSearchSelect
                  v-model="form.channelsCollectionName"
                  :data="form.channelsCollectionData"
                  :fetcher="fetchChannelsCollections"
                  :field-map="{ label: 'name' }"
                  search-mode="frontend"
                  empty-behavior="load-all"
                  placeholder="输入合集名称搜索"
                  search-placeholder="输入合集名称,按回车搜索"
                  @change="handleChannelsCollectionChange"
                />
              </div>
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">位置</div>
                <RemoteSearchSelect
                  v-model="form.channelsLocationName"
                  :data="form.channelsLocationData"
                  :fetcher="fetchChannelsLocations"
                  :field-map="{ label: 'name', desc: 'desc' }"
                  search-mode="backend"
                  empty-behavior="block"
                  placeholder="输入位置关键词搜索"
                  search-placeholder="输入位置关键词,按回车搜索"
                  @change="handleChannelsLocationChange"
                />
              </div>
              <!-- 链接(账号级,标准下拉 4 选 1)
                   选哪个才显示对应子配置区。
                   视频号发布页 DOM(实测):
                     .post-link-wrap > .link-display-wrap > .link-placeholder(选择链接)
                     点击展开 .link-list-options(4 个 .link-option-item) -->
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">链接</div>
                <el-select
                  v-model="form.channelsLinkType"
                  placeholder="选择链接"
                  clearable
                  style="width: 100%"
                  @change="onChannelsLinkTypeChange"
                >
                  <el-option label="公众号文章" value="article" />
                  <el-option label="红包封面" value="red_envelope" />
                  <el-option label="视频号剧集" value="drama" />
                  <el-option label="小程序短剧" value="mini_drama" />
                </el-select>

                <!-- 子配置:视频号剧集 / 小程序短剧 → 走 picker 弹窗 -->
                <div v-if="form.channelsLinkType === 'drama' || form.channelsLinkType === 'mini_drama'" class="link-sub">
                  <div v-if="form.channelsDrama && form.channelsDrama.length > 0" class="channels-drama-selected">
                    <div class="drama-pill">
                      <img v-if="form.channelsDrama[0].cover" :src="form.channelsDrama[0].cover" class="drama-pill-cover" referrerpolicy="no-referrer" />
                      <div class="drama-pill-text">
                        <div class="drama-pill-title">{{ form.channelsDrama[0].title }}</div>
                        <div v-if="form.channelsDrama[0].extinfo" class="drama-pill-ext">{{ form.channelsDrama[0].extinfo }}</div>
                      </div>
                      <el-button size="small" text type="danger" @click="form.channelsDrama = []">移除</el-button>
                    </div>
                    <el-button size="small" plain @click="openChannelsDramaPicker(form.channelsLinkType)">重新选择</el-button>
                  </div>
                  <el-button v-else size="default" :icon="Plus" plain @click="openChannelsDramaPicker(form.channelsLinkType)">
                    选择{{ form.channelsLinkType === 'mini_drama' ? '小程序短剧' : '视频号剧集' }}
                  </el-button>
                </div>

                <!-- 子配置:公众号文章(占位) -->
                <div v-else-if="form.channelsLinkType === 'article'" class="link-sub">
                  <el-input v-model="form.channelsLinkArticleUrl" placeholder="输入公众号文章链接" clearable />
                </div>

                <!-- 子配置:红包封面 → 粘贴红包封面链接 -->
                <div v-else-if="form.channelsLinkType === 'red_envelope'" class="link-sub">
                  <el-input v-model="form.channelsRedEnvelopeUrl" placeholder="粘贴红包封面链接" clearable />
                </div>
              </div>
            </template>

            <!-- 微博专属卡片(合集为账号级,选中账号后才显示) -->
            <template v-if="selectedPlatform === 'weibo' && selectedAccountId">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">加入合集</div>
                <RemoteSearchSelect
                  v-model="form.weiboCollectionName"
                  :data="form.weiboCollectionData"
                  :fetcher="fetchWeiboCollections"
                  :field-map="{ label: 'name' }"
                  search-mode="frontend"
                  empty-behavior="load-all"
                  placeholder="选择合集"
                  @change="handleWeiboCollectionChange"
                />
              </div>
            </template>

            <!-- 微信公众号合集(账号级,选中账号后才显示) -->
            <template v-if="selectedPlatform === 'weixin_gzh' && selectedAccountId">
              <div class="setting-card" :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }">
                <div class="setting-label" :style="{ color: currentPlatformConfig.color }">加入合集</div>
                <RemoteSearchSelect
                  v-model="form.gzhCollectionName"
                  :data="form.gzhCollectionData"
                  :fetcher="fetchGzhCollections"
                  :field-map="{ label: 'name' }"
                  search-mode="frontend"
                  empty-behavior="load-all"
                  placeholder="选择合集"
                  @change="handleGzhCollectionChange"
                />
              </div>
            </template>

            <!-- settingsFields（排除已在通用字段渲染的） -->
            <template v-for="field in currentPlatformConfig.settingsFields" :key="field.key">
              <template v-if="field.key !== 'title' && field.key !== 'description' && field.key !== 'videoFormat'">
                <div
                  v-if="!field.visibleWhen || form[field.visibleWhen.key] === field.visibleWhen.value"
                  :class="['setting-card', { 'setting-card--full-row': field.fullRow }]"
                  :style="{ borderColor: currentPlatformConfig.color + '26', background: currentPlatformConfig.color + '0a' }"
                >
                  <div class="setting-label" :style="{ color: currentPlatformConfig.color }">
                    <span v-if="field.required" style="color: #f56c6c; margin-right: 2px;">*</span>
                    {{ field.label }}
                  </div>
                  <div v-if="field.description" class="setting-desc">{{ field.description }}</div>

                  <el-input
                    v-if="field.type === 'input'"
                    v-model="form[field.key]"
                    :placeholder="field.placeholder"
                    size="small"
                  />
                  <el-switch
                    v-else-if="field.type === 'switch'"
                    v-model="form[field.key]"
                  />
                  <div v-else-if="field.type === 'radio'" class="radio-row" :class="{ 'is-disabled': field.disabledWhen && form[field.disabledWhen.key] === field.disabledWhen.value }">
                    <label
                      v-for="opt in field.options"
                      :key="String(opt.value)"
                      :class="['radio-item', { 'cursor-pointer': !(field.disabledWhen && form[field.disabledWhen.key] === field.disabledWhen.value), 'is-disabled': field.disabledWhen && form[field.disabledWhen.key] === field.disabledWhen.value }]"
                    >
                      <input
                        type="radio"
                        :name="(selectedAccountId || selectedPlatform) + '-' + field.key"
                        :value="opt.value"
                        v-model="form[field.key]"
                        :disabled="field.disabledWhen && form[field.disabledWhen.key] === field.disabledWhen.value"
                        class="cursor-pointer"
                      />
                      <span
                        :class="['radio-text', { on: form[field.key] === opt.value }]"
                        :style="form[field.key] === opt.value && !(field.disabledWhen && form[field.disabledWhen.key] === field.disabledWhen.value) ? { borderColor: currentPlatformConfig.color, color: currentPlatformConfig.color } : {}"
                      >{{ opt.label }}</span>
                    </label>
                  </div>
                  <el-select
                    v-else-if="field.type === 'select'"
                    v-model="form[field.key]"
                    :placeholder="field.placeholder"
                    size="small"
                    clearable
                    class="cursor-pointer"
                  >
                    <el-option
                      v-for="opt in (field.options || [])"
                      :key="opt.value"
                      :label="opt.label"
                      :value="opt.value"
                    />
                    <el-option v-if="!field.options || field.options.length === 0" label="暂无可选项" :value="''" disabled />
                  </el-select>
                  <el-select
                    v-else-if="field.type === 'multiSelect'"
                    v-model="form[field.key]"
                    :placeholder="field.placeholder"
                    size="small"
                    multiple
                    collapse-tags
                    collapse-tags-tooltip
                    clearable
                    class="cursor-pointer"
                  >
                    <el-option
                      v-for="opt in (field.options || [])"
                      :key="opt.value"
                      :label="opt.label"
                      :value="opt.value"
                    />
                    <el-option v-if="!field.options || field.options.length === 0" label="暂无可选项" :value="''" disabled />
                  </el-select>
                  <el-date-picker
                    v-else-if="field.type === 'datetime'"
                    v-model="form[field.key]"
                    type="datetime"
                    :placeholder="field.placeholder"
                    :disabled-date="field.disabledDate || (field.key === 'scheduleTime' ? scheduleDisabledDate : undefined)"
                    :disabled-hours="field.disabledHours || (field.key === 'scheduleTime' ? () => scheduleDisabledHours(field.key) : undefined)"
                    :disabled-minutes="field.disabledMinutes || (field.key === 'scheduleTime' ? (h) => scheduleDisabledMinutes(field.key, h) : undefined)"
                    value-format="YYYY-MM-DD HH:mm:ss"
                    size="small"
                    class="cursor-pointer"
                  />
                  <el-date-picker
                    v-else-if="field.type === 'date'"
                    v-model="form[field.key]"
                    type="date"
                    :placeholder="field.placeholder"
                    :disabled-date="(date) => date > new Date()"
                    value-format="YYYY-MM-DD"
                    size="small"
                    class="cursor-pointer"
                  />
                  <XhsPoiSelect
                    v-else-if="field.type === 'poiSelect' && !field.key.startsWith('vivo')"
                    :account-id="selectedAccountId"
                    v-model="form[field.key]"
                    :data="form[field.key + 'Data']"
                    @change="(val) => handleXhsPoiChange(field.key, val)"
                  />
                  <VivoPositionSelect
                    v-else-if="field.type === 'poiSelect' && field.key.startsWith('vivo')"
                    :account-id="selectedAccountId"
                    v-model="form[field.key]"
                    :data="form[field.key + 'Data']"
                    @change="(val) => handleXhsPoiChange(field.key, val)"
                  />
                  <el-cascader
                    v-else-if="field.type === 'cascader'"
                    v-model="form[field.key]"
                    :options="field.options || []"
                    :placeholder="field.placeholder"
                    :props="field.props || { expandTrigger: 'hover' }"
                    size="small"
                    clearable
                    filterable
                    class="cursor-pointer weibo-cascader"
                  />
                  <RemoteSearchSelect
                    v-else-if="field.type === 'compilationSelect'"
                    v-model="form[field.key]"
                    :data="form.compilationData"
                    :fetcher="fetchCompilation"
                    :field-map="compilationFieldMap"
                    search-mode="backend"
                    empty-behavior="clear"
                    placeholder="输入合集名称搜索"
                    search-placeholder="输入合集名称,按回车搜索"
                    @change="(val) => handleAlipayCompilationChange(field.key, val)"
                  />
                </div>
              </template>
            </template>
          </div>
        </div>

        <!-- No account selected hint -->
        <div v-else-if="publishAccountIds.size === 0" class="no-platform-hint">
          <div class="hint-icon">
            <el-icon :size="48"><UserFilled /></el-icon>
          </div>
          <p>请先在左侧账号设置</p>
          <p class="hint-sub">选择账号后才能配置对应渠道的发布设置</p>
        </div>

        <!-- No platform selected hint -->
        <div v-else class="no-platform-hint">
          <div class="hint-icon">
            <el-icon :size="48"><VideoCameraFilled /></el-icon>
          </div>
          <p>请在左侧选择一个平台分组</p>
          <p class="hint-sub">选择后可配置该平台的个性化发布设置</p>
        </div>
      </div>
      </div><!-- /main-form-col -->

      <!-- Right: Phone preview panel -->
      <div class="phone-panel">
        <div class="phone-panel-header">
          <span class="phone-panel-title">视频预览</span>
        </div>
        <div class="phone-preview-area">
          <div :class="['phone-mockup', videoModeTab]">
            <div class="phone-notch"></div>
            <div class="phone-screen">
              <template v-if="currentVideoData">
                <video
                  :src="currentVideoData.url"
                  controls
                  preload="metadata"
                  class="phone-video-player"
                ></video>
              </template>
              <template v-else>
                <div class="phone-empty" @click="triggerUploadVideo()">
                  <el-icon :size="28"><Upload /></el-icon>
                  <span>上传视频</span>
                </div>
              </template>
            </div>
            <div class="phone-home-bar"></div>
          </div>
        </div>
        <div class="phone-panel-actions">
          <button class="cover-action-btn primary" @click="triggerUploadVideo()">
            <el-icon :size="14"><Upload /></el-icon><span>本地上传</span>
          </button>
          <button class="cover-action-btn" @click="selectFromLibrary('video')">
            <el-icon :size="14"><Picture /></el-icon><span>素材库</span>
          </button>
        </div>
        <div v-if="currentVideoData" class="phone-panel-info">
          <span class="phone-info-name">{{ currentVideoData.name }}</span>
          <button class="phone-info-remove" @click="clearVideo()">
            <el-icon :size="12"><Delete /></el-icon>
          </button>
        </div>
      </div>

      </div><!-- /main-body -->
    </main>

    <!-- ========== DIALOGS ========== -->

    <!-- Account Selection Dialog -->
    <AccountSelectDialog
      v-model="accountDialogVisible"
      :platforms="platformList"
      :publish-account-ids="publishAccountIds"
      @confirm="onAccountConfirm"
    />

    <!-- Video Upload Dialog -->
    <MaterialUploader
      v-model="videoUploadDialogVisible"
      accept="video/*"
      :max-size="null"
      :multiple="false"
      :title="'上传视频'"
      tip="支持 MP4、AVI、MKV 等视频格式，不限大小"
      @uploaded="onVideoUploaded"
    />

    <!-- Add Videos To Queue Dialog (multiple) -->
    <MaterialUploader
      v-model="addVideosDialogVisible"
      accept="video/*"
      :max-size="null"
      :multiple="true"
      :title="'添加视频到队列'"
      tip="支持 MP4、AVI、MKV 等视频格式，可多选；新视频继承当前配置（含账号与平台设置）"
      @all-uploaded="onVideosAdded"
    />

    <!-- Add Videos From Library To Queue Dialog (multiple) -->
    <MaterialSelectDialog
      ref="queueMaterialSelectRef"
      filter-type="video"
      :multiple="true"
      @select="onQueueMaterialsSelected"
    />

    <!-- Material Library Dialog -->
    <MaterialSelectDialog
      ref="materialSelectRef"
      :filter-type="materialLibraryMode === 'cover' ? 'image' : 'video'"
      @select="onMaterialSelect"
    />

    <!-- Batch Publish Confirm Dialog -->
    <VideoBatchConfirmDialog
      :visible="batchConfirmVisible"
      :rows="batchConfirmRows"
      :submitting="batchSubmitting"
      @update:visible="batchConfirmVisible = $event"
      @confirm="confirmBatchPublish"
    />

    <!-- Batch Publish Realtime Progress Dialog -->
    <BatchTaskProgressDialog
      :visible="batchProgressVisible"
      :batch-ids="batchProgressBatchIds"
      :failed-notes="batchProgressFailedNotes"
      :interval-minutes="batchProgressIntervalMinutes"
      @update:visible="batchProgressVisible = $event"
      @go-history="goPublishHistoryFromProgress"
    />

    <!-- Pre-publish Cookie Check Dialog -->
    <PrePublishCheckDialog
      ref="prePublishCheckRef"
      v-model="prePublishCheckVisible"
    />

    <OneClickFillDialog
      v-model="oneClickDialogOpen"
      type="video"
      @pick="handleOneClickFill"
    />

    <BatchSetDialog
      v-model="batchSetDialogOpen"
      :platforms="batchSetPlatforms"
      :show-all-videos="true"
      @apply="onBatchSetApply"
    />

    <!-- 淘宝光合:关联商品/店铺选择弹窗 -->
    <GuangheItemPicker
      v-model="guanghePickerVisible"
      :account-id="guanghePickerAccountId"
      :mode="guanghePickerMode"
      :init-selected="(form[guanghePickerFieldKey] || [])"
      @confirm="onGuanghePickerConfirm"
    />

    <!-- 京东:关联商品选择弹窗 -->
    <JdItemPicker
      v-model="jdPickerVisible"
      :account-id="jdPickerAccountId"
      :init-selected="form.jdProducts"
      @confirm="onJdPickerConfirm"
    />

    <!-- 视频号:关联剧集选择弹窗(后端 channels drama_picker) -->
    <ChannelsDramaPicker
      v-model="channelsDramaPickerVisible"
      :account-id="channelsDramaPickerAccountId"
      :link-type="channelsDramaPickerLinkType"
      :init-selected="form.channelsDrama"
      @confirm="onChannelsDramaPickerConfirm"
    />
  </div>
</template>

<script setup>
import { ref, reactive, computed, nextTick, watch, onMounted, onBeforeUnmount } from 'vue'
import { Upload, Picture, VideoCameraFilled, Delete, Document, WarningFilled, MagicStick, Setting, Promotion, UserFilled, Close, Plus } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useAccountStore } from '@/stores/account'
import { useAppStore } from '@/stores/app'
import { materialsApi } from '@/api/materials'
import { getFileUrl } from '@/utils/storage'
import { http } from '@/utils/request'
import { accountApi } from '@/api/account'
import { platformList, getPlatformByKey, platformKeyToId, platformNameToKey } from '@/config/platforms'
import { validateVideoForPlatform, validateTitleForPlatform, validateDescForPlatform, countCharsWithEmoji } from '@/config/videoLimits'

import AccountSidebar from '@/components/AccountSidebar.vue'
import AccountSelectDialog from '@/components/AccountSelectDialog.vue'
import BatchSetDialog from '@/components/BatchSetDialog.vue'
import CoverCard from '@/components/CoverCard.vue'
import CoverEditorDialog from '@/components/CoverEditorDialog.vue'
import MaterialSelectDialog from '@/components/MaterialSelectDialog.vue'
import MaterialUploader from '@/components/MaterialUploader.vue'
import OneClickFillDialog from '@/components/OneClickFillDialog.vue'
import VideoQueueBar from '@/components/VideoQueueBar.vue'
import VideoBatchConfirmDialog from '@/components/VideoBatchConfirmDialog.vue'
import BatchTaskProgressDialog from '@/components/BatchTaskProgressDialog.vue'
import DouyinActivitySelect from '@/components/douyin/ActivitySelect.vue'
import DouyinTagSelect from '@/components/douyin/TagSelect.vue'
import { channelsApi } from '@/api/channels'
import XhsPoiSelect from '@/components/xiaohongshu/PoiSelect.vue'
import VivoPositionSelect from '@/components/vivo/PositionSelect.vue'
import RemoteSearchSelect from '@/components/common/RemoteSearchSelect.vue'
import PrePublishCheckDialog from '@/components/PrePublishCheckDialog.vue'
import GuangheItemPicker from '@/components/GuangheItemPicker.vue'
import JdItemPicker from '@/components/JdItemPicker.vue'
import ChannelsDramaPicker from '@/components/ChannelsDramaPicker.vue'
import { channelsDramaApi } from '@/api/channels_drama'
import { xhsApi } from '@/api/xiaohongshu'
import { biliApi } from '@/api/bilibili'
import { douyinImageApi } from '@/api/douyinImage'
import { alipayApi } from '@/api/alipay'
import { toutiaoApi } from '@/api/toutiao'
import { weiboApi } from '@/api/weibo'
import { weixinGzhApi } from '@/api/weixin_gzh'
import { jdApi } from '@/api/jd'
import { useAutoSave } from '@/composables/useAutoSave'
import { useBatchSetApply } from '@/composables/useBatchSetApply'
import { frameApi } from '@/api/frame'
import { draftApi } from '@/api/draft'
import { batchPublishApi } from '@/api/v2'
import { useRoute, useRouter } from 'vue-router'
import { HASHTAG_RE as DESC_HASHTAG_RE, countDescriptionHashtags, useAutoExtractHashtags } from '@/utils/hashtag'

// ========== Stores & Config ==========
const accountStore = useAccountStore()
const appStore = useAppStore()
appStore.loadAutoFillTitle()
appStore.loadAccountCheckMode()
appStore.loadAutoSaveSettings()
const route = useRoute()
const router = useRouter()

// ========== Left Sidebar State ==========
const expandedGroups = ref(new Set())
const selectedPlatform = ref(null)
const selectedAccountId = ref(null)

const accountGroups = computed(() => {
  return platformList.map(p => ({
    key: p.key,
    id: p.id,
    name: p.name,
    letter: p.letter,
    color: p.color,
    bgColor: p.bgColor,
    cssClass: p.cssClass,
    logo: p.logo,
    accounts: accountStore.accounts.filter(a => a.platform === p.name),
    settingsFields: p.settingsFields || [],
    defaultSettings: p.defaultSettings || {},
  }))
})

const totalCount = computed(() => accountStore.accounts.length)

// 当前预览视频:横版优先,无则取竖版(发布时不再区分横竖,上传了即可发)
const currentVideoData = computed(() =>
  currentEditTarget.value.videoLandscape || currentEditTarget.value.videoPortrait
)

const currentPlatformConfig = computed(() =>
  selectedPlatform.value ? getPlatformByKey(selectedPlatform.value) : null
)

// ========== Public Config ==========
const commonConfig = reactive({
  videoLandscape: null,
  videoPortrait: null,
  coverLandscape: null,      // 横版封面 4:3（主尺寸）
  coverPortrait: null,       // 竖版封面 3:4（主尺寸）
  coverLandscape169: null,   // 横版封面 16:9（次尺寸，后续各平台按需使用）
  coverPortrait916: null,    // 竖版封面 9:16（次尺寸）
})

// ===== 封面卡片 tab 激活比例 =====
// 切换到不同编辑目标（公共/平台覆写/账号覆写）后重置到主尺寸
// 对应的 watch 注册在 currentEditTarget 声明之后
const coverPortraitActiveRatio = ref('3:4')    // 竖版卡：默认 3:4
const coverLandscapeActiveRatio = ref('4:3')    // 横版卡：默认 4:3

// 自动裁剪封面的状态：上传/选视频后，后台抽帧 + 生成多比例封面（5~20s）
// 用 cropping=true 让 CoverCard 显示「裁剪中…」反馈，避免用户以为没响应
const isCoverCropping = ref(false)
const coverCropStage = ref('')         // 'extracting' | 'saving'

// 平台级覆写（spec §3.3）—— 公共区域的媒体字段覆写
const platformOverrides = reactive({})         // { [platformKey]: { coverPortrait, coverLandscape, videoPortrait, videoLandscape } }
const platformChecked = reactive({})           // { [platformKey]: boolean }

// 账号级覆写（accountOverrides 已在下方 line 631 声明）
const accountChecked = reactive({})            // { [accountId]: boolean }

// 当前编辑目标：公共区域 v-model / 编辑器 source/target 的实际绑定对象
// 勾选账号 → accountOverrides[id]；勾选平台 → platformOverrides[key]；默认 → commonConfig
const currentEditTarget = computed(() => {
  const aid = selectedAccountId.value
  if (aid && accountChecked[aid] && accountOverrides[aid]) return accountOverrides[aid]
  const pk = selectedPlatform.value
  if (pk && platformChecked[pk] && platformOverrides[pk]) return platformOverrides[pk]
  return commonConfig
})

// 切换编辑目标（公共 / 平台覆写 / 账号覆写）时，封面卡片激活 tab 重置到主尺寸
watch(currentEditTarget, () => {
  coverPortraitActiveRatio.value = '3:4'
  coverLandscapeActiveRatio.value = '4:3'
})

function hasPlatformOverrideContent(platformKey) {
  const ov = platformOverrides[platformKey]
  if (!ov) return false
  return !!(
    ov.coverPortrait || ov.coverLandscape || ov.coverLandscape169 || ov.coverPortrait916 ||
    ov.videoPortrait  || ov.videoLandscape
  )
}

function hasAccountOverrideContent(accountId) {
  const ov = accountOverrides[accountId]
  if (!ov) return false
  return !!(
    ov.coverPortrait || ov.coverLandscape || ov.coverLandscape169 || ov.coverPortrait916 ||
    ov.videoPortrait  || ov.videoLandscape
  )
}

// ========== Override Section: Interaction ==========

function onPlatformCheckChange(checked) {
  if (!checked && hasPlatformOverrideContent(selectedPlatform.value)) {
    ElMessageBox.confirm(
      '取消个性化配置后，本渠道的覆写将丢失，恢复使用公共默认，是否继续？',
      '确认取消', { confirmButtonText: '继续', cancelButtonText: '取消', type: 'warning' }
    ).then(() => {
      delete platformOverrides[selectedPlatform.value]
    }).catch(() => {
      platformChecked[selectedPlatform.value] = true
    })
  } else if (checked) {
    platformOverrides[selectedPlatform.value] = {
      coverPortrait: null, coverLandscape: null,
      coverLandscape169: null, coverPortrait916: null,
      videoPortrait: null, videoLandscape: null,
    }
  }
}

function onAccountCheckChange(checked) {
  if (!checked && hasAccountOverrideContent(selectedAccountId.value)) {
    ElMessageBox.confirm(
      '取消个性化配置后，本账号的覆写将丢失，恢复使用渠道默认，是否继续？',
      '确认取消', { confirmButtonText: '继续', cancelButtonText: '取消', type: 'warning' }
    ).then(() => {
      delete accountOverrides[selectedAccountId.value]
    }).catch(() => {
      accountChecked[selectedAccountId.value] = true
    })
  } else if (checked) {
    accountOverrides[selectedAccountId.value] = {
      coverPortrait: null, coverLandscape: null,
      coverLandscape169: null, coverPortrait916: null,
      videoPortrait: null, videoLandscape: null,
    }
  }
}

// ========== 4 级优先级合并（spec §3.3） ==========
// accountOv > platformOv > platformDefault > common
function resolveAccountConfig(platformKey, accountId) {
  const accountOv = accountOverrides[accountId] || null
  const platformOv = platformOverrides[platformKey] || null
  const platformDefault = platformConfigs[platformKey] || null
  return mergeConfig(commonConfig, platformDefault, platformOv, accountOv)
}

/**
 * 解析定时发布时间:账号级优先,且账号级显式设置(含清空)就以账号级为准。
 *
 * 关键: accountOv.scheduleTime === null 表示用户在账号级"清空了定时"(=不定时),
 * 不能用 ?? fallback 到平台级默认 —— 否则平台级的定时时间会强制定时该账号。
 * 仅当账号 override 完全没带 scheduleTime key(未操作过)时,才 fallback 到平台级。
 */
function _resolveScheduleTime(accountOv, platformOv, platformDefault) {
  if (accountOv && Object.prototype.hasOwnProperty.call(accountOv, 'scheduleTime')) {
    // 账号级显式设置过(含 null/'') → 以账号级为准(null/'' = 不定时)
    return accountOv.scheduleTime || ''
  }
  if (platformOv && Object.prototype.hasOwnProperty.call(platformOv, 'scheduleTime')) {
    return platformOv.scheduleTime || ''
  }
  return platformDefault?.scheduleTime || ''
}

function mergeConfig(common, platformDefault, platformOv, accountOv) {
  return {
    // 文本字段 4 级合并（账号 > 渠道 > 平台默认），与视频/封面/平台特有字段一致
    title: accountOv?.title ?? platformOv?.title ?? platformDefault?.title ?? '',
    description: accountOv?.description ?? platformOv?.description ?? platformDefault?.description ?? '',
    tags: accountOv?.tags ?? platformOv?.tags ?? platformDefault?.tags ?? [],
    // 视频/封面走 4 级合并 → commonConfig 兜底
    coverLandscape: accountOv?.coverLandscape ?? platformOv?.coverLandscape ?? common.coverLandscape,
    coverPortrait:  accountOv?.coverPortrait  ?? platformOv?.coverPortrait  ?? common.coverPortrait,
    coverLandscape169: accountOv?.coverLandscape169 ?? platformOv?.coverLandscape169 ?? common.coverLandscape169,
    coverPortrait916:  accountOv?.coverPortrait916  ?? platformOv?.coverPortrait916  ?? common.coverPortrait916,
    videoLandscape: accountOv?.videoLandscape ?? platformOv?.videoLandscape ?? common.videoLandscape,
    videoPortrait:  accountOv?.videoPortrait  ?? platformOv?.videoPortrait  ?? common.videoPortrait,
    // 平台特有字段走 platformDefault 兜底
    enableTimer: accountOv?.enableTimer ?? platformOv?.enableTimer ?? platformDefault?.enableTimer ?? 0,
    // scheduleTime: 账号级若已显式设置(含清空为 null/'')就以账号级为准,不 fallback
    // 到平台级默认 —— 否则平台级的定时时间会污染"账号没设定时"的账号(实测 bug)。
    // 用 _hasOwn 判断:账号 override 显式带过该 key 才采纳账号级值(含 null/空=不定时)。
    scheduleTime: _resolveScheduleTime(accountOv, platformOv, platformDefault),
    aiContent: accountOv?.aiContent ?? platformOv?.aiContent ?? platformDefault?.aiContent ?? '',
    isOriginal: accountOv?.isOriginal ?? platformOv?.isOriginal ?? platformDefault?.isOriginal ?? false,
    // 平台特有字段：4 级合并（账号 > 渠道 > 平台默认），与视频/封面一致
    creationDeclaration: accountOv?.creationDeclaration ?? platformOv?.creationDeclaration ?? platformDefault?.creationDeclaration,
    // B 站转载来源(创作声明=转载 时必填)
    biliRepostSource: accountOv?.biliRepostSource ?? platformOv?.biliRepostSource ?? platformDefault?.biliRepostSource ?? '',
    // B 站是否保留系统生成的标签(关闭 = 发布前先清空 B 站标签栏再填自己的)
    biliKeepSystemTags: accountOv?.biliKeepSystemTags ?? platformOv?.biliKeepSystemTags ?? platformDefault?.biliKeepSystemTags ?? true,
    riskWarning: accountOv?.riskWarning ?? platformOv?.riskWarning ?? platformDefault?.riskWarning,
    enableCashActivity: accountOv?.enableCashActivity ?? platformOv?.enableCashActivity ?? platformDefault?.enableCashActivity,
    supplementaryDeclaration: accountOv?.supplementaryDeclaration ?? platformOv?.supplementaryDeclaration ?? platformDefault?.supplementaryDeclaration,
    audience: accountOv?.audience ?? platformOv?.audience ?? platformDefault?.audience,
    alteredContent: accountOv?.alteredContent ?? platformOv?.alteredContent ?? platformDefault?.alteredContent,
    // 修：zone 字段也走 4 级合并（B 站分区），账号级填的 zone 才能进 publishData
    zone: accountOv?.zone ?? platformOv?.zone ?? platformDefault?.zone ?? '',
    // 知乎「所属领域」4 级合并
    category: accountOv?.category ?? platformOv?.category ?? platformDefault?.category ?? '',
    // 平台特有字段 4 级合并（账号 > 渠道 > 平台默认）—— 补回漏的
    // 抖音
    activityId: accountOv?.activityId ?? platformOv?.activityId ?? platformDefault?.activityId ?? [],
    hotspotId: accountOv?.hotspotId ?? platformOv?.hotspotId ?? platformDefault?.hotspotId ?? '',
    hotspotData: accountOv?.hotspotData ?? platformOv?.hotspotData ?? platformDefault?.hotspotData ?? null,
    selectedTag: accountOv?.selectedTag ?? platformOv?.selectedTag ?? platformDefault?.selectedTag ?? null,
    tagType: accountOv?.tagType ?? platformOv?.tagType ?? platformDefault?.tagType ?? '',
    tagValue: accountOv?.tagValue ?? platformOv?.tagValue ?? platformDefault?.tagValue ?? '',
    mixId: accountOv?.mixId ?? platformOv?.mixId ?? platformDefault?.mixId ?? '',
    mixData: accountOv?.mixData ?? platformOv?.mixData ?? platformDefault?.mixData ?? null,
    // B 站
    topic: accountOv?.topic ?? platformOv?.topic ?? platformDefault?.topic ?? '',
    // 视频号
    isDraft: accountOv?.isDraft ?? platformOv?.isDraft ?? platformDefault?.isDraft ?? false,
    location: accountOv?.location ?? platformOv?.location ?? platformDefault?.location ?? '',
    // 平台特有字段 4 级合并（账号 > 渠道 > 平台默认）—— 补回 xiaohongshu 漏的
    collection: accountOv?.collection ?? platformOv?.collection ?? platformDefault?.collection ?? '',
    groupChat: accountOv?.groupChat ?? platformOv?.groupChat ?? platformDefault?.groupChat ?? '',
    // 小红书合集(账号级配置)
    collectionId: accountOv?.collectionId ?? platformOv?.collectionId ?? platformDefault?.collectionId ?? '',
    collectionName: accountOv?.collectionName ?? platformOv?.collectionName ?? platformDefault?.collectionName ?? '',
    collectionData: accountOv?.collectionData ?? platformOv?.collectionData ?? platformDefault?.collectionData ?? null,
    // 小红书内容来源声明联动字段(平台级)
    xhsSourceType: accountOv?.xhsSourceType ?? platformOv?.xhsSourceType ?? platformDefault?.xhsSourceType ?? '',
    xhsShootLocation: accountOv?.xhsShootLocation ?? platformOv?.xhsShootLocation ?? platformDefault?.xhsShootLocation ?? '',
    xhsShootLocationData: accountOv?.xhsShootLocationData ?? platformOv?.xhsShootLocationData ?? platformDefault?.xhsShootLocationData ?? null,
    xhsShootDate: accountOv?.xhsShootDate ?? platformOv?.xhsShootDate ?? platformDefault?.xhsShootDate ?? '',
    xhsRepostSource: accountOv?.xhsRepostSource ?? platformOv?.xhsRepostSource ?? platformDefault?.xhsRepostSource ?? '',
    // 微博
    videoType: accountOv?.videoType ?? platformOv?.videoType ?? platformDefault?.videoType ?? '',
    weiboCategory: accountOv?.weiboCategory ?? platformOv?.weiboCategory ?? platformDefault?.weiboCategory ?? [],
    weiboCollectionName: accountOv?.weiboCollectionName ?? platformOv?.weiboCollectionName ?? platformDefault?.weiboCollectionName ?? '',
    contentStatement: accountOv?.contentStatement ?? platformOv?.contentStatement ?? platformDefault?.contentStatement ?? '',
    contentStatement2: accountOv?.contentStatement2 ?? platformOv?.contentStatement2 ?? platformDefault?.contentStatement2 ?? '',
    contentStatement2Optional: accountOv?.contentStatement2Optional ?? platformOv?.contentStatement2Optional ?? platformDefault?.contentStatement2Optional ?? '',
    // 支付宝
    authorStatement: accountOv?.authorStatement ?? platformOv?.authorStatement ?? platformDefault?.authorStatement ?? '',
    reprintUrl: accountOv?.reprintUrl ?? platformOv?.reprintUrl ?? platformDefault?.reprintUrl ?? '',
    compilation: accountOv?.compilation ?? platformOv?.compilation ?? platformDefault?.compilation ?? '',
    compilationData: accountOv?.compilationData ?? platformOv?.compilationData ?? platformDefault?.compilationData ?? null,
    // 今日头条
    enableGenerateImage: accountOv?.enableGenerateImage ?? platformOv?.enableGenerateImage ?? platformDefault?.enableGenerateImage ?? true,
    collection: accountOv?.collection ?? platformOv?.collection ?? platformDefault?.collection ?? '',
    extendLink: accountOv?.extendLink ?? platformOv?.extendLink ?? platformDefault?.extendLink ?? false,
    extendLinkUrl: accountOv?.extendLinkUrl ?? platformOv?.extendLinkUrl ?? platformDefault?.extendLinkUrl ?? '',
    // 大鱼号转载原文链接(信息来源=转载 时必填)
    dayuRepostUrl: accountOv?.dayuRepostUrl ?? platformOv?.dayuRepostUrl ?? platformDefault?.dayuRepostUrl ?? '',
    // B 站合集(账号级)
    biliCollectionName: accountOv?.biliCollectionName ?? platformOv?.biliCollectionName ?? platformDefault?.biliCollectionName ?? '',
    biliCollectionData: accountOv?.biliCollectionData ?? platformOv?.biliCollectionData ?? platformDefault?.biliCollectionData ?? null,
    // 视频号合集(账号级)
    channelsCollectionName: accountOv?.channelsCollectionName ?? platformOv?.channelsCollectionName ?? platformDefault?.channelsCollectionName ?? '',
    channelsCollectionData: accountOv?.channelsCollectionData ?? platformOv?.channelsCollectionData ?? platformDefault?.channelsCollectionData ?? null,
    // 视频号位置(账号级,空=不显示位置)
    channelsLocationName: accountOv?.channelsLocationName ?? platformOv?.channelsLocationName ?? platformDefault?.channelsLocationName ?? '',
    channelsLocationData: accountOv?.channelsLocationData ?? platformOv?.channelsLocationData ?? platformDefault?.channelsLocationData ?? null,
    // 视频号活动:虽然卡片按平台级显示,但 watch(form) 把值回写到 accountOverrides
    // (与合集/位置同模式),所以 4 级合并才能取到草稿恢复后的值
    channelsActivityName: accountOv?.channelsActivityName ?? platformOv?.channelsActivityName ?? platformDefault?.channelsActivityName ?? '',
    channelsActivityData: accountOv?.channelsActivityData ?? platformOv?.channelsActivityData ?? platformDefault?.channelsActivityData ?? null,
    // 视频号视频标注(平台级):所有选项(含「无需标注」)都会去页面真正选中
    channelsMarkTag: accountOv?.channelsMarkTag ?? platformOv?.channelsMarkTag ?? platformDefault?.channelsMarkTag ?? '无需标注',
    channelsShootDate: accountOv?.channelsShootDate ?? platformOv?.channelsShootDate ?? platformDefault?.channelsShootDate ?? '',
    channelsShootRegion: accountOv?.channelsShootRegion ?? platformOv?.channelsShootRegion ?? platformDefault?.channelsShootRegion ?? [],
    channelsRepostSource: accountOv?.channelsRepostSource ?? platformOv?.channelsRepostSource ?? platformDefault?.channelsRepostSource ?? '',
    // 视频号剧集(账号级,每条视频关联 1 部剧集,值是 [{key,title,cover,extinfo,sourceLeft,sourceRight,trace}])
    channelsDrama: accountOv?.channelsDrama ?? platformOv?.channelsDrama ?? platformDefault?.channelsDrama ?? [],
    // 视频号「链接」下拉选择(账号级): '' | 'article' | 'red_envelope' | 'drama' | 'mini_drama'
    channelsLinkType: accountOv?.channelsLinkType ?? platformOv?.channelsLinkType ?? platformDefault?.channelsLinkType ?? '',
    // 公众号文章链接(账号级,channelsLinkType='article' 时使用)
    channelsLinkArticleUrl: accountOv?.channelsLinkArticleUrl ?? platformOv?.channelsLinkArticleUrl ?? platformDefault?.channelsLinkArticleUrl ?? '',
    // 红包封面链接(账号级,channelsLinkType='red_envelope' 时使用)
    channelsRedEnvelopeUrl: accountOv?.channelsRedEnvelopeUrl ?? platformOv?.channelsRedEnvelopeUrl ?? platformDefault?.channelsRedEnvelopeUrl ?? '',
    // CSDN 是否推荐(平台级开关)
    recommend: accountOv?.recommend ?? platformOv?.recommend ?? platformDefault?.recommend ?? false,
    // VIVO 平台特有字段(平台级)
    vivoLocationName: accountOv?.vivoLocationName ?? platformOv?.vivoLocationName ?? platformDefault?.vivoLocationName ?? '',
    vivoLocationData: accountOv?.vivoLocationData ?? platformOv?.vivoLocationData ?? platformDefault?.vivoLocationData ?? null,
    vivoDistribution: accountOv?.vivoDistribution ?? platformOv?.vivoDistribution ?? platformDefault?.vivoDistribution ?? false,
    vivoDeclaration: accountOv?.vivoDeclaration ?? platformOv?.vivoDeclaration ?? platformDefault?.vivoDeclaration ?? '',
    vivoPrivacy: accountOv?.vivoPrivacy ?? platformOv?.vivoPrivacy ?? platformDefault?.vivoPrivacy ?? '公开',
    vivoDownloadPermission: accountOv?.vivoDownloadPermission ?? platformOv?.vivoDownloadPermission ?? platformDefault?.vivoDownloadPermission ?? '允许',
    // 微信公众号合集(账号级)
    gzhCollectionName: accountOv?.gzhCollectionName ?? platformOv?.gzhCollectionName ?? platformDefault?.gzhCollectionName ?? '',
    gzhCollectionData: accountOv?.gzhCollectionData ?? platformOv?.gzhCollectionData ?? platformDefault?.gzhCollectionData ?? null,
    // 微信公众号创作来源(平台级)
    gzhClaimSource: accountOv?.gzhClaimSource ?? platformOv?.gzhClaimSource ?? platformDefault?.gzhClaimSource ?? '',
    // 淘宝光合创作者声明(平台级)
    guangheClaim: accountOv?.guangheClaim ?? platformOv?.guangheClaim ?? platformDefault?.guangheClaim ?? '',
    // 淘宝光合关联商品/店铺(平台级, radio 互斥, 名称列表最多 6 个)
    guangheLinkType: accountOv?.guangheLinkType ?? platformOv?.guangheLinkType ?? platformDefault?.guangheLinkType ?? '',
    guangheProducts: accountOv?.guangheProducts ?? platformOv?.guangheProducts ?? platformDefault?.guangheProducts ?? [],
    guangheShops: accountOv?.guangheShops ?? platformOv?.guangheShops ?? platformDefault?.guangheShops ?? [],
    // 京东关联挂件(平台级, radio 互斥)
    jdRelatedType: accountOv?.jdRelatedType ?? platformOv?.jdRelatedType ?? platformDefault?.jdRelatedType ?? '',
    jdProducts: accountOv?.jdProducts ?? platformOv?.jdProducts ?? platformDefault?.jdProducts ?? [],
    jdNovel: accountOv?.jdNovel ?? platformOv?.jdNovel ?? platformDefault?.jdNovel ?? '',
    jdNovelData: accountOv?.jdNovelData ?? platformOv?.jdNovelData ?? platformDefault?.jdNovelData ?? null,
    jdDeclaration: accountOv?.jdDeclaration ?? platformOv?.jdDeclaration ?? platformDefault?.jdDeclaration ?? '',
  }
}

// ========== Override Section: CoverEditor source/target ==========
// 公共区域的 CoverEditor 永远跟随 currentEditTarget（默认=commonConfig, 勾选时=覆写对象）
// coverEditOrientation 记录当前打开的是横版还是竖版弹窗
const coverEditOrientation = ref('landscape')
const editorSource = computed(() => {
  const t = currentEditTarget.value
  const isLandscape = coverEditOrientation.value === 'landscape'
  return {
    videoLandscape: t?.videoLandscape,
    videoPortrait:  t?.videoPortrait,
    // 横版：主尺寸=coverLandscape(4:3)，次尺寸=coverLandscape169(16:9)
    // 竖版：主尺寸=coverPortrait(3:4)，次尺寸=coverPortrait916(9:16)
    coverPrimary:   isLandscape ? t?.coverLandscape    : t?.coverPortrait,
    coverSecondary: isLandscape ? t?.coverLandscape169 : t?.coverPortrait916,
  }
})

// 确定性写回：直接按 orientation + ratio 映射到具体字段
function onCoverSaved({ orientation, ratio, cover }) {
  const t = currentEditTarget.value
  if (orientation === 'landscape') {
    if (ratio === '4:3') t.coverLandscape = cover
    else if (ratio === '16:9') t.coverLandscape169 = cover
  } else {
    if (ratio === '3:4') t.coverPortrait = cover
    else if (ratio === '9:16') t.coverPortrait916 = cover
  }
}

// Cover editor
const coverEditorRef = ref(null)
const landscapeFrames = ref([])
const portraitFrames = ref([])
// 预览区 mockup 比例:根据当前视频方向自动推导(horizontal→横版,其余→竖版)
// 不再需要用户手动切换 tab;无视频时默认竖版
const videoModeTab = computed(() =>
  currentVideoData.value?.orientation === 'horizontal' ? 'landscape' : 'portrait'
)

const portraitCoverFrames = computed(() =>
  portraitFrames.value.length > 0 ? portraitFrames.value : landscapeFrames.value
)
const landscapeCoverFrames = computed(() =>
  landscapeFrames.value.length > 0 ? landscapeFrames.value : portraitFrames.value
)

// ========== Per-platform Config ==========
// 平台表单默认值（常量）。platformConfigs 是「当前视频」的活状态，
// 切换视频时按默认值 + 快照重建（applyVideoSnapshot）。
const DEFAULT_PLATFORM_CONFIGS = {
  douyin: { title: '', description: '', tags: [], aiContent: '', isOriginal: false, scheduleTime: '', activityId: [], hotspotId: '', hotspotData: null, selectedTag: null, tagType: '', tagValue: '', mixId: '', mixData: null },
  xiaohongshu: { title: '', description: '', aiContent: '', isOriginal: false, scheduleTime: '', tags: [], collectionId: '', collectionName: '', collectionData: null },
  kuaishou: { title: '', description: '', aiContent: '', isOriginal: false, scheduleTime: '', tags: [] },
  bilibili: { title: '', description: '', zone: '', tags: [], creationDeclaration: '', biliRepostSource: '', biliKeepSystemTags: true, isOriginal: false, scheduleTime: '', biliCollectionName: '', biliCollectionData: null },
  channels: { title: '', description: '', isOriginal: false, scheduleTime: '', tags: [], channelsCollectionName: '', channelsCollectionData: null, channelsLocationName: '', channelsLocationData: null, channelsActivityName: '', channelsActivityData: null, channelsMarkTag: '无需标注', channelsShootDate: '', channelsShootRegion: [], channelsRepostSource: '', channelsDrama: [], channelsLinkType: '', channelsLinkArticleUrl: '', channelsRedEnvelopeUrl: '' },
  baijiahao: { title: '', description: '', isOriginal: false, scheduleTime: '', tags: [] },
  tiktok: { title: '', description: '', aiContent: false, isOriginal: false, scheduleTime: '', tags: [] },
  youtube: { title: '', description: '', audience: 'not_kids', alteredContent: false, scheduleTime: '', tags: [] },
  iqiyi: { title: '', description: '', creationDeclaration: '', riskWarning: '', enableCashActivity: false, scheduleTime: '', tags: [] },
  tencent_video: { title: '', description: '', creationDeclaration: [], scheduleTime: '', tags: [] },
  weibo: { title: '', description: '', videoType: '', weiboCategory: [], contentStatement: '', contentStatement2: '', contentStatement2Optional: '', tags: [], weiboCollectionName: '', weiboCollectionData: null },
  alipay: { title: '', description: '', authorStatement: '', reprintUrl: '', compilation: '', scheduleTime: '', tags: [] },
  toutiao: { title: '', description: '', creationDeclaration: [], enableGenerateImage: true, collection: '', extendLink: false, extendLinkUrl: '', scheduleTime: '', tags: [] },
  zhihu: { title: '', description: '', creationDeclaration: '内容无需标注', category: '', scheduleTime: '', tags: [] },
  csdn: { title: '', description: '', recommend: false, scheduleTime: '', tags: [] },
  vivo: { title: '', description: '', vivoLocationName: '', vivoLocationData: null,
    vivoDistribution: false, vivoDeclaration: '', vivoPrivacy: '公开',
    vivoDownloadPermission: '允许', scheduleTime: '', tags: [] },
  weixin_gzh: { title: '', description: '', isOriginal: false, gzhClaimSource: '', gzhCollectionName: '', gzhCollectionData: null, scheduleTime: '', tags: [] },
  taobao_guanghe: { title: '', description: '', guangheClaim: '', guangheLinkType: '', guangheProducts: [], guangheShops: [], scheduleTime: '', tags: [] },
  jingmai: { title: '', description: '', jdRelatedType: '', jdProducts: [], jdNovel: '', jdNovelData: null, jdDeclaration: '', scheduleTime: '', tags: [] },
  dayu: { title: '', description: '', creationDeclaration: '', dayuRepostUrl: '', category: '', scheduleTime: '', tags: [] },
}

const platformConfigs = reactive(JSON.parse(JSON.stringify(DEFAULT_PLATFORM_CONFIGS)))

const accountOverrides = reactive({})

const currentSettings = computed(() =>
  selectedPlatform.value ? platformConfigs[selectedPlatform.value] || {} : {}
)

// ========== Account-level Settings Merging ==========
function getAccountSettings(accountId, platformKey) {
  const platform = platformConfigs[platformKey] || {}
  const override = accountOverrides[accountId] || {}
  const merged = { ...platform }
  for (const key of Object.keys(merged)) {
    if (override[key] !== undefined && override[key] !== '') {
      merged[key] = override[key]
    }
  }
  return merged
}

function hasAccountOverride(accountId) {
  const override = accountOverrides[accountId]
  if (!override) return false
  return Object.values(override).some(v => v !== undefined && v !== '' && v !== false)
}

const form = reactive({})

// 媒体字段由 currentEditTarget 直接管理（写入 commonConfig / platformOverrides / accountOverrides），
// 不应该出现在 form 里。否则 watch(form) 的 diff 会把它们当成账号级差异写回 accountOverrides，
// 其中的 null 会覆盖刚刚选好的视频/封面（详见 selectFromLibrary 后视频消失的 bug）。
const MEDIA_KEYS = new Set([
  'videoLandscape', 'videoPortrait',
  'coverLandscape', 'coverPortrait',
  'coverLandscape169', 'coverPortrait916',
])

// ========== Schedule Time Picker Constraints ==========
// 定时发布:必须晚于当前时间,最多往后 14 天
// 仅对 scheduleTime 字段生效,其它 datetime 字段不受影响
const SCHEDULE_MAX_DAYS = 14

function scheduleDisabledDate(date) {
  if (!date) return false
  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const maxDate = new Date(startOfToday)
  maxDate.setDate(maxDate.getDate() + SCHEDULE_MAX_DAYS)
  return date < startOfToday || date > maxDate
}

function _sameDay(a, b) {
  return a.getFullYear() === b.getFullYear()
    && a.getMonth() === b.getMonth()
    && a.getDate() === b.getDate()
}

// disabled-hours: 选中日期为今天时禁用已过去的小时
function scheduleDisabledHours(fieldKey) {
  if (fieldKey !== 'scheduleTime') return []
  const raw = form[fieldKey]
  if (!raw) return []
  const selected = new Date(raw)
  if (isNaN(selected.getTime())) return []
  const now = new Date()
  if (!_sameDay(selected, now)) return []
  return Array.from({ length: now.getHours() }, (_, i) => i)
}

// disabled-minutes: 选中日期为今天且小时为当前小时时禁用已过去的分钟
function scheduleDisabledMinutes(fieldKey, hour) {
  if (fieldKey !== 'scheduleTime') return []
  const raw = form[fieldKey]
  if (!raw) return []
  const selected = new Date(raw)
  if (isNaN(selected.getTime())) return []
  const now = new Date()
  if (!_sameDay(selected, now) || hour !== now.getHours()) return []
  return Array.from({ length: now.getMinutes() }, (_, i) => i)
}

// ========== 淘宝光合: 关联商品/店铺 picker ==========
// picker 组件可见性 + 配置
const guanghePickerVisible = ref(false)
const guanghePickerMode = ref('product') // 'product' | 'shop'
const guanghePickerFieldKey = ref('') // 当前编辑的字段 key
const guanghePickerAccountId = ref('') // 用于打开浏览器的账号 id(从已勾选账号里挑一个)

// ========== 京东: 关联商品 picker ==========
// picker 组件可见性 + 当前账号 id
const jdPickerVisible = ref(false)
const jdPickerAccountId = ref('')

// 复合字段当前要操作的数据 key(guangheProducts / guangheShops) + 数据列表
const currentGuangheFieldKey = computed(() =>
  form.guangheLinkType === 'shop' ? 'guangheShops' : 'guangheProducts'
)
const currentGuangheItems = computed(() =>
  Array.isArray(form[currentGuangheFieldKey.value]) ? form[currentGuangheFieldKey.value] : []
)

// 从已勾选的账号中任选一个淘宝光合账号(配置 picker 时不需要先选具体账号)
function findAnyGuangheAccountId() {
  for (const id of publishAccountIds) {
    const acc = accountStore.accounts.find(a => String(a.id) === String(id))
    if (acc && acc.platform === '淘宝光合') {
      return String(acc.id)
    }
  }
  // 兜底:未勾选时,从 accountStore 找任一淘宝光合账号
  const anyAcc = accountStore.accounts.find(a => a.platform === '淘宝光合')
  return anyAcc ? String(anyAcc.id) : ''
}

function openGuanghePicker() {
  // mode / field key 由当前 radio 决定
  const mode = form.guangheLinkType === 'shop' ? 'shop' : 'product'
  if (mode !== 'product' && mode !== 'shop') {
    ElMessage.warning('请先选择「商品」或「店铺」')
    return
  }
  const accountId = findAnyGuangheAccountId()
  if (!accountId) {
    ElMessage.warning('请先添加至少一个淘宝光合账号')
    return
  }
  guanghePickerAccountId.value = accountId
  guanghePickerMode.value = mode
  guanghePickerFieldKey.value = mode === 'shop' ? 'guangheShops' : 'guangheProducts'
  guanghePickerVisible.value = true
}

function onGuanghePickerConfirm(names) {
  const key = guanghePickerFieldKey.value
  if (!key) return
  // 用最新选择替换当前字段值(picker 内部已支持回显已选项,确认时返回完整列表)
  form[key] = names
  guanghePickerVisible.value = false
}

function removeGuangheItem(fieldKey, idx) {
  if (!Array.isArray(form[fieldKey])) return
  form[fieldKey] = form[fieldKey].filter((_, i) => i !== idx)
}

// ========== 视频号: 关联剧集 picker 方法 ==========
// 走 channels drama_picker 后端流程(后端启常驻 headless 浏览器 → 开弹窗 → 多次 search/go_page)。
// trace (keyword, page) 存进 channelsDrama[*].trace,发布时 platform.py 按 trace 复现选中。
const channelsDramaPickerVisible = ref(false)
const channelsDramaPickerAccountId = ref('')
const channelsDramaPickerLinkType = ref('drama')

function findAnyChannelsAccountId() {
  if (!publishAccountIds || publishAccountIds.size === 0) return ''
  for (const id of publishAccountIds) {
    const a = accountStore.accounts.find((x) => x.id === id)
    if (a && a.platform === '视频号') return id
  }
  return ''
}

function openChannelsDramaPicker(linkType) {
  const accountId = findAnyChannelsAccountId()
  if (!accountId) {
    ElMessage.warning('请先选择至少一个视频号账号')
    return
  }
  channelsDramaPickerAccountId.value = accountId
  // linkType: 'drama'(视频号剧集) / 'mini_drama'(小程序短剧)
  channelsDramaPickerLinkType.value = linkType === 'mini_drama' ? 'mini_drama' : 'drama'
  channelsDramaPickerVisible.value = true
}

function onChannelsLinkTypeChange(val) {
  // 切换链接类型时清空旧的剧集选择(类型不匹配)
  if (val !== 'drama' && val !== 'mini_drama') {
    form.channelsDrama = []
  }
}

function onChannelsDramaPickerConfirm(items) {
  if (!Array.isArray(items)) return
  form.channelsDrama = items.slice(0, 1)
  channelsDramaPickerVisible.value = false
}

onBeforeUnmount(() => {
  const acc = channelsDramaPickerAccountId.value
  if (acc && channelsDramaPickerVisible.value) {
    channelsDramaApi.close(acc).catch(() => {})
  }
})

// ========== 京东: 关联商品 picker 方法 ==========
function openJdPicker() {
  // 关联挂件数据按账号挂钩,必须选中账号(区域 v-if 已保证 selectedAccountId 非空,这里兜底)
  const accountId = selectedAccountId.value
  if (!accountId) {
    ElMessage.warning('请先选择一个京东账号')
    return
  }
  jdPickerAccountId.value = accountId
  jdPickerVisible.value = true
}

function onJdPickerConfirm(items) {
  form.jdProducts = items
  jdPickerVisible.value = false
}

function removeJdProduct(idx) {
  if (!Array.isArray(form.jdProducts)) return
  form.jdProducts = form.jdProducts.filter((_, i) => i !== idx)
}

// radio 切换时清空对方列表(平台规则: 商品/店铺互斥)
watch(() => form.guangheLinkType, (newType, oldType) => {
  if (newType === oldType) return
  if (newType === 'product') {
    form.guangheShops = []
  } else if (newType === 'shop') {
    form.guangheProducts = []
  }
})

watch(() => form.jdRelatedType, (newType, oldType) => {
  if (newType === oldType) return
  if (newType === 'product') {
    form.jdNovel = ''
    form.jdNovelData = null
  } else if (newType === 'novel') {
    form.jdProducts = []
  }
  // jdRelatedType 是平台级字段:主动写回 platformConfigs,并清掉账号级残留。
  // 否则 watch(form) 的 diff 在值跟平台相同时跳过写回,accountOverrides 里残留
  // 旧的 'novel'/'product',刷新时 resolveAccountConfig 读账号级旧值导致 radio 回跳。
  if (platformConfigs.jingmai) {
    platformConfigs.jingmai.jdRelatedType = newType
  }
  for (const aid of Object.keys(accountOverrides)) {
    if (accountOverrides[aid] && 'jdRelatedType' in accountOverrides[aid]) {
      delete accountOverrides[aid].jdRelatedType
    }
  }
})

function getMergedSettings() {
  const platformKey = selectedPlatform.value
  if (!platformKey) return {}
  const platform = platformConfigs[platformKey] || {}
  if (selectedAccountId.value) {
    const override = accountOverrides[selectedAccountId.value]
    if (override && Object.keys(override).length > 0) {
      // 过滤媒体字段:它们由 currentEditTarget 管理,不应该进 form,
      // 否则 watch(form) 的 diff 会把 null 写回 accountOverrides,覆盖已选的视频/封面
      const pickFormFields = (obj) => Object.fromEntries(
        Object.entries(obj).filter(([k, v]) => !MEDIA_KEYS.has(k))
      )
      return {
        ...pickFormFields(platform),
        ...Object.fromEntries(
          Object.entries(pickFormFields(override))
            .filter(([_, v]) => v !== undefined && v !== '' && v !== false)
        ),
      }
    }
  }
  return { ...platform }
}

// 把 form 同步到「当前选中层级」的合并值（平台/账号切换、视频切换后调用）
function syncFormToMergedSettings() {
  const merged = getMergedSettings()
  for (const key of Object.keys(merged)) {
    form[key] = merged[key]
  }
  for (const key of Object.keys(form)) {
    if (!(key in merged)) {
      delete form[key]
    }
  }
  const platformKey = selectedPlatform.value
  if (platformKey) {
    const platform = platformConfigs[platformKey] || {}
    const fields = platform.settingsFields || []
    for (const field of fields) {
      if (field.type === 'multiSelect' && !Array.isArray(form[field.key])) {
        form[field.key] = []
      }
      if (field.type === 'cascader' && !Array.isArray(form[field.key])) {
        form[field.key] = []
      }
    }
  }
}

watch([selectedPlatform, selectedAccountId], () => {
  syncFormToMergedSettings()
}, { immediate: true })

// 小红书:内容来源声明选「来源转载」时,转载内容不能声明原创 →
// 强制把原创声明还原为「非原创」(false)。切换回自主拍摄/其他声明时由用户重新勾选。
watch(() => form.xhsSourceType, (val) => {
  if (selectedPlatform.value === 'xiaohongshu' && val === 'repost' && form.isOriginal !== false) {
    form.isOriginal = false
    ElMessage.info('已切换为来源转载，原创声明已自动改为非原创')
  }
})

watch(form, (newVal) => {
  const platformKey = selectedPlatform.value
  if (!platformKey) return
  if (!platformConfigs[platformKey]) {
    platformConfigs[platformKey] = {}
  }
  const platform = platformConfigs[platformKey]

  if (selectedAccountId.value) {
    const diff = {}
    for (const key of Object.keys(newVal)) {
      // 跳过媒体字段:它们由 currentEditTarget 管理,不属于 form 表单字段
      if (MEDIA_KEYS.has(key)) continue
      if (newVal[key] !== platform[key]) {
        diff[key] = newVal[key]
      }
    }
    // 用 merge 而不是 replace：保留已上传的视频/封面/图片等媒体字段
    // （这些字段不在 form 里，diff 不会包含它们）
    const existing = accountOverrides[selectedAccountId.value]
    if (Object.keys(diff).length > 0) {
      accountOverrides[selectedAccountId.value] = existing
        ? { ...existing, ...diff }
        : { ...diff }
    }
    // diff 为空时不要 delete！媒体字段可能还在
  } else {
    for (const key of Object.keys(newVal)) {
      platform[key] = newVal[key]
    }
  }
}, { deep: true })

function getAccountName(accountId) {
  const account = accountStore.accounts.find(a => a.id === accountId)
  return account ? account.name : '未知'
}

function resetAccountOverride(accountId) {
  delete accountOverrides[accountId]
  ElMessage.success('已恢复为渠道默认设置')
}

// 上传视频/选素材时按"左侧选中层级"决定 title 填充范围:
//   - 选中账号:仅替换该账号的 title(其它字段保留)
//   - 选中平台:替换所选平台的 title,并替换该平台下所有已勾选账号的 accountOverrides.title
//   - 什么都没选(默认):替换所有平台的 title + 所有已勾选账号的 accountOverrides.title
// 直接绕过 watch(form) 的 diff,避免 diff 跳过更新。
function fillTitleForAccount(accountId, title) {
  const existing = accountOverrides[accountId]
  accountOverrides[accountId] = existing
    ? { ...existing, title }
    : { title }
  if (selectedAccountId.value === accountId) {
    form.title = title
  }
}

function fillTitleForPlatform(platformKey, title) {
  if (platformConfigs[platformKey]) {
    platformConfigs[platformKey].title = title
  }
  // 替换该平台下所有已勾选账号的 accountOverrides.title
  const group = accountGroups.value.find(g => g.key === platformKey)
  if (group) {
    for (const acc of group.accounts) {
      if (!publishAccountIds.has(acc.id)) continue
      const existing = accountOverrides[acc.id]
      accountOverrides[acc.id] = existing
        ? { ...existing, title }
        : { title }
    }
  }
  if (selectedPlatform.value === platformKey && !selectedAccountId.value) {
    form.title = title
  }
}

function fillTitleForAllPlatformsAndAccounts(title) {
  for (const key of Object.keys(platformConfigs)) {
    platformConfigs[key].title = title
  }
  for (const aid of publishAccountIds) {
    if (accountOverrides[aid]) {
      accountOverrides[aid] = { ...accountOverrides[aid], title }
    } else {
      accountOverrides[aid] = { title }
    }
  }
  form.title = title
}

// ========== Auto-save ==========
const currentDraftId = ref(null)
const { hasChanges, startAutoSaveTimer } = useAutoSave(() => saveDraft())

// ========== Tag Input ==========
const tagInput = ref('')

function addTag() {
  const tag = tagInput.value.trim()
  if (!tag) return
  if (!form.tags) form.tags = []
  if (form.tags.includes(tag)) {
    ElMessage.warning('标签已存在')
    return
  }
  if (selectedPlatform.value === 'douyin') {
    const ac = form.activityId?.length || 0
    const tc = form.tags?.length || 0
    if (ac + tc >= 5) {
      ElMessage.warning('官方活动 + 标签最多 5 个')
      return
    }
  }
  if (selectedPlatform.value === 'kuaishou') {
    const tc = form.tags?.length || 0
    if (tc >= 4) {
      ElMessage.warning('快手标签最多 4 个')
      return
    }
  }
  form.tags.push(tag)
  tagInput.value = ''
}

function removeTag(index) {
  form.tags.splice(index, 1)
}

// 自动提取描述中的 #xxx 到标签数组,并从描述中清除 #xxx 字样
// maxTags 反应式跟随 selectedPlatform:抖音 5 个(活动+标签总数),其他平台不限
// 但 description 在切平台/账号时会被覆盖(form 重置),所以挂个 watch 即可
useAutoExtractHashtags({
  form,
  descKey: 'description',
  tagKey: 'tags',
  // 抖音活动+标签总数 ≤ 5;快手标签 ≤ 4;其他平台不限
  maxTags: selectedPlatform.value === 'douyin' ? 5 : (selectedPlatform.value === 'kuaishou' ? 4 : undefined),
  // 抖音:活动数也算占用,需要预留位置;其他平台不预留
  getReservedTagCount: () => (selectedPlatform.value === 'douyin' ? (form.activityId?.length || 0) : 0),
})

// ========== Douyin-specific Methods ==========
function handleDouyinActivityChange(activity) {
  if (activity?.challenge?.length > 0) {
    for (const topic of activity.challenge) {
      if (form.tags && !form.tags.includes(topic)) {
        if ((form.activityId?.length || 0) + (form.tags?.length || 0) >= 5) break
        form.tags.push(topic)
      }
    }
  }
}

function handleDouyinHotspotChange(hotspot) {
  if (hotspot) {
    form.hotspotId = hotspot.word
    form.hotspotData = hotspot
  } else {
    form.hotspotId = ''
    form.hotspotData = null
  }
}

// 抖音关联热点 —— RemoteSearchSelect 数据源(后端搜索模式,必须传 keyword)
async function fetchDouyinHotspots(keyword) {
  const resp = await douyinImageApi.searchHotspot(selectedAccountId.value || '', keyword || '')
  return { list: resp.data?.sentences || [] }
}
// 热点字段映射:word 标题,hot_value 派生热度文案,word_cover.url_list.0 嵌套封面
const douyinHotspotFieldMap = {
  label: 'word',
  key: 'sentence_id',
  desc: (item) => item.hot_value ? `热度 ${formatHotValue(item.hot_value)}` : '',
  cover: 'word_cover.url_list.0'
}
function formatHotValue(value) {
  if (!value) return '0'
  return value >= 10000 ? (value / 10000).toFixed(1) + '万' : String(value)
}

// 京东小说 —— RemoteSearchSelect 数据源(后端搜索模式,必须传 keyword)
async function fetchJdNovels(keyword) {
  const resp = await jdApi.novelSearch(selectedAccountId.value || '', keyword || '')
  return { list: resp.data?.novels || [] }
}
// 小说字段映射:title 书名(做 modelValue label),image 封面,desc 由分类+阅读人数拼出
const jdNovelFieldMap = {
  label: 'title',
  key: 'title',
  desc: (item) => [item.category, item.read_count ? `${item.read_count}人已读` : ''].filter(Boolean).join(' | '),
  cover: 'image'
}
function handleJdNovelChange(novel) {
  if (novel) {
    form.jdNovel = novel.title
    form.jdNovelData = novel
  } else {
    form.jdNovel = ''
    form.jdNovelData = null
  }
}

function handleDouyinTagSelect(tag) {
  if (tag) {
    form.selectedTag = tag
    const m = { poi: 'location', miniapp: 'miniapp', game: 'gamepad', mark: 'mark', film: 'film' }
    form.tagType = m[tag.type] || ''
    form.tagValue = tag.name || tag.id || ''
    ElMessage.success(`标签已选择: ${tag.name}`)
  } else {
    form.selectedTag = null
    form.tagType = ''
    form.tagValue = ''
  }
}

function handleDouyinMixChange(mix) {
  if (mix) {
    form.mixId = mix.mix_name
    form.mixData = mix
  } else {
    form.mixId = ''
    form.mixData = null
  }
}

// 支付宝合集选择回调:把选中的完整对象存到 form.compilationData 便于回显,
// v-model 已把 compilationId 绑定到 form.compilation
function handleAlipayCompilationChange(fieldKey, comp) {
  if (comp) {
    form.compilationData = comp
  } else {
    form.compilationData = null
  }
}

// B站合集 —— RemoteSearchSelect 数据源(前端过滤模式)
async function fetchBiliCollections(keyword) {
  const resp = await biliApi.getCollections(selectedAccountId.value)
  const all = resp.data?.list || []
  const kw = keyword?.trim().toLowerCase()
  return {
    list: kw ? all.filter(c => c.name?.toLowerCase().includes(kw)) : all
  }
}

// 抖音合集(mix)—— RemoteSearchSelect 数据源(前端过滤模式,空关键词清空)
async function fetchDouyinMixes(keyword) {
  const resp = await douyinImageApi.getMixList(selectedAccountId.value)
  const all = resp.data?.mix_list || []
  const kw = keyword?.trim().toLowerCase()
  return {
    list: kw ? all.filter(m => m.mix_name?.toLowerCase().includes(kw)) : all
  }
}

// 支付宝/头条合集(compilation)—— RemoteSearchSelect 数据源(后端搜索模式)
// 按 selectedPlatform 切换 api:头条用 toutiaoApi,其余用 alipayApi
async function fetchCompilation(keyword) {
  const api = selectedPlatform.value === 'toutiao' ? toutiaoApi : alipayApi
  const resp = await api.searchCompilation(selectedAccountId.value, keyword || '')
  return { list: resp.data?.list || [] }
}
// compilation 字段映射:title 主标题,category+total 派生描述,coverUrl 扁平封面
const compilationFieldMap = {
  label: 'title',
  key: 'compilationId',
  desc: (item) => {
    const parts = []
    if (item.category) parts.push(item.category)
    if (item.total != null) parts.push(`${item.total} 个内容`)
    return parts.join(' · ')
  },
  cover: 'coverUrl'
}

// 微博合集 —— RemoteSearchSelect 数据源(后端一次返回全量,前端过滤)
async function fetchWeiboCollections(keyword) {
  const resp = await weiboApi.getCollections(selectedAccountId.value)
  const all = resp.data?.list || []
  const kw = keyword?.trim().toLowerCase()
  return {
    list: kw ? all.filter(c => c.name?.toLowerCase().includes(kw)) : all
  }
}

// 微博合集选择回调
function handleWeiboCollectionChange(col) {
  if (col) {
    form.weiboCollectionData = col
  } else {
    form.weiboCollectionData = null
  }
}

// 微信公众号合集 —— RemoteSearchSelect 数据源(后端一次返回全量,前端过滤)
async function fetchGzhCollections(keyword) {
  const resp = await weixinGzhApi.getCollections(selectedAccountId.value)
  const all = resp.data?.list || []
  const kw = keyword?.trim().toLowerCase()
  return {
    list: kw ? all.filter(c => c.name?.toLowerCase().includes(kw)) : all
  }
}

// 微信公众号合集选择回调
function handleGzhCollectionChange(col) {
  if (col) {
    form.gzhCollectionData = col
  } else {
    form.gzhCollectionData = null
  }
}

// 小红书合集选择回调:v-model 已把 collectionName 绑到 form.collectionName,
// 这里把完整对象(含 id)存到 form.collectionData,并把 id 同步到 form.collectionId
function handleXhsCollectionChange(col) {
  if (col) {
    form.collectionId = col.id || ''
    form.collectionData = col
  } else {
    form.collectionId = ''
    form.collectionData = null
  }
}

// 小红书合集 —— RemoteSearchSelect 数据源与字段映射
// 后端一次返回全量合集,前端按关键词过滤(searchMode=frontend + load-all)
async function fetchXhsCollections(keyword) {
  const resp = await xhsApi.getCollections(selectedAccountId.value)
  const all = resp.data?.list || []
  const kw = keyword?.trim().toLowerCase()
  return {
    list: kw ? all.filter(c => c.name?.toLowerCase().includes(kw)) : all
  }
}
const xhsCollectionFieldMap = {
  label: 'name',
  key: 'id',
  desc: (item) => item.note_num != null
    ? (item.note_num > 0 ? `共 ${item.note_num} 篇` : '暂无内容')
    : ''
}

// 小红书拍摄地点(POI)选择回调:存完整对象到 <key>Data,publishData 取 poi 名称
function handleXhsPoiChange(fieldKey, poi) {
  if (poi) {
    form[fieldKey + 'Data'] = poi
  } else {
    form[fieldKey + 'Data'] = null
  }
}

// B 站合集选择回调:v-model 已把 biliCollectionName 绑到 form,
// 这里把完整对象存到 form.biliCollectionData
function handleBiliCollectionChange(col) {
  if (col) {
    form.biliCollectionData = col
  } else {
    form.biliCollectionData = null
  }
}

// 视频号合集选择回调
function handleChannelsCollectionChange(col) {
  if (col) {
    form.channelsCollectionData = col
  } else {
    form.channelsCollectionData = null
  }
}

// 视频号位置选择回调
function handleChannelsLocationChange(loc) {
  if (loc) {
    form.channelsLocationData = loc
  } else {
    form.channelsLocationData = null
  }
}

// 视频号合集 —— RemoteSearchSelect 数据源(前端过滤模式,后端一次返回全量)
async function fetchChannelsCollections(keyword) {
  const resp = await channelsApi.getCollections(selectedAccountId.value)
  const all = resp.data?.list || []
  const kw = keyword?.trim().toLowerCase()
  return {
    list: kw ? all.filter(c => c.name?.toLowerCase().includes(kw)) : all
  }
}

// 视频号位置 —— RemoteSearchSelect 数据源(后端搜索模式,必须传 keyword)
async function fetchChannelsLocations(keyword) {
  const resp = await channelsApi.getLocations(selectedAccountId.value, keyword || '')
  return { list: resp.data?.list || [] }
}

// 视频号活动 —— RemoteSearchSelect 数据源(后端搜索模式,必须传 keyword)
// DOM: option-item 内 .creator-name(发起人)+ .name(活动名) 两个 span,
// label 拼成「creator-name + 空格 + name」,desc 单放 .name(后端已分好)
async function fetchChannelsActivities(keyword) {
  // 活动是平台级字段:未选账号时退回到该平台第一个账号的 cookie 去搜
  const aid = selectedAccountId.value
    || accountStore.accounts.find(a => a.platform === '视频号')?.id
    || ''
  const resp = await channelsApi.searchActivities(aid, keyword || '')
  return { list: resp.data?.list || [] }
}
const channelsActivityFieldMap = {
  key: 'activity_id',
  label: 'name',
  desc: (item) => item.creator_name ? `发起人: ${item.creator_name}` : ''
}

// 视频号活动选择回调:存完整对象到 form.channelsActivityData
function handleChannelsActivityChange(act) {
  if (act) {
    form.channelsActivityData = act
  } else {
    form.channelsActivityData = null
  }
}

// ========== Init ==========
const firstGroup = accountGroups.value.find(g => g.accounts.length > 0)
if (firstGroup) {
  expandedGroups.value.add(firstGroup.key)
  selectedPlatform.value = firstGroup.key
}

// ========== Dialog State ==========
const accountDialogVisible = ref(false)
const videoUploadDialogVisible = ref(false)
const videoUploadTarget = ref('landscape')
const materialSelectRef = ref(null)
const materialLibraryMode = ref('video')
const materialLibraryCoverTarget = ref('landscape')
const oneClickDialogOpen = ref(false)
const materialLibraryVideoTarget = ref('landscape')

// ========== 批量发布 ==========
const batchConfirmVisible = ref(false)
const batchConfirmRows = ref([])
const batchSubmitting = ref(false)
// 批量发布实时进度弹窗：提交成功后打开（保持原发布交互，不跳发布历史）
const batchProgressVisible = ref(false)
const batchProgressBatchIds = ref([])
const batchProgressFailedNotes = ref([])
// 本次批量间隔（分钟），传给进度弹窗用于显示「下一个视频倒计时」
const batchProgressIntervalMinutes = ref(0)

function goPublishHistoryFromProgress() {
  batchProgressVisible.value = false
  router.push('/publish-history')
}

// ========== 发布前 Cookie 预检 ==========
const prePublishCheckRef = ref(null)
const prePublishCheckVisible = ref(false)

// ========== 批量设 (Batch Set) ==========
const batchSetDialogOpen = ref(false)
const { applyBatchSet } = useBatchSetApply({
  platformConfigs,
  accountOverrides,
  accountChecked,
  accountStore,
})
// 渠道个性化可见平台列表：过滤掉被拉黑的平台
const visiblePlatformsForCustomize = computed(() =>
  platformList.filter(p => !appStore.isPlatformDisabled(p.key))
)

const batchSetPlatforms = computed(() => {
  return visiblePlatformsForCustomize.value.map(p => {
    const platformAccounts = accountStore.accounts.filter(a => a.platform === p.name)
    const selectedCount = platformAccounts.filter(a => publishAccountIds.has(a.id)).length
    return { key: p.key, name: p.name, logo: p.logo, count: selectedCount }
  })
})
function onBatchSetApply(checkedKeys, payload) {
  // 全视频应用：先固化当前视频到队列，再对队列中其余视频的快照逐个全量替换
  // （当前视频走下方 applyBatchSet 的活状态路径，含 form 刷新）
  const allVideos = payload.scope === 'all-videos'
  if (allVideos) {
    syncCurrentIntoQueue()
    videoQueue.value.forEach((snap, i) => {
      if (i === currentVideoIndex.value) return
      if (!snap.platformConfigs) snap.platformConfigs = {}
      if (!snap.accountOverrides) snap.accountOverrides = {}
      applyBatchSet(checkedKeys, payload, {
        platformConfigs: snap.platformConfigs,
        accountOverrides: snap.accountOverrides,
      })
    })
    hasChanges.value = true
  }
  applyBatchSet(checkedKeys, payload)
  // 如果当前查看的渠道在批量设范围内,强制刷新 form (watch [selectedPlatform,...] 不会自动触发)
  if (selectedPlatform.value && checkedKeys.includes(selectedPlatform.value)) {
    const merged = getMergedSettings()
    for (const key of Object.keys(merged)) {
      form[key] = merged[key]
    }
    for (const key of Object.keys(form)) {
      if (!(key in merged)) {
        delete form[key]
      }
    }
  }
  ElMessage.success(allVideos
    ? `已全视频替换 ${videoQueue.value.length} 个视频 · ${checkedKeys.length} 个渠道`
    : `已批量设置到 ${checkedKeys.length} 个渠道`)
}

// Selected accounts
const publishAccountIds = reactive(new Set())

// ========== 视频队列（批量发布） ==========
// 每个队列元素 = 一份完整发布状态快照（与单视频 draft_data 同构，含所选账号/平台设置/个性化）。
// 任意时刻只有 currentVideoIndex 对应的视频是「活状态」（顶层 reactive 对象），
// 其余视频以快照存于 videoQueue；切换视频 = 活状态写回快照 + 目标快照装载进活状态。
const videoQueue = ref([])
const currentVideoIndex = ref(0)
const addVideosDialogVisible = ref(false)

function _slimMaterial(m) {
  return m ? {
    id: m.id, name: m.name, stored_path: m.stored_path, url: m.url,
    size: m.size, type: m.type, _fromFrame: m._fromFrame,
    duration: m.duration, orientation: m.orientation,
  } : null
}

// 活状态 → 快照（与草稿 draft_data 同构）
function snapshotLiveVideo() {
  return {
    commonConfig: {
      videoLandscape: _slimMaterial(commonConfig.videoLandscape),
      videoPortrait: _slimMaterial(commonConfig.videoPortrait),
      coverLandscape: _slimMaterial(commonConfig.coverLandscape),
      coverPortrait: _slimMaterial(commonConfig.coverPortrait),
      coverLandscape169: _slimMaterial(commonConfig.coverLandscape169),
      coverPortrait916: _slimMaterial(commonConfig.coverPortrait916),
    },
    platformConfigs: JSON.parse(JSON.stringify(platformConfigs)),
    platformOverrides: JSON.parse(JSON.stringify(platformOverrides)),
    accountOverrides: JSON.parse(JSON.stringify(accountOverrides)),
    platformChecked: { ...platformChecked },
    accountChecked: { ...accountChecked },
    publishAccountIds: [...publishAccountIds],
    selectedPlatform: selectedPlatform.value,
    selectedAccountId: selectedAccountId.value,
    expandedGroups: [...expandedGroups.value],
  }
}

function _replaceReactiveMap(target, source) {
  Object.keys(target).forEach(k => delete target[k])
  if (source) Object.assign(target, source)
}

// 快照 → 活状态（in-place 赋值保持响应性；与旧 restoreDraft 同一套装载语义 + 旧格式兼容）
function applyVideoSnapshot(dd) {
  dd = dd || {}
  const cc = dd.commonConfig || {}
  for (const key of ['videoLandscape', 'videoPortrait', 'coverLandscape', 'coverPortrait', 'coverLandscape169', 'coverPortrait916']) {
    const v = cc[key]
    if (v && v.stored_path && !v.url) v.url = getFileUrl(v.stored_path)
    commonConfig[key] = v || null
  }

  // 平台表单：默认值 + 快照整键重建（避免上一个视频的值残留）
  const pcs = dd.platformConfigs || {}
  for (const key of Object.keys(DEFAULT_PLATFORM_CONFIGS)) {
    platformConfigs[key] = { ...DEFAULT_PLATFORM_CONFIGS[key], ...(pcs[key] || {}) }
  }

  // —— 旧格式兼容（与原 restoreDraft 一致）——
  // commonConfig.topics 迁移到各平台 tags
  if (cc.topics && cc.topics.length > 0) {
    for (const key of Object.keys(platformConfigs)) {
      if (!platformConfigs[key].tags || platformConfigs[key].tags.length === 0) {
        platformConfigs[key].tags = [...cc.topics]
      }
    }
  }
  // bilibili tags 字符串 → 数组
  if (typeof platformConfigs.bilibili?.tags === 'string') {
    const str = platformConfigs.bilibili.tags
    platformConfigs.bilibili.tags = str.split(/[,，\s]+/).map(t => t.replace(/^#/, '').trim()).filter(Boolean)
  }
  // 为缺少 tags 的平台补空数组
  for (const key of Object.keys(platformConfigs)) {
    if (!Array.isArray(platformConfigs[key].tags)) {
      platformConfigs[key].tags = []
    }
  }
  // 抖音新增字段兜底
  {
    const dy = platformConfigs.douyin
    if (!Array.isArray(dy.activityId)) dy.activityId = []
    if (dy.hotspotId === undefined) dy.hotspotId = ''
    if (dy.hotspotData === undefined) dy.hotspotData = null
    if (dy.selectedTag === undefined) dy.selectedTag = null
    if (dy.tagType === undefined) dy.tagType = ''
    if (dy.tagValue === undefined) dy.tagValue = ''
    if (dy.mixId === undefined) dy.mixId = ''
    if (dy.mixData === undefined) dy.mixData = null
  }
  // 淘宝光合关联商品/店铺兜底 + 字符串数组归一化
  {
    const tg = platformConfigs.taobao_guanghe
    if (tg.guangheLinkType === undefined) tg.guangheLinkType = ''
    if (!Array.isArray(tg.guangheProducts)) tg.guangheProducts = []
    if (!Array.isArray(tg.guangheShops)) tg.guangheShops = []
    const normalize = arr => arr.map(it =>
      typeof it === 'string' ? { title: it, image: '' }
        : { title: it?.title || '', image: it?.image || '' }
    ).filter(it => it.title)
    tg.guangheProducts = normalize(tg.guangheProducts)
    tg.guangheShops = normalize(tg.guangheShops)
  }
  // 京东关联挂件字段兜底
  {
    const jd = platformConfigs.jingmai
    if (jd.jdRelatedType === undefined) jd.jdRelatedType = ''
    if (!Array.isArray(jd.jdProducts)) jd.jdProducts = []
    if (jd.jdNovel === undefined) jd.jdNovel = ''
    if (jd.jdNovelData === undefined) jd.jdNovelData = null
    if (jd.jdDeclaration === undefined) jd.jdDeclaration = ''
  }
  // 清除残留 videoFormat（视频方向由素材 orientation 自动推导）
  for (const key of Object.keys(platformConfigs)) {
    if (platformConfigs[key]) delete platformConfigs[key].videoFormat
  }

  _replaceReactiveMap(accountOverrides, dd.accountOverrides)
  _replaceReactiveMap(platformOverrides, dd.platformOverrides)
  _replaceReactiveMap(platformChecked, dd.platformChecked)
  _replaceReactiveMap(accountChecked, dd.accountChecked)

  publishAccountIds.clear()
  ;(dd.publishAccountIds || []).forEach(id => publishAccountIds.add(id))
  expandedGroups.value = new Set(dd.expandedGroups || [])
  selectedPlatform.value = dd.selectedPlatform || null
  selectedAccountId.value = dd.selectedAccountId || null

  // 平台/账号选中态可能没变（watch 不触发），强制把 form 同步到新视频的合并值
  syncFormToMergedSettings()
}

// 活状态写回队列（切换/保存/提交/校验前调用）
function syncCurrentIntoQueue() {
  videoQueue.value[currentVideoIndex.value] = snapshotLiveVideo()
}

// —— 队列栏展示信息 ——
const liveVideoStateForDisplay = computed(() => ({
  commonConfig,
  platformConfigs,
  publishAccountIds: [...publishAccountIds],
}))

function _videoDisplayInfo(state) {
  const cc = state.commonConfig || {}
  const video = cc.videoLandscape || cc.videoPortrait
  const cover = cc.coverLandscape || cc.coverPortrait
  let title = ''
  let hasSchedule = false
  const pcs = state.platformConfigs || {}
  for (const key of Object.keys(pcs)) {
    if (!title && pcs[key]?.title) title = pcs[key].title
    if (pcs[key]?.scheduleTime) hasSchedule = true
  }
  const accountIds = state.publishAccountIds || []
  return {
    name: video?.name || '未上传视频',
    coverUrl: cover?.url || '',
    title,
    accountCount: accountIds.length,
    hasVideo: !!video,
    hasSchedule,
    warn: !!(video && (!cover || accountIds.length === 0)),
  }
}

const videoQueueItems = computed(() =>
  videoQueue.value.map((snap, i) =>
    _videoDisplayInfo(i === currentVideoIndex.value ? liveVideoStateForDisplay.value : snap)
  )
)

function switchVideo(index) {
  if (index === currentVideoIndex.value) return
  if (index < 0 || index >= videoQueue.value.length) return
  syncCurrentIntoQueue()
  currentVideoIndex.value = index
  applyVideoSnapshot(videoQueue.value[index])
  // 清临时 UI 状态并重抽帧（封面编辑器用，横竖共用）
  tagInput.value = ''
  landscapeFrames.value = []
  portraitFrames.value = []
  const draftVideo = commonConfig.videoLandscape || commonConfig.videoPortrait
  if (draftVideo) triggerFrameExtraction(draftVideo, 'landscape')
  hasChanges.value = true
}

// —— 添加视频（来源由用户选择：素材库多选 / 本地多文件上传，均继承当前配置）——
const queueMaterialSelectRef = ref(null)

function openAddVideosDialog(mode) {
  if (mode === 'library') {
    queueMaterialSelectRef.value?.open()
  } else {
    addVideosDialogVisible.value = true
  }
}

// 素材库多选回调：映射为与上传响应同构的数据，复用 onVideosAdded 入队逻辑
async function onQueueMaterialsSelected(materials) {
  const list = (Array.isArray(materials) ? materials : [materials]).filter(Boolean)
  if (list.length === 0) return
  // 去重：跳过已在队列中的同一素材，避免误重复发布
  syncCurrentIntoQueue()
  const queuedIds = new Set(
    videoQueue.value
      .map(v => v.commonConfig?.videoLandscape?.id || v.commonConfig?.videoPortrait?.id)
      .filter(Boolean)
  )
  const fresh = list.filter(m => !queuedIds.has(m.id))
  const dupCount = list.length - fresh.length
  if (fresh.length === 0) {
    ElMessage.warning('所选视频都已在队列中')
    return
  }
  const responses = fresh.map(m => ({
    id: m.id,
    original_filename: m.name,
    stored_path: m.stored_path,
    file_size: m.size,
    mime_type: m.type,
    duration: m.duration ?? 0,
  }))
  await onVideosAdded(responses)
  if (dupCount > 0) {
    ElMessage.info(`${dupCount} 个视频已在队列中，已跳过`)
  }
}

async function onVideosAdded(responses) {
  addVideosDialogVisible.value = false
  const list = (responses || []).filter(Boolean)
  if (list.length === 0) return
  syncCurrentIntoQueue()
  const base = JSON.parse(JSON.stringify(videoQueue.value[currentVideoIndex.value] || {}))
  const firstNewIndex = videoQueue.value.length
  for (const d of list) {
    const videoData = {
      id: d.id,
      name: d.original_filename,
      url: getFileUrl(d.stored_path),
      stored_path: d.stored_path,
      size: d.file_size,
      type: d.mime_type,
      duration: d.duration ?? 0,
    }
    const snap = JSON.parse(JSON.stringify(base))
    snap.commonConfig = snap.commonConfig || {}
    snap.commonConfig.videoLandscape = _slimMaterial(videoData)
    snap.commonConfig.videoPortrait = null
    // 清封面，后台自动抽帧补默认封面
    snap.commonConfig.coverLandscape = null
    snap.commonConfig.coverPortrait = null
    snap.commonConfig.coverLandscape169 = null
    snap.commonConfig.coverPortrait916 = null
    // 标题自动填文件名（autoFillTitle 开启时），平台级 + 账号级覆盖
    if (appStore.autoFillTitle) {
      const title = videoData.name.replace(/\.[^.]+$/, '')
      const pcs = snap.platformConfigs || {}
      for (const key of Object.keys(pcs)) {
        if (pcs[key]) pcs[key].title = title
      }
      const aos = snap.accountOverrides || {}
      for (const aid of Object.keys(aos)) {
        if (aos[aid]) aos[aid].title = title
      }
    }
    videoQueue.value.push(snap)
  }
  ElMessage.success(`已添加 ${list.length} 个视频（已继承当前配置）`)
  // 切到最后添加的视频
  switchVideo(videoQueue.value.length - 1)
  // 后台为每个新视频抽帧选默认封面
  for (let k = 0; k < list.length; k++) {
    autoCoverForVideo(firstNewIndex + k, list[k])
  }
}

// —— 自动默认封面 ——
// 选帧策略：优先「前面 1~5 秒」窗口内最接近 3s 的帧（避开 0s 处常见黑帧/
// 转场，也符合封面取片头画面的习惯）；视频过短没有该区间帧时退回第一帧。
function pickAutoCoverFrame(frames) {
  const inWindow = frames.filter(f => f.seconds >= 1 && f.seconds <= 5)
  if (inWindow.length > 0) {
    return inWindow.reduce((best, f) =>
      Math.abs(f.seconds - 3) < Math.abs(best.seconds - 3) ? f : best)
  }
  return frames[0]
}

// 公共：等待抽帧完成 → 取「前面 1~5 秒」中最接近 3s 的帧 → save-cover 生成 4 比例封面。失败返回 null。
// onStage?: (stage: 'extracting' | 'saving') => void — 通知调用方当前阶段，
// 用于 CoverCard「裁剪中…」文案展示。
async function fetchAutoCovers(materialId, onStage) {
  if (!materialId) return null
  try {
    onStage?.('extracting')
    let frames = []
    for (let attempt = 0; attempt < 15; attempt++) {
      try {
        const resp = await frameApi.getFrames(materialId)
        const data = resp?.data || {}
        frames = data.frames || []
        if (data.status === 'done' && frames.length > 0) break
      } catch { /* 素材探测中等，继续重试 */ }
      await frameApi.extractFrames(materialId).catch(() => {})
      await new Promise(r => setTimeout(r, 2500))
    }
    if (!frames.length) return null
    const pick = pickAutoCoverFrame(frames)
    if (!pick || pick.seconds === undefined || pick.seconds === null) return null
    onStage?.('saving')
    const resp = await http.post('/api/frames/save-cover', {
      material_id: materialId,
      seconds: pick.seconds,
    })
    const d = resp?.data
    if (!d?.landscape_43) return null
    // 后端按 4 个比例中心裁剪，前端分别填入对应字段（与手动裁剪结果同构）
    const toCover = c => c ? {
      id: c.id, name: c.original_filename, url: getFileUrl(c.stored_path),
      stored_path: c.stored_path, size: c.file_size, type: c.mime_type,
    } : null
    return {
      coverLandscape: toCover(d.landscape_43),
      coverLandscape169: toCover(d.landscape_169),
      coverPortrait: toCover(d.portrait_34),
      coverPortrait916: toCover(d.portrait_916),
    }
  } catch (e) {
    console.warn('[自动封面] 生成失败（可手动设置）:', e)
    return null
  }
}

// 队列快照版：为队列中指定下标的视频自动补默认封面（添加视频到队列后调用）
async function autoCoverForVideo(index, materialData) {
  const covers = await fetchAutoCovers(materialData?.id)
  if (!covers) return
  const snap = videoQueue.value[index]
  // 队列索引可能已漂移（视频被移除/提交）：校验素材 ID 仍匹配才写入
  if (!snap || snap.commonConfig?.videoLandscape?.id !== materialData.id) return
  // 用户已手动设置封面时不覆盖
  if (snap.commonConfig.coverLandscape || snap.commonConfig.coverPortrait) return
  Object.assign(snap.commonConfig, covers)
  if (index === currentVideoIndex.value
      && !commonConfig.coverLandscape && !commonConfig.coverPortrait) {
    Object.assign(commonConfig, covers)
  }
}

// 换视频时清掉旧封面：旧封面属于旧视频，留着会把 autoCoverForLiveVideo 挡住
// （它见已有封面就跳过），导致换视频后封面还是上一条的。用 assign 回调包住视频
// 字段写入，前后对比「当前视频」是否变化，变了才清 4 个比例的封面字段。
function replaceVideoWithCoverReset(target, assign) {
  const oldVideo = target?.videoLandscape || target?.videoPortrait
  assign()
  const newVideo = target?.videoLandscape || target?.videoPortrait
  if (oldVideo?.id === newVideo?.id) return
  target.coverLandscape = null
  target.coverLandscape169 = null
  target.coverPortrait = null
  target.coverPortrait916 = null
}

// 活状态版：发布页主区域上传/素材库选视频后，自动补默认封面到 currentEditTarget
async function autoCoverForLiveVideo(videoData) {
  const target = currentEditTarget.value   // 捕获当前编辑目标（视频写到哪，封面写到哪）
  if (!target || !videoData?.id) return
  // 翻起「裁剪中…」状态，让 CoverCard 显示旋转图标 + 进度文案
  isCoverCropping.value = true
  try {
    const covers = await fetchAutoCovers(videoData.id, (stage) => {
      coverCropStage.value = stage
    })
    if (!covers) return
    // 期间用户已手动设置封面，或又换了别的视频 → 不写入
    if (target.coverLandscape || target.coverPortrait) return
    const curVideo = target.videoLandscape || target.videoPortrait
    if (curVideo?.id !== videoData.id) return
    Object.assign(target, covers)
  } finally {
    isCoverCropping.value = false
    coverCropStage.value = ''
  }
}

function removeVideoAt(index) {
  if (videoQueue.value.length <= 1) {
    ElMessage.warning('至少保留一个视频')
    return
  }
  if (index === currentVideoIndex.value) {
    videoQueue.value.splice(index, 1)
    const next = Math.min(index, videoQueue.value.length - 1)
    applyVideoSnapshot(videoQueue.value[next])
    currentVideoIndex.value = next
    tagInput.value = ''
    landscapeFrames.value = []
    portraitFrames.value = []
    const draftVideo = commonConfig.videoLandscape || commonConfig.videoPortrait
    if (draftVideo) triggerFrameExtraction(draftVideo, 'landscape')
  } else {
    videoQueue.value.splice(index, 1)
    if (index < currentVideoIndex.value) currentVideoIndex.value -= 1
  }
  hasChanges.value = true
}

// 初始队列：1 个空白视频（与旧单视频页面一致）
videoQueue.value = [snapshotLiveVideo()]

// ========== Sidebar Methods ==========

function toggleGroup(key) {
  if (expandedGroups.value.has(key)) {
    // 再次点击已展开的平台:收起并取消平台选中
    expandedGroups.value.delete(key)
    if (selectedPlatform.value === key) {
      selectedPlatform.value = null
    }
  } else {
    // 互斥展开:收起所有其它平台,只展开当前平台,并设为选中
    expandedGroups.value.clear()
    expandedGroups.value.add(key)
    selectedPlatform.value = key
  }
  selectedAccountId.value = null
}

function removePublishAccount(id) {
  publishAccountIds.delete(id)
  hasChanges.value = true
}

function selectAccount(account, group) {
  selectedAccountId.value = account.id
  selectedPlatform.value = group.key
  // 互斥展开:只展开账号所属平台
  expandedGroups.value.clear()
  expandedGroups.value.add(group.key)
}

// ========== Account Dialog ==========

function onAccountConfirm(ids) {
  publishAccountIds.clear()
  ids.forEach(id => {
    publishAccountIds.add(id)
  })
  hasChanges.value = true
  ElMessage.success(`已选择 ${ids.length} 个账号`)
}

// ========== Upload Methods ==========

function triggerUploadVideo() {
  // 统一上传入口:写入主字段 videoLandscape(onVideoUploaded 内固定)
  videoUploadTarget.value = 'landscape'
  videoUploadDialogVisible.value = true
}

function clearVideo() {
  // 移除横竖区分:同时清两个视频字段
  currentEditTarget.value.videoLandscape = null
  currentEditTarget.value.videoPortrait = null
}

// ========== Cover Editor ==========

// 当前激活 tab 对应的封面对象（按 orientation + ratio 路由到 4 个字段之一）
const coverPortraitActiveCover = computed(() => {
  const t = currentEditTarget.value
  if (!t) return null
  return coverPortraitActiveRatio.value === '9:16' ? t.coverPortrait916 : t.coverPortrait
})
const coverLandscapeActiveCover = computed(() => {
  const t = currentEditTarget.value
  if (!t) return null
  return coverLandscapeActiveRatio.value === '16:9' ? t.coverLandscape169 : t.coverLandscape
})

// 移除/更新当前激活 tab 的封面（v-model 回调）
function onPortraitCoverChange(v) {
  const t = currentEditTarget.value
  if (!t) return
  if (coverPortraitActiveRatio.value === '9:16') t.coverPortrait916 = v
  else t.coverPortrait = v
}
function onLandscapeCoverChange(v) {
  const t = currentEditTarget.value
  if (!t) return
  if (coverLandscapeActiveRatio.value === '16:9') t.coverLandscape169 = v
  else t.coverLandscape = v
}

function openCoverEditor(orientation = 'landscape', _ratio) {
  coverEditOrientation.value = orientation
  // 弹窗侧 CoverEditorDialog 不感知 ratio，保持原默认（orientation 主尺寸）打开；
  // 用户进入弹窗后可自行切换 9:16 / 16:9 tab 编辑。
  coverEditorRef.value?.open(orientation)
}

function triggerFrameExtraction(videoData, type) {
  if (!videoData?.id) return
  const doExtract = async () => {
    try {
      const resp = await frameApi.extractFrames(videoData.id)
      if (resp.data) {
        const allFrames = resp.data.frames || []
        const recommended = pickRecommendedFrames(allFrames, 6)
        if (type === 'landscape') landscapeFrames.value = recommended
        else portraitFrames.value = recommended
      }
    } catch (e) {
      console.error('Frame extraction failed:', e)
    }
  }
  doExtract()
}

function pickRecommendedFrames(frames, count) {
  if (frames.length <= count) return frames
  const result = [frames[0]]
  for (let i = 1; i < count - 1; i++) {
    const idx = Math.round((frames.length - 1) * i / (count - 1))
    result.push(frames[idx])
  }
  result.push(frames[frames.length - 1])
  return result
}

async function onVideoUploaded(d) {
  const videoData = {
    id: d.id,
    name: d.original_filename,
    url: getFileUrl(d.stored_path),
    stored_path: d.stored_path,
    size: d.file_size,
    type: d.mime_type,
    duration: d.duration ?? 0,
  }
  if (videoUploadTarget.value === 'portrait') {
    replaceVideoWithCoverReset(currentEditTarget.value, () => {
      currentEditTarget.value.videoPortrait = videoData
    })
  } else {
    replaceVideoWithCoverReset(currentEditTarget.value, () => {
      currentEditTarget.value.videoLandscape = videoData
    })
  }
  videoUploadDialogVisible.value = false
  ElMessage.success('视频上传成功')
  if (appStore.autoFillTitle) {
    const title = videoData.name.replace(/\.[^.]+$/, '')
    if (selectedAccountId.value) {
      // 选中账号:仅替换该账号的 title
      fillTitleForAccount(selectedAccountId.value, title)
    } else if (selectedPlatform.value) {
      // 选中平台:替换所选平台 + 该平台下所有已勾选账号的 title
      fillTitleForPlatform(selectedPlatform.value, title)
    } else {
      // 什么都没选(默认):全量替换所有平台 + 所有已勾选账号的 title
      fillTitleForAllPlatformsAndAccounts(title)
    }
  }
  triggerFrameExtraction(videoData, videoUploadTarget.value)
  // 后台自动补默认封面（4 比例，可手动替换）
  autoCoverForLiveVideo(videoData)
}

// ========== Material Library ==========

async function selectFromLibrary(mode = 'video', videoOrCoverTarget = 'landscape') {
  materialLibraryMode.value = mode
  if (mode === 'video') {
    materialLibraryVideoTarget.value = videoOrCoverTarget
  } else {
    materialLibraryCoverTarget.value = videoOrCoverTarget
  }
  materialsApi.list({ page_size: 200 }).then((response) => {
    if (response.code === 200) {
      appStore.setMaterials(response.data.items || [])
    }
  }).catch((err) => console.error('预拉素材列表出错:', err))
  materialSelectRef.value?.open()
}

function onMaterialSelect(material) {
  // 公共区域选素材：写入 currentEditTarget（默认=commonConfig, 勾选=覆写对象）
  if (materialLibraryMode.value === 'cover') {
    if (materialLibraryCoverTarget.value === 'portrait') {
      currentEditTarget.value.coverPortrait = material
    } else {
      currentEditTarget.value.coverLandscape = material
    }
    ElMessage.success('封面已设置')
  } else {
    if (materialLibraryVideoTarget.value === 'portrait') {
      replaceVideoWithCoverReset(currentEditTarget.value, () => {
        currentEditTarget.value.videoPortrait = material
      })
    } else {
      replaceVideoWithCoverReset(currentEditTarget.value, () => {
        currentEditTarget.value.videoLandscape = material
      })
    }
    ElMessage.success('视频已设置')
    if (appStore.autoFillTitle) {
      const title = material.name.replace(/\.[^.]+$/, '')
      if (selectedAccountId.value) {
        // 选中账号:仅替换该账号的 title
        fillTitleForAccount(selectedAccountId.value, title)
      } else if (selectedPlatform.value) {
        // 选中平台:替换所选平台 + 该平台下所有已勾选账号的 title
        fillTitleForPlatform(selectedPlatform.value, title)
      } else {
        // 什么都没选(默认):全量替换所有平台 + 所有已勾选账号的 title
        fillTitleForAllPlatformsAndAccounts(title)
      }
    }
    triggerFrameExtraction(material, materialLibraryVideoTarget.value)
    // 后台自动补默认封面（4 比例，可手动替换）
    autoCoverForLiveVideo(material)
  }
}

// Watch content changes
watch(commonConfig, () => { hasChanges.value = true }, { deep: true })
watch(platformConfigs, () => { hasChanges.value = true }, { deep: true })
watch(accountOverrides, () => { hasChanges.value = true }, { deep: true })

// ========== Publish Methods ==========

async function saveDraft() {
  try {
    // 活状态写回队列后整队列序列化（v2 批量草稿结构）
    syncCurrentIntoQueue()
    const draftData = {
      version: 2,
      currentIndex: currentVideoIndex.value,
      videos: videoQueue.value.map(v => JSON.parse(JSON.stringify(v))),
    }

    if (currentDraftId.value) {
      await draftApi.updateDraft(currentDraftId.value, { draft_data: draftData })
      ElMessage.success('草稿已更新')
    } else {
      const resp = await draftApi.createDraft({ draft_data: draftData })
      currentDraftId.value = resp.data.id
      ElMessage.success('草稿已保存')
    }
  } catch (e) {
    ElMessage.error('草稿保存失败')
  }
}

async function restoreDraft(draftId) {
  try {
    const resp = await draftApi.getDraft(draftId)
    const data = resp.data
    const dd = data.draft_data
    if (!dd) {
      ElMessage.error('草稿数据为空')
      return
    }

    // v2 批量草稿：videos[] 整队列恢复；v1 单视频草稿：包装成单元素队列
    let videosData
    let currentIndex = 0
    if (Array.isArray(dd.videos) && dd.videos.length > 0) {
      videosData = dd.videos
      currentIndex = Math.min(dd.currentIndex || 0, videosData.length - 1)
    } else {
      videosData = [dd]
      currentIndex = 0
    }

    videoQueue.value = videosData.map(v => JSON.parse(JSON.stringify(v || {})))
    currentVideoIndex.value = currentIndex
    applyVideoSnapshot(videoQueue.value[currentIndex])

    currentDraftId.value = draftId

    // 视频已不区分横竖版：只对当前视频抽帧一次（横版优先，没有才竖版），
    // 横竖版共用同一份帧缓存；避免对旧草稿里可能残留的失效 videoPortrait.id 重复抽帧触发"素材失效"提示。
    const draftVideo = commonConfig.videoLandscape || commonConfig.videoPortrait
    if (draftVideo) {
      triggerFrameExtraction(draftVideo, 'landscape')
    }

    ElMessage.success(`草稿已恢复（${videoQueue.value.length} 个视频）`)
  } catch (e) {
    ElMessage.error('草稿恢复失败')
  }
}

onMounted(async () => {
  // 加载账号列表
  try {
    const res = await accountApi.getAccounts()
    accountStore.setAccounts(res.data)
  } catch (e) {
    console.error('加载账号列表失败:', e)
  }

  // 加载标签列表(确保「选择账号」弹窗内的标签筛选可用)
  accountStore.loadTags()

  // 清理 publishAccountIds 中属于黑名单平台的账号（本地清理，不写后端）
  // Set 是发布页内存状态，重建一个新的 Set 来剔除被拉黑平台的账号
  const filteredIds = new Set()
  for (const id of publishAccountIds) {
    const acc = accountStore.accounts.find(a => a.id === id)
    if (!acc) continue
    const key = platformNameToKey[acc.platform]
    if (key && !appStore.isPlatformDisabled(key)) {
      filteredIds.add(id)
    }
  }
  publishAccountIds.clear()
  filteredIds.forEach(id => publishAccountIds.add(id))

  const draftId = route.query.draft
  if (draftId) {
    restoreDraft(Number(draftId))
  }
  startAutoSaveTimer()
})

// ========== 批量发布：逐视频校验 + 提交 ==========
// 与后端 merge_config 同语义：对任意视频快照做 4 级合并（accountOv > platformOv > platformDefault > common）
function resolveAccountConfigFor(state, platformKey, accountId) {
  const accountOv = state.accountOverrides?.[accountId] || null
  const platformOv = state.platformOverrides?.[platformKey] || null
  const platformDefault = state.platformConfigs?.[platformKey] || null
  return mergeConfig(state.commonConfig || {}, platformDefault, platformOv, accountOv)
}

const _DECLARATION_PLATFORMS = {
  xiaohongshu: 'aiContent',
  douyin: 'aiContent',
  kuaishou: 'aiContent',
  bilibili: 'creationDeclaration',
  baijiahao: 'creationDeclaration',
  tencent_video: 'creationDeclaration',
  iqiyi: 'creationDeclaration',
  youtube: ['audience', 'alteredContent'],
  tiktok: 'aiContent',
  weibo: 'contentStatement',
  alipay: 'authorStatement',
  taobao_guanghe: 'guangheClaim',
  dayu: 'creationDeclaration',
  // channels 不必填
}

// 单个视频快照的发布前校验（collect-all）：返回错误消息数组（空数组 = 通过）。
// 由旧 publishAll 的校验段移植，参数化为快照状态。
function collectVideoErrors(state) {
  const publishIds = state.publishAccountIds || []
  const cc = state.commonConfig || {}
  const pOvs = state.platformOverrides || {}
  const aOvs = state.accountOverrides || {}
  const errors = []  // [{ type, accounts: [...] }]

  // 1. 视频文件（扫 3 个源，个性化模式下视频可能在 override 里）
  const hasAnyVideo = !!(cc.videoLandscape || cc.videoPortrait)
    || Object.values(aOvs).some(ov => ov && (ov.videoLandscape || ov.videoPortrait))
    || Object.values(pOvs).some(ov => ov && (ov.videoLandscape || ov.videoPortrait))
  if (!hasAnyVideo) {
    return ['缺少视频文件']
  }

  // 2. 至少一张封面（扫 3 个源）
  const hasAnyCover = !!(cc.coverLandscape || cc.coverPortrait)
    || Object.values(aOvs).some(ov => ov && (ov.coverLandscape || ov.coverPortrait))
    || Object.values(pOvs).some(ov => ov && (ov.coverLandscape || ov.coverPortrait))
  if (!hasAnyCover) {
    errors.push({ type: '封面', accounts: ['所有账号都缺封面，请上传至少一张'] })
  }

  // 3. 逐账号校验（声明/标题/封面/时长/字数/平台专属）
  const accountsWithoutDeclaration = []
  const accountsWithoutRepostSource = []
  const accountsWithoutReprintUrl = []
  const accountsWithoutDayuRepostUrl = []
  const accountsWithoutTitle = []
  const accountsWithoutCover = []
  const accountsVideoInvalid = []

  for (const group of accountGroups.value) {
    if (group.accounts.length === 0) continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, group.key, account.id)
      const platformKey = group.key

      // 3a. 作品声明
      const declFields = _DECLARATION_PLATFORMS[platformKey]
      if (declFields) {
        const fields = Array.isArray(declFields) ? declFields : [declFields]
        for (const field of fields) {
          const value = merged[field]
          const isEmpty = Array.isArray(value)
            ? value.length === 0
            : (typeof value === 'boolean' ? value === null || value === undefined : (!value && value !== 0))
          if (isEmpty) {
            accountsWithoutDeclaration.push(`${account.name}(${group.name})`)
            break
          }
        }
      }

      // 3a-bonus. B 站联动校验: 创作声明=转载 时, 转载来源必填
      if (platformKey === 'bilibili' && merged.creationDeclaration === '内容为转载') {
        if (!merged.biliRepostSource || !merged.biliRepostSource.trim()) {
          accountsWithoutRepostSource.push(`${account.name}(${group.name})`)
        }
      }

      // 3a-bonus-2. 支付宝联动校验: 作者声明=内容为转载 时, 转载来源地址必填
      if (platformKey === 'alipay' && merged.authorStatement === '内容为转载') {
        if (!merged.reprintUrl || !merged.reprintUrl.trim()) {
          accountsWithoutReprintUrl.push(`${account.name}(${group.name})`)
        }
      }

      // 3a-bonus-3. 大鱼号联动校验: 信息来源=转载 时, 原文链接必填
      if (platformKey === 'dayu' && merged.creationDeclaration === '转载') {
        if (!merged.dayuRepostUrl || !merged.dayuRepostUrl.trim()) {
          accountsWithoutDayuRepostUrl.push(`${account.name}(${group.name})`)
        }
      }

      // 3b. 标题
      if (!merged.title || !merged.title.trim()) {
        accountsWithoutTitle.push(`${account.name}(${group.name})`)
      }

      // 3c. 封面 per-account(横竖任一即可)
      if (!merged.coverLandscape && !merged.coverPortrait) {
        accountsWithoutCover.push(`${account.name}(${group.name})`)
      }
    }
  }

  if (accountsWithoutDeclaration.length > 0) errors.push({ type: '作品声明', accounts: accountsWithoutDeclaration })
  if (accountsWithoutRepostSource.length > 0) errors.push({ type: '转载来源(B站)', accounts: accountsWithoutRepostSource })
  if (accountsWithoutReprintUrl.length > 0) errors.push({ type: '转载来源(支付宝)', accounts: accountsWithoutReprintUrl })
  if (accountsWithoutDayuRepostUrl.length > 0) errors.push({ type: '原文链接(大鱼号)', accounts: accountsWithoutDayuRepostUrl })
  if (accountsWithoutTitle.length > 0) errors.push({ type: '标题', accounts: accountsWithoutTitle })
  if (accountsWithoutCover.length > 0) errors.push({ type: '封面', accounts: accountsWithoutCover })

  // 4. 视频时长/大小 + 标题/简介长度校验
  for (const group of accountGroups.value) {
    if (group.accounts.length === 0) continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, group.key, account.id)
      const platformKey = group.key

      // 取有效视频:横版优先,无则竖版
      const video = merged.videoLandscape || merged.videoPortrait

      if (!video || !video.duration || video.duration === 0) {
        // 未上传视频的账号：跳过（必填标题会先拦住）
        continue
      }

      // 标题长度校验（如小红书 ≤ 20 字）。京东标题有专属校验块，排除避免重复归类。
      if (platformKey !== 'jingmai') {
        const titleResult = validateTitleForPlatform(platformKey, merged.title)
        if (!titleResult.ok) {
          accountsVideoInvalid.push(`${account.name}(${group.name}): ${titleResult.error}`)
        }
      }

      // 简介长度校验（B 站 ≤ 2000 字,emoji 按 3 算）
      if (platformKey === 'bilibili') {
        const descResult = validateDescForPlatform('bilibili', merged.description || '')
        if (!descResult.ok) {
          accountsVideoInvalid.push(`${account.name}(${group.name}): ${descResult.error}`)
        }
      }

      const result = validateVideoForPlatform(platformKey, video.duration, video.size || 0)
      if (!result.ok) {
        accountsVideoInvalid.push(`${account.name}(${group.name}): ${result.error}`)
      }
    }
  }
  if (accountsVideoInvalid.length > 0) {
    errors.push({ type: '视频校验', accounts: accountsVideoInvalid })
  }

  // ===== 爱奇艺专属校验:标题 ≤30 字符、描述+标签 ≤450 字符(emoji 按 3 算) =====
  const iqiyiTitleAccounts = []
  const iqiyiDescAccounts = []
  for (const group of accountGroups.value) {
    if (group.key !== 'iqiyi') continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, 'iqiyi', account.id)

      const titleChars = countCharsWithEmoji(merged.title || '')
      if (titleChars > 30) {
        iqiyiTitleAccounts.push(`${account.name}(爱奇艺) 标题 ${titleChars} 字符,超过 30`)
      }

      const desc = merged.description || ''
      const tags = merged.tags || []
      const parts = [desc]
      if (tags.length > 0) parts.push(tags.map(t => `#${t}`).join(' '))
      const full = parts.filter(Boolean).join(' ').trim()
      const charCount = countCharsWithEmoji(full)
      if (charCount > 450) {
        iqiyiDescAccounts.push(`${account.name}(爱奇艺) 描述+标签共 ${charCount} 字符,超过 450`)
      }
    }
  }
  if (iqiyiTitleAccounts.length > 0) errors.push({ type: '爱奇艺标题', accounts: iqiyiTitleAccounts })
  if (iqiyiDescAccounts.length > 0) errors.push({ type: '爱奇艺描述/标签', accounts: iqiyiDescAccounts })

  // ===== 百家号专属校验:描述+标签总字符 ≤ 50(emoji 按 3 算),最多 10 标签 =====
  const baijiahaoAccountsNoTag = []
  for (const group of accountGroups.value) {
    if (group.key !== 'baijiahao') continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, 'baijiahao', account.id)
      const desc = merged.description || ''
      const tags = merged.tags || []
      if (tags.length > 10) {
        baijiahaoAccountsNoTag.push(`${account.name}(百家号) 最多 10 个标签,当前 ${tags.length} 个`)
        continue
      }
      const parts = [desc]
      if (tags.length > 0) parts.push(tags.map(t => `#${t}`).join(' '))
      const full = parts.filter(Boolean).join(' ').trim()
      let charCount = 0
      for (const ch of full) {
        charCount += ch.codePointAt(0) > 0xFFFF ? 3 : 1
      }
      if (charCount > 50) {
        baijiahaoAccountsNoTag.push(`${account.name}(百家号) 描述+标签共 ${charCount} 字符,超过 50`)
      }
    }
  }
  if (baijiahaoAccountsNoTag.length > 0) {
    errors.push({ type: '百家号描述/标签', accounts: baijiahaoAccountsNoTag })
  }

  // ===== 京东专属校验:标题 5~27 字(emoji 按 3 算) =====
  const jdAccountsTitleInvalid = []
  for (const group of accountGroups.value) {
    if (group.key !== 'jingmai') continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, 'jingmai', account.id)
      const titleResult = validateTitleForPlatform('jingmai', merged.title || '')
      if (!titleResult.ok) {
        jdAccountsTitleInvalid.push(`${account.name}(京麦): ${titleResult.error}`)
      }
    }
  }
  if (jdAccountsTitleInvalid.length > 0) {
    errors.push({ type: '京东标题', accounts: jdAccountsTitleInvalid })
  }

  // ===== 抖音专属校验:话题总数 ≤ 5(描述 #xxx + 官方活动 + 标签) =====
  const douyinAccountsTooManyTopics = []
  for (const group of accountGroups.value) {
    if (group.key !== 'douyin') continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, 'douyin', account.id)
      const dh = countDescriptionHashtags(merged.description)
      const ac = (merged.activityId || []).length
      const tc = (merged.tags || []).length
      const total = dh + ac + tc
      if (total > 5) {
        douyinAccountsTooManyTopics.push(
          `${account.name}(抖音) 话题 ${total} 个超过 5 个(描述#${dh} + 活动${ac} + 标签${tc})`
        )
      }
    }
  }
  if (douyinAccountsTooManyTopics.length > 0) {
    errors.push({ type: '抖音话题', accounts: douyinAccountsTooManyTopics })
  }

  // ===== 小红书专属校验:话题总数 ≤ 10(描述 #xxx + 标签) =====
  const xhsAccountsTooManyTopics = []
  for (const group of accountGroups.value) {
    if (group.key !== 'xiaohongshu') continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, 'xiaohongshu', account.id)
      const dh = countDescriptionHashtags(merged.description)
      const tc = (merged.tags || []).length
      const total = dh + tc
      if (total > 10) {
        xhsAccountsTooManyTopics.push(
          `${account.name}(小红书) 话题 ${total} 个超过 10 个(描述#${dh} + 标签${tc})`
        )
      }
    }
  }
  if (xhsAccountsTooManyTopics.length > 0) {
    errors.push({ type: '小红书话题', accounts: xhsAccountsTooManyTopics })
  }

  // ===== 快手专属校验:标签 ≤ 4 个 =====
  const kuaishouAccountsTooManyTags = []
  for (const group of accountGroups.value) {
    if (group.key !== 'kuaishou') continue
    for (const account of group.accounts) {
      if (!publishIds.includes(account.id)) continue
      const merged = resolveAccountConfigFor(state, 'kuaishou', account.id)
      const tc = (merged.tags || []).length
      if (tc > 4) {
        kuaishouAccountsTooManyTags.push(`${account.name}(快手) 标签最多 4 个,当前 ${tc} 个`)
      }
    }
  }
  if (kuaishouAccountsTooManyTags.length > 0) {
    errors.push({ type: '快手标签', accounts: kuaishouAccountsTooManyTags })
  }

  // 压缩成字符串数组（确认弹窗展开行展示用）
  return errors.map(e => {
    const list = e.accounts || [e.type]
    const shown = list.length > 3
      ? list.slice(0, 3).join('、') + ` 等 ${list.length} 项`
      : list.join('、')
    return `【${e.type}】${shown}`
  })
}

// 点「批量发布」：逐视频校验 → Cookie 预检（通过视频的账号并集）→ 弹确认框
async function startBatchPublish() {
  if (videoQueue.value.length === 0) {
    ElMessage.error('请先添加视频')
    return
  }
  syncCurrentIntoQueue()

  const rows = videoQueue.value.map((snap, i) => ({
    index: i,
    ..._videoDisplayInfo(snap),
    errors: collectVideoErrors(snap),
  }))
  const validRows = rows.filter(r => r.errors.length === 0)

  if (validRows.length === 0) {
    ElMessage.warning('所有视频都未通过发布前检查，请在确认框中查看原因')
  }

  // Cookie 预检（对通过校验视频的账号并集做一次检查）
  if (appStore.accountCheckMode === 'pre-publish' && validRows.length > 0 && prePublishCheckRef.value) {
    const seen = new Set()
    const accountsToCheck = []
    for (const r of validRows) {
      for (const aid of (videoQueue.value[r.index].publishAccountIds || [])) {
        if (!seen.has(aid)) {
          seen.add(aid)
          const acc = accountStore.accounts.find(a => a.id === aid)
          if (acc) accountsToCheck.push(acc)
        }
      }
    }
    if (accountsToCheck.length > 0) {
      const allValid = await prePublishCheckRef.value.open(accountsToCheck)
      if (!allValid) return  // 用户取消或未全部修复
    }
  }

  batchConfirmRows.value = rows
  batchConfirmVisible.value = true
}

// 确认弹窗回调：提交勾选视频 → 移出队列 → 结果反馈
async function confirmBatchPublish(payload) {
  // 新格式：{ selectedIndexes, intervalMinutes }；兼容旧版直接传数组（防御性）
  const selectedIndexes = Array.isArray(payload)
    ? payload
    : (payload?.selectedIndexes || [])
  const intervalMinutes = Array.isArray(payload)
    ? 0
    : Math.max(0, Number(payload?.intervalMinutes) || 0)
  if (!selectedIndexes || selectedIndexes.length === 0) return
  batchSubmitting.value = true
  try {
    const sorted = [...selectedIndexes].sort((a, b) => a - b)
    const videos = sorted.map(i => videoQueue.value[i])
    const resp = await batchPublishApi.batchPublishVideos(videos, intervalMinutes)
    const data = resp?.data || resp || {}
    const taskIds = data.task_ids || []
    const failed = data.failed || []

    // 发布后视频保留在队列,不再自动移出(用户要求):
    // 发布是后端异步任务,任务卡住/失败时视频还在队列里可直接再次点发布重发;
    // 不需要的视频由用户在队列栏手动移除。先把活状态写回对应位置保留内容。
    syncCurrentIntoQueue()

    // 发布不改动草稿（用户要求）：与当前草稿解绑。
    // 已发布的草稿保持原样；后续再编辑/保存会另存为新草稿，不覆盖它。
    currentDraftId.value = null
    // applyVideoSnapshot 等清理会触发 deep watcher 把 hasChanges 置 true，
    // 等 watcher 跑完立刻复位，避免自动保存把「空白队列」写成新草稿。
    await nextTick()
    hasChanges.value = false
    batchConfirmVisible.value = false

    const failLines = failed
      .filter(f => videos[f.video])
      .map(f => {
        const v = videos[f.video]
        const name = (v.commonConfig?.videoLandscape || v.commonConfig?.videoPortrait)?.name || '未知视频'
        return `「${name}」${f.reason || ''}`
      })
    if (taskIds.length > 0) {
      // 不再跳发布历史：保持原发布交互，弹窗实时展示后端队列执行进度
      batchProgressBatchIds.value = data.batch_ids || []
      batchProgressFailedNotes.value = failLines
      batchProgressIntervalMinutes.value = intervalMinutes
      batchProgressVisible.value = true
    } else if (failLines.length) {
      ElMessage.error(`提交失败：${failLines.join('；')}`)
    }
  } catch (e) {
    ElMessage.error(`批量发布提交失败：${e?.message || e}`)
  } finally {
    batchSubmitting.value = false
  }
}

// （旧前端逐账号发布链路已删除：批量发布改走后端持久化任务队列 /api/v2/videos/batch-publish）

function handleOneClickFill(record) {
  const histConfig = record.account_configs || {}
  const channels = record.channels || []
  // 1. 复原账号选择：清空当前选中，按历史 channels 自动勾选对应平台下的所有账号
  publishAccountIds.clear()
  let selectedAccounts = 0
  for (const ch of channels) {
    const group = accountGroups.value.find(g => g.name === ch.platform)
    if (!group) continue
    for (const acc of group.accounts) {
      if (acc.id != null) {
        publishAccountIds.add(acc.id)
        selectedAccounts++
      }
    }
  }
  // 2. 把历史的单份配置应用到所有涉及的平台（覆盖现有平台配置）
  // 注意：channels[].platform 是中文名（如 "抖音"），platformConfigs 的 key 是英文（如 "douyin"）
  let filled = 0
  for (const ch of channels) {
    const key = platformNameToKey[ch.platform]
    if (!key) continue
    platformConfigs[key] = {
      ...platformConfigs[key],
      ...histConfig,
    }
    filled++
  }
  if (filled > 0) {
    ElMessage.success(`已从历史填充 ${filled} 个平台配置${selectedAccounts > 0 ? `，已选中 ${selectedAccounts} 个账号` : ''}`)
  } else {
    if (selectedAccounts > 0) {
      ElMessage.success(`已选中 ${selectedAccounts} 个账号`)
    } else {
      ElMessage.warning('历史记录没有可填充的平台配置')
    }
  }
}

// ========== Utility ==========
function formatSize(bytes) {
  if (!bytes) return '0B'
  if (bytes < 1024) return bytes + 'B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + 'KB'
  return (bytes / 1024 / 1024).toFixed(2) + 'MB'
}
</script>

<style lang="scss" scoped>
@use '@/styles/variables.scss' as *;

.cursor-pointer {
  cursor: pointer;
}

.publish-center {
  display: flex;
  height: 100%;
  gap: 0;
  overflow: hidden;
}

// ========== RIGHT MAIN ==========
.publish-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  background: $bg-elevated;
  overflow: hidden;
}

.main-body {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.main-form-col {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.main-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 24px;
  border-bottom: 1px solid $border;
  flex-shrink: 0;

  .header-left {
    display: flex;
    align-items: center;
    gap: 12px;

    .page-title {
      font-size: 18px;
      font-weight: 700;
      color: $text-primary;
    }

    .platform-tag {
      font-size: 12px;
      font-weight: 500;
      padding: 4px 12px;
      border-radius: 20px;
    }
  }

  .header-right {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    justify-content: flex-end;

    .header-btn {
      // el-button 默认 padding 8px 15px / font-size 14px / height 32px
      // 想要更紧凑一点,小分辨率下自动缩
      @media (max-width: 1280px) {
        padding: 6px 12px !important;
        font-size: 12px !important;
      }
    }

    .header-btn--primary {
      // 一键发布: 保留项目渐变 + 阴影
      background: linear-gradient(135deg, #8b5cf6, #6366f1) !important;
      border: none !important;
      box-shadow: 0 4px 20px rgba($brand-start, 0.35) !important;
      font-weight: 700;
      letter-spacing: 0.04em;
      padding: 10px 24px !important;

      &:hover {
        box-shadow: 0 6px 28px rgba($brand-start, 0.5) !important;
        transform: translateY(-1px);
        opacity: 1 !important;
      }
      &:active { transform: translateY(0) scale(0.98); }
      &:disabled { opacity: 0.5 !important; cursor: not-allowed; transform: none; box-shadow: none !important; }
    }
  }
}

.main-content {
  flex: 1;
  overflow-y: auto;
  padding: 24px;

  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: rgba($overlay-rgb, 0.1);
    border-radius: 3px;
  }
}

// ========== Config Section ==========
.config-section {
  margin-bottom: 24px;

  // 直接子级、且不在网格/标题组里的独立 setting-card（如通用标签卡片）
  // 与下方 settings-grid 之间需要间距
  > .setting-card {
    margin-bottom: 12px;
  }
}

.xhs-warning {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  margin-bottom: 16px;
  background: rgba(#ff4d4f, 0.1);
  border: 2px solid #ff4d4f;
  border-radius: 8px;
  color: #ff4d4f;
  font-size: 14px;
  font-weight: 600;
  animation: xhs-pulse 2s ease-in-out infinite;

  .el-icon {
    font-size: 20px;
    flex-shrink: 0;
  }
}

@keyframes xhs-pulse {
  0%, 100% { border-color: #ff4d4f; }
  50% { border-color: #ff7875; box-shadow: 0 0 12px rgba(#ff4d4f, 0.3); }
}

.section-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;

  .bar {
    width: 3px;
    height: 18px;
    border-radius: 2px;
    flex-shrink: 0;

    &.purple {
      background: $brand-start;
    }
  }

  .section-label {
    font-size: 15px;
    font-weight: 600;
    color: $text-primary;
  }

  .hint {
    font-size: 12px;
    color: $text-muted;
  }
}

// ========== Media Section ==========
.media-section {
  margin-bottom: 20px;
  border: 1px solid $border;
  border-radius: $radius-card;
  padding: 16px;
  background: rgba($overlay-rgb, 0.02);
  transition: $transition-base;

  &:hover {
    border-color: $border-active;
  }

  > .section-label {
    font-size: 13px;
    font-weight: 600;
    color: $text-primary;
    margin-bottom: 12px;
    display: block;
  }
}

.btn-icon {
  margin-right: 4px;
}

// ----- Right Phone Panel -----
.phone-panel {
  width: 400px;
  flex-shrink: 0;
  background: $bg-base;
  border-left: 1px solid $border;
  display: flex;
  flex-direction: column;
  justify-content: center;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: rgba($overlay-rgb, 0.08) transparent;
  &::-webkit-scrollbar { width: 4px; }
  &::-webkit-scrollbar-thumb { background: rgba($overlay-rgb, 0.1); border-radius: 2px; }
}

.phone-panel-header {
  padding: 16px 16px 12px;
  border-bottom: 1px solid $border;
}

.phone-panel-title {
  font-size: 14px;
  font-weight: 600;
  color: $text-primary;
}

.phone-mode-tabs {
  display: flex;
  gap: 4px;
  padding: 12px 16px 8px;
}

.mode-tab {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 12px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: $text-muted;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: $transition-fast;
  font-family: inherit;
  outline: none;

  &:hover:not(.active) {
    color: $text-secondary;
    background: rgba($overlay-rgb, 0.03);
  }
  &.active {
    background: rgba($brand-start, 0.08);
    border-color: rgba($brand-start, 0.2);
    color: $brand-start;
  }
}

.mode-icon-portrait {
  display: inline-block;
  width: 10px;
  height: 14px;
  border: 2px solid currentColor;
  border-radius: 3px;
}
.mode-icon-landscape {
  display: inline-block;
  width: 14px;
  height: 10px;
  border: 2px solid currentColor;
  border-radius: 3px;
}

.phone-preview-area {
  display: flex;
  justify-content: center;
  padding: 16px 4px;
}

.phone-mockup {
  position: relative;
  background: #1a1a2e;
  border: 3px solid #2a2a40;
  border-radius: 28px;
  padding: 8px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), inset 0 0 0 1px rgba($overlay-rgb, 0.05);
  display: flex;
  flex-direction: column;
  align-items: center;
  transition: width 0.3s ease;

  width: 90%;
}

.phone-notch {
  width: 60px;
  height: 6px;
  background: #2a2a40;
  border-radius: 3px;
  margin-bottom: 6px;
}

.phone-screen {
  width: 100%;
  aspect-ratio: 9 / 16;
  background: $bg-base;
  border-radius: 16px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.phone-video-player {
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
  outline: none;
}

.phone-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  height: 100%;
  color: $text-muted;
  font-size: 11px;
  cursor: pointer;
  transition: $transition-fast;

  &:hover {
    color: $brand-start;
    background: rgba($brand-start, 0.04);
  }
}

.phone-home-bar {
  width: 40px;
  height: 4px;
  background: rgba($overlay-rgb, 0.15);
  border-radius: 2px;
  margin-top: 6px;
}

.phone-panel-actions {
  display: flex;
  gap: 8px;
  padding: 0 16px 12px;
  .cover-action-btn { flex: 1; }
}

.phone-panel-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 0 16px;
  padding: 10px 12px;
  background: rgba($overlay-rgb, 0.03);
  border: 1px solid $border;
  border-radius: $radius-base;
}

.phone-info-name {
  font-size: 12px;
  color: $text-secondary;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}

.phone-info-remove {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: $text-muted;
  cursor: pointer;
  transition: $transition-fast;
  &:hover {
    background: rgba($danger-color, 0.1);
    color: $danger-color;
  }
}

// ----- Cover Section -----
.cover-section {
  background: rgba($overlay-rgb, 0.01);
  border-color: $border;
}

.cover-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  align-items: stretch;
}

.cover-action-btn {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 6px 14px;
  border: 1px solid $border;
  border-radius: $radius-sm;
  background: rgba($overlay-rgb, 0.03);
  color: $text-secondary;
  font-size: 12px;
  cursor: pointer;
  transition: $transition-base;
  outline: none;
  font-family: inherit;
  line-height: 1;

  .el-icon {
    flex-shrink: 0;
    color: $text-muted;
    transition: $transition-base;
  }

  &:hover {
    border-color: rgba($brand-start, 0.35);
    background: linear-gradient(135deg, rgba($brand-start, 0.08), rgba($brand-end, 0.06));
    color: $text-primary;

    .el-icon {
      color: $brand-start;
    }
  }

  &:active {
    transform: scale(0.97);
  }

  &.primary {
    border-color: rgba($brand-start, 0.25);
    background: linear-gradient(135deg, rgba($brand-start, 0.1), rgba($brand-end, 0.08));
    color: $text-primary;

    .el-icon {
      color: $brand-start;
    }

    &:hover {
      border-color: rgba($brand-start, 0.45);
      background: linear-gradient(135deg, rgba($brand-start, 0.18), rgba($brand-end, 0.14));
    }
  }

  &.danger {
    &:hover {
      border-color: rgba($danger-color, 0.35);
      background: rgba($danger-color, 0.08);
      color: $danger-color;

      .el-icon {
        color: $danger-color;
      }
    }
  }
}

// ========== Form Fields ==========
.form-field {
  margin-bottom: 20px;

  .field-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;
    font-size: 13px;
    font-weight: 500;
    color: $text-secondary;

    .field-counter {
      font-size: 12px;
      color: $text-muted;
    }
  }

  :deep(.el-input__wrapper),
  :deep(.el-textarea__inner) {
    background: rgba($overlay-rgb, 0.03);
    border: 1px solid $border;
    border-radius: $radius-base;
    box-shadow: none;
    color: $text-primary;
    transition: $transition-base;

    &:hover {
      border-color: $border-active;
    }

    &:focus,
    &.is-focus {
      border-color: $brand-start;
    }
  }

  :deep(.el-input__count) {
    color: $text-muted;
    background: transparent;
  }
}

// ========== Divider ==========
.divider {
  height: 1px;
  background: $border;
  margin: 8px 0 24px;
  background-image: repeating-linear-gradient(
    90deg,
    $border,
    $border 6px,
    transparent 6px,
    transparent 12px
  );
}

// ========== Batch Sync Section ==========
.batch-sync-section {
  border: 1px solid $border;
  border-radius: $radius-card;
  overflow: hidden;
  margin-bottom: 4px;

  .batch-sync-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    color: $text-secondary;
    transition: $transition-base;

    &:hover {
      color: $text-primary;
      background: rgba($overlay-rgb, 0.02);
    }
  }

  .batch-sync-body {
    padding: 12px 16px 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    border-top: 1px solid $border;
  }
}

// ========== Platform Title & Description ==========
.platform-title-desc {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 12px;
}

// ========== Settings Grid ==========
.settings-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 12px;
  margin-bottom: 12px;
}

// 单独占满整行的卡片(如淘宝光合「关联商品/店铺」radio 卡片)
.setting-card--full-row {
  grid-column: 1 / -1;
}

.setting-card {
  padding: 14px 16px;
  border: 1px solid;
  border-radius: $radius-card;
  display: flex;
  flex-direction: column;
  gap: 10px;
  transition: $transition-base;

  &:hover {
    filter: brightness(1.1);
  }

  .setting-label {
    font-size: 13px;
    font-weight: 600;
  }

  .setting-desc {
    font-size: 12px;
    color: $text-secondary;
    line-height: 1.6;
    white-space: pre-line;
  }

  :deep(.el-input__wrapper),
  :deep(.el-select .el-input__wrapper) {
    background: rgba($overlay-rgb, 0.03);
    border: 1px solid $border;
    border-radius: $radius-sm;
    box-shadow: none;
    transition: $transition-base;

    &:hover {
      border-color: $border-active;
    }
  }

  .radio-row {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;

    // 禁用态(如小红书选「来源转载」时原创声明禁用)
    &.is-disabled {
      .radio-item.is-disabled {
        opacity: 0.4;
        cursor: not-allowed;
        pointer-events: none;
      }
    }
  }

  .radio-item {
    display: flex;
    align-items: center;
    gap: 4px;

    input[type='radio'] {
      display: none;
    }

    .radio-text {
      padding: 4px 14px;
      border: 1px solid $border;
      border-radius: $radius-sm;
      font-size: 12px;
      color: $text-secondary;
      transition: $transition-base;

      &.on {
        font-weight: 600;
        box-shadow: 0 0 0 1px rgba($brand-start, 0.3);
      }
    }

    &.disabled {
      opacity: 0.4;
      cursor: not-allowed;
      .radio-text.muted { opacity: 0.5; }
    }
  }
}

.setting-hint {
  font-size: 12px;
  color: #909399;
  margin-bottom: 8px;
  line-height: 1.5;
}

.tags-list {
  margin-top: 8px;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

// ========== No Platform Hint ==========
.no-platform-hint {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 20px;
  color: $text-muted;
  text-align: center;

  .hint-icon {
    opacity: 0.3;
    margin-bottom: 16px;
  }

  p {
    font-size: 15px;
    margin: 4px 0;
  }

  .hint-sub {
    font-size: 13px;
    color: $text-muted;
  }
}

// ========== Upload Dialogs ==========
.video-upload-dialog,
.material-library-dialog {
  .material-library-content {
    .material-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      max-height: 400px;
      overflow-y: auto;

      .material-item {
        padding: 10px 14px;
        border: 1px solid $border;
        border-radius: $radius-base;
        transition: $transition-base;

        &:hover {
          border-color: $border-active;
        }

        .material-info {
          .material-name {
            font-size: 14px;
            color: $text-primary;
            font-weight: 500;
          }

          .material-details {
            display: flex;
            gap: 16px;
            margin-top: 4px;
            font-size: 12px;
            color: $text-muted;
          }
        }
      }
    }
  }
}

// ========== Shared ==========
.dialog-footer-right {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

// ========== 淘宝光合:关联商品/店铺 ==========
.guanghe-link-field {
  display: flex;
  flex-direction: column;
  gap: 14px;
  width: 100%;
}
.guanghe-items-field {
  width: 100%;
}

.link-sub {
  margin-top: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.channels-drama-selected {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;

  .drama-pill {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 4px 8px 4px 4px;
    background: rgba(255, 80, 0, 0.06);
    border: 1px solid rgba(255, 80, 0, 0.25);
    border-radius: 6px;
    max-width: 320px;
    flex: 1 1 320px;
    min-width: 0;

    .drama-pill-cover {
      width: 32px;
      height: 32px;
      border-radius: 4px;
      object-fit: cover;
      flex-shrink: 0;
      background: rgba(0, 0, 0, 0.05);
    }
    .drama-pill-text {
      flex: 1;
      min-width: 0;

      .drama-pill-title {
        font-size: 13px;
        color: var(--el-text-color-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .drama-pill-ext {
        font-size: 11px;
        color: var(--el-text-color-secondary);
        margin-top: 2px;
      }
    }
  }
}
.guanghe-selected-list {
  // 跟弹窗里 .grid 完全一致
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 12px;
}
.guanghe-selected-card {
  position: relative;
  border: 1px solid #eee;
  border-radius: 6px;
  background: #fff;
  overflow: hidden;
  transition: all 0.15s;
  display: flex;
  flex-direction: column;

  &:hover {
    border-color: #ff5000;
    box-shadow: 0 2px 8px rgba(255, 80, 0, 0.12);
    .guanghe-selected-remove { opacity: 1; }
  }

  // 完全复刻弹窗 .card 的 .img-wrap 结构
  .img-wrap {
    position: relative;
    width: 100%;
    aspect-ratio: 1;
    background: #f5f5f5;
    img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .placeholder {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #999;
      font-size: 28px;
      font-weight: 600;
    }
  }

  // 完全复刻弹窗 .card 的 .info 结构(关键:flex:1 让标题区有完整空间,line-clamp 才会正确生效)
  .info {
    padding: 8px;
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;

    .title {
      font-size: 12px;
      color: #333;
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      min-height: 34px;
    }
  }

  .guanghe-selected-remove {
    position: absolute;
    top: 6px;
    right: 6px;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.55);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    opacity: 0;
    transition: opacity 0.15s;
    font-size: 12px;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
    &:hover { background: #ff5000; }
  }
}
.guanghe-add-card {
  // 跟 selected-card 同尺寸(grid cell)
  border: 2px dashed #d9d9d9;
  border-radius: 6px;
  background: #fafafa;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 6px;
  cursor: pointer;
  color: #999;
  font-size: 12px;
  // 高度对齐 selected-card 整卡(grid cell 宽 ≥180, 图 180 + 标题 34 + padding)
  min-height: 224px;
  transition: all 0.15s;

  .el-icon {
    font-size: 32px;
  }

  &:hover {
    border-color: #ff5000;
    color: #ff5000;
    background: #fff5f0;
  }
}

// 暗色模式:发布界面已选商品卡片 + 添加卡片(色值与 GuangheItemPicker 暗色保持一致)
// 注意:Vue scoped 不支持 :global(...) 嵌套,必须扁平写 html.dark .xxx
html.dark .guanghe-selected-card {
  background: #2a2a2c;
  border-color: #3a3a3c;
}
html.dark .guanghe-selected-card .img-wrap {
  background: #1f1f21;
}
html.dark .guanghe-selected-card .img-wrap .placeholder {
  color: #8a8a8e;
}
html.dark .guanghe-selected-card .info .title {
  color: #e5e5e7;
}
html.dark .guanghe-add-card {
  background: #232325;
  border-color: #4a4a4c;
  color: #8a8a8e;
}
html.dark .guanghe-add-card:hover {
  background: #3a2018;
  color: #ff5000;
  border-color: #ff5000;
}
/* B 站标签选项行(保留系统生成标签开关) */
.tag-option-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
  flex-wrap: wrap;
}
.tag-option-label {
  font-size: 13px;
  font-weight: 600;
}
.tag-option-hint {
  font-size: 12px;
  color: $text-muted;
}
</style>

import { describe, it, expect, vi } from 'vitest';
import { registerPublishTools } from '../../src/tools/publish';
import { BackendClient } from '../../src/client';

function makeMockServer(tools: any[]) {
  return {
    tool: (name: string, description: string, schema: any, handler: Function) => {
      tools.push({ name, description, schema, handler });
    },
  } as any;
}

/** 模拟后端：1 个抖音账号 + 抖音平台元数据 + 视频素材 + 成功任务 + 封面裁剪 */
function makeMockClient(overrides: Record<string, any> = {}) {
  const coverObj = (key: string) => ({
    id: `cov-${key}`, original_filename: `cover_${key}.jpg`,
    stored_path: `covers/${key}.jpg`, file_type: 'image',
    mime_type: 'image/jpeg', file_size: 100, url: `http://x/${key}.jpg`, thumbnail_path: null,
  });
  const coverDict = {
    landscape_43: coverObj('landscape_43'),
    landscape_169: coverObj('landscape_169'),
    portrait_34: coverObj('portrait_34'),
    portrait_916: coverObj('portrait_916'),
  };
  return {
    get: vi.fn(async (path: string) => {
      if (path === '/getAccounts') {
        return { data: [[7, 3, '/cookies/dy.json', '抖音号', 1, '']] };
      }
      if (path === '/api/v2/platforms') {
        return { data: { platforms: [{
          id: 3, key: 'douyin', name: '抖音',
          default_config: { title: '', description: '', tags: [], aiContent: '', scheduleTime: '' },
        }] } };
      }
      if (path.startsWith('/api/materials/')) {
        return { data: {
          id: 'mat-1', original_filename: 'v.mp4', stored_path: 'materials/v.mp4',
          file_type: 'video', file_size: 1, duration: 10, orientation: 'horizontal',
        } };
      }
      if (path === '/api/frames') {
        return { data: { status: 'done', frames: [{ seconds: 1 }, { seconds: 3 }, { seconds: 5 }] } };
      }
      if (path.startsWith('/api/v2/tasks/')) {
        return { data: { id: 'task-1', status: 'success', platform: '抖音', account_name: '抖音号', error_message: '' } };
      }
      return { data: null };
    }),
    post: vi.fn(async (path: string, body?: any) => {
      if (path === '/api/v2/videos/batch-publish') {
        return { code: 200, data: { task_ids: ['task-1'], batch_ids: ['batch-1'], failed: [] } };
      }
      if (path === '/api/frames/save-cover') {
        return { code: 200, data: coverDict };
      }
      if (path === '/api/materials/covers/crop') {
        // 指定 ratios 时只返回子集（与后端行为一致）
        if (body?.ratios) {
          const sub: any = {};
          for (const r of body.ratios) sub[r] = coverDict[r as keyof typeof coverDict];
          return { code: 200, data: sub };
        }
        return { code: 200, data: coverDict };
      }
      return { code: 200, data: {} };
    }),
    ...overrides,
  } as any;
}

describe('publish tools', () => {
  it('应该注册3个发布工具（video_publish / video_batch_publish / image_publish）', () => {
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), {} as BackendClient);
    expect(tools.map(t => t.name)).toEqual(['video_publish', 'video_batch_publish', 'image_publish']);
  });

  it('video_publish 走 /api/v2/videos/batch-publish（与网页同链路），构造完整 draft_data 快照', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [7],
      material_id: 'mat-1',
      title: '测试标题',
      description: '测试描述',
      tags: ['测试'],
      use_auto_cover: true,
      platform_settings: { douyin: { aiContent: '内容由AI生成' } },
      schedule_time: '2026-09-20 18:00:00',
    });

    expect(result.isError).toBeFalsy();
    expect(mockClient.post).toHaveBeenCalledWith('/api/v2/videos/batch-publish', expect.objectContaining({
      videos: [expect.objectContaining({
        publishAccountIds: [7],
        platformConfigs: {
          douyin: expect.objectContaining({
            title: '测试标题',
            description: '测试描述',
            tags: ['测试'],
            aiContent: '内容由AI生成',
            scheduleTime: '2026-09-20 18:00:00',
          }),
        },
      })],
      interval_minutes: 0,
    }), expect.any(Number));

    // 载荷结构与网页一致：媒体放 commonConfig（orientation 决定横/竖字段）
    const call = mockClient.post.mock.calls.find(c => c[0] === '/api/v2/videos/batch-publish');
    const video = call![1].videos[0];
    expect(video.commonConfig.videoLandscape).toEqual(expect.objectContaining({
      id: 'mat-1', stored_path: 'materials/v.mp4',
    }));
    expect(video.commonConfig.videoPortrait).toBeNull();
    // 封面 4 比例齐备（自动路径：抽帧 → 3 秒帧 → save-cover 裁剪）
    expect(mockClient.post).toHaveBeenCalledWith('/api/frames/save-cover', { material_id: 'mat-1', seconds: 3 });
    expect(video.commonConfig.coverLandscape).toEqual(expect.objectContaining({ stored_path: 'covers/landscape_43.jpg' }));
    expect(video.commonConfig.coverLandscape169).toEqual(expect.objectContaining({ stored_path: 'covers/landscape_169.jpg' }));
    expect(video.commonConfig.coverPortrait).toEqual(expect.objectContaining({ stored_path: 'covers/portrait_34.jpg' }));
    expect(video.commonConfig.coverPortrait916).toEqual(expect.objectContaining({ stored_path: 'covers/portrait_916.jpg' }));
    expect(video.platformOverrides).toEqual({});
    expect(video.accountOverrides).toEqual({});
  });

  it('video_publish 传 cover_material_id 时以源图裁 4 比例（covers/crop）', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't',
      description: '', tags: [],
      cover_material_id: 'cover-img-1', wait: false,
    });

    expect(result.isError).toBeFalsy();
    expect(mockClient.post).toHaveBeenCalledWith('/api/materials/covers/crop', { material_id: 'cover-img-1' });
    const call = mockClient.post.mock.calls.find(c => c[0] === '/api/v2/videos/batch-publish');
    const video = call![1].videos[0];
    expect(video.commonConfig.coverLandscape.stored_path).toBe('covers/landscape_43.jpg');
    expect(video.commonConfig.coverPortrait916.stored_path).toBe('covers/portrait_916.jpg');
  });

  it('video_publish 显式横版+竖版不同源图时按各自比例单独裁剪', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't', wait: false,
      description: '', tags: [],
      cover_landscape_material_id: 'img-land',
      cover_portrait_material_id: 'img-port',
    });

    expect(result.isError).toBeFalsy();
    // 主源（横版）裁 4 张，竖版单独按 3:4 裁剪覆盖
    expect(mockClient.post).toHaveBeenCalledWith('/api/materials/covers/crop', { material_id: 'img-land' });
    expect(mockClient.post).toHaveBeenCalledWith('/api/materials/covers/crop', { material_id: 'img-port', ratios: ['portrait_34'] });
    const call = mockClient.post.mock.calls.find(c => c[0] === '/api/v2/videos/batch-publish');
    const video = call![1].videos[0];
    expect(video.commonConfig.coverLandscape.stored_path).toBe('covers/landscape_43.jpg');
    expect(video.commonConfig.coverPortrait.stored_path).toBe('covers/portrait_34.jpg');
  });

  it('video_publish 默认等待终态，返回 all_success', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't',
      description: '简介', tags: ['标签'],
      use_auto_cover: true,
    });

    const parsed = JSON.parse(result.content[0].text);
    expect(parsed.all_success).toBe(true);
    expect(parsed.tasks).toEqual([expect.objectContaining({ task_id: 'task-1', status: 'success' })]);
  });

  it('video_publish wait=false 立即返回 task_ids 不轮询', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't', wait: false,
      description: '', tags: [],
      use_auto_cover: true,
    });

    const parsed = JSON.parse(result.content[0].text);
    expect(parsed.task_ids).toEqual(['task-1']);
    // 不应有任务轮询调用
    expect(mockClient.get).not.toHaveBeenCalledWith('/api/v2/tasks/task-1', undefined);
  });

  it('video_publish 不存在的素材返回 MATERIAL_NOT_FOUND', async () => {
    const mockClient = makeMockClient();
    mockClient.get = vi.fn(async (path: string) => {
      if (path === '/getAccounts') return { data: [[7, 3, '/cookies/dy.json', '抖音号', 1, '']] };
      if (path === '/api/v2/platforms') return { data: { platforms: [{ id: 3, key: 'douyin', default_config: {} }] } };
      if (path.startsWith('/api/materials/')) {
        const err: any = new Error('not found');
        err.response = { status: 404 };
        throw err;
      }
      return { data: null };
    });
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [7], material_id: 'nope', title: 't',
      description: '', tags: [],
      use_auto_cover: true,
    });
    expect(result.isError).toBe(true);
    expect(JSON.parse(result.content[0].text).error).toBe('MATERIAL_NOT_FOUND');
    expect(mockClient.post).not.toHaveBeenCalled();
  });

  it('video_publish 不存在的账号返回 ACCOUNT_NOT_FOUND', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    const result = await videoPublish.handler({
      account_ids: [999], material_id: 'mat-1', title: 't',
      description: '', tags: [],
    });
    expect(result.isError).toBe(true);
    expect(JSON.parse(result.content[0].text).error).toBe('ACCOUNT_NOT_FOUND');
    expect(mockClient.post).not.toHaveBeenCalled();
  });

  it('video_publish 缺描述/标签（未经用户确认）时拒绝发布', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    // 两个都缺
    const both = await videoPublish.handler({ account_ids: [7], material_id: 'mat-1', title: 't' });
    expect(both.isError).toBe(true);
    const parsedBoth = JSON.parse(both.content[0].text);
    expect(parsedBoth.error).toBe('MISSING_REQUIRED_FIELD');
    expect(parsedBoth.message).toContain('description（描述）');
    expect(parsedBoth.message).toContain('tags（标签）');

    // 只缺标签
    const tagsOnly = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't', description: '有描述',
    });
    expect(tagsOnly.isError).toBe(true);
    expect(JSON.parse(tagsOnly.content[0].text).message).toContain('tags（标签）');

    // 缺失场景下不应触达后端发布
    expect(mockClient.post).not.toHaveBeenCalledWith('/api/v2/videos/batch-publish', expect.anything(), expect.anything());

    // 显式空值 = 用户确认过，放行（封面同时确认抽帧自动）
    const explicitEmpty = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't', description: '', tags: [], wait: false,
      use_auto_cover: true,
    });
    expect(explicitEmpty.isError).toBeFalsy();
  });

  it('video_publish 封面方式未抉择（抽帧 or 用户封面图）时拒绝发布', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const videoPublish = tools.find(t => t.name === 'video_publish')!;

    // 描述/标签都确认了，但封面方式没让用户抉择
    const result = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't',
      description: '', tags: [],
    });
    expect(result.isError).toBe(true);
    const parsed = JSON.parse(result.content[0].text);
    expect(parsed.error).toBe('MISSING_REQUIRED_FIELD');
    expect(parsed.message).toContain('封面方式未确认');
    expect(mockClient.post).not.toHaveBeenCalledWith('/api/frames/save-cover', expect.anything());
    expect(mockClient.post).not.toHaveBeenCalledWith('/api/v2/videos/batch-publish', expect.anything(), expect.anything());

    // 用户确认抽帧自动封面 → 放行并走抽帧裁剪
    const autoOk = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't',
      description: '', tags: [], use_auto_cover: true, wait: false,
    });
    expect(autoOk.isError).toBeFalsy();
    expect(mockClient.post).toHaveBeenCalledWith('/api/frames/save-cover', { material_id: 'mat-1', seconds: 3 });

    // 指定选帧时间点 = 隐式确认抽帧封面
    const framePick = await videoPublish.handler({
      account_ids: [7], material_id: 'mat-1', title: 't',
      description: '', tags: [], cover_frame_seconds: 5, wait: false,
    });
    expect(framePick.isError).toBeFalsy();
    expect(mockClient.post).toHaveBeenCalledWith('/api/frames/save-cover', { material_id: 'mat-1', seconds: 5 });
  });

  it('video_batch_publish 某视频缺描述/标签时整批拒绝', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const batchPublish = tools.find(t => t.name === 'video_batch_publish')!;

    const result = await batchPublish.handler({
      videos: [
        { account_ids: [7], material_id: 'mat-1', title: '视频1', description: '', tags: [], use_auto_cover: true },
        { account_ids: [7], material_id: 'mat-1', title: '视频2' },  // 缺描述/标签
      ],
      wait: false,
    });

    expect(result.isError).toBe(true);
    expect(JSON.parse(result.content[0].text).error).toBe('MISSING_REQUIRED_FIELD');
    expect(mockClient.post).not.toHaveBeenCalledWith('/api/v2/videos/batch-publish', expect.anything(), expect.anything());
  });

  it('video_batch_publish 多视频一次提交', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const batchPublish = tools.find(t => t.name === 'video_batch_publish')!;

    const result = await batchPublish.handler({
      videos: [
        { account_ids: [7], material_id: 'mat-1', title: '视频1', description: '', tags: [], use_auto_cover: true },
        { account_ids: [7], material_id: 'mat-1', title: '视频2', description: '', tags: [], use_auto_cover: true },
      ],
      interval_minutes: 10,
      wait: false,
    });

    expect(result.isError).toBeFalsy();
    const call = mockClient.post.mock.calls.find(c => c[0] === '/api/v2/videos/batch-publish');
    expect(call![1].videos).toHaveLength(2);
    expect(call![1].interval_minutes).toBe(10);
  });

  it('image_publish 自动解析账号 cookie 路径并注入平台声明字段', async () => {
    const mockClient = makeMockClient();
    const tools: any[] = [];
    registerPublishTools(makeMockServer(tools), mockClient);
    const imagePublish = tools.find(t => t.name === 'image_publish')!;

    const result = await imagePublish.handler({
      image_ids: ['img-1'],
      account_configs: [{
        account_id: 7,
        title: '图文标题',
        platform_settings: { aiContent: '内容由AI生成', isOriginal: true },
      }],
    });

    expect(result.isError).toBeFalsy();
    expect(mockClient.post).toHaveBeenCalledWith('/api/image-publish/publish', expect.objectContaining({
      image_ids: ['img-1'],
      account_configs: [expect.objectContaining({
        account_id: 7,
        platform: 'douyin',
        filePath: '/cookies/dy.json',
        cover_path: '',
        dry_run: false,
        aiContent: '内容由AI生成',
        isOriginal: true,
      })],
    }), expect.any(Number));
  });
});

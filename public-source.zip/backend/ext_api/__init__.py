"""
扩展 API Blueprint — 阶段二
任务管理、发布历史、统计数据、SSE 实时推送
"""

import json
import sqlite3
import queue
import threading
import urllib.parse
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from flask import Blueprint, request, jsonify, Response

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from conf import BASE_DIR

from .task_queue import get_task_queue, PublishTask, TaskStatus
from ._personalized import compute_personalized
from services.draft_merge import (
    merge_config, validate_draft_for_publish, build_platform_kwargs,
)

ext_api = Blueprint('ext_api', __name__, url_prefix='/api/v2')

DB_PATH = BASE_DIR / "db" / "database.db"

# 平台 id → 中文名称(必须与 frontend config/platforms.js + impl/registry.py 一致)
_PLATFORM_ID_TO_NAME = {
    1: "小红书", 2: "视频号", 3: "抖音", 4: "快手", 5: "B站",
    6: "百家号", 7: "TikTok", 8: "YouTube", 9: "腾讯视频",
    10: "爱奇艺", 11: "微博", 12: "支付宝", 13: "今日头条", 14: "知乎",
    15: "CSDN", 16: "VIVO", 17: "微信公众号", 18: "淘宝光合", 19: "京东京麦",
    21: "大鱼号",
}

# 平台 key(拼音) → 中文名称。修复 publish_details.platform 历史脏数据:
# 旧数据中有的存的是拼音 key(如 iqiyi / tencent_video),有的存的是中文名
# 这里统一转中文名。key 必须与 frontend config/platforms.js 一致。
_PLATFORM_KEY_TO_NAME = {
    "xiaohongshu": "小红书", "channels": "视频号", "douyin": "抖音",
    "kuaishou": "快手", "bilibili": "B站", "baijiahao": "百家号",
    "tiktok": "TikTok", "youtube": "YouTube",
    "tencent_video": "腾讯视频", "iqiyi": "爱奇艺",
    "weibo": "微博", "alipay": "支付宝", "toutiao": "今日头条", "zhihu": "知乎",
    "csdn": "CSDN", "vivo": "VIVO", "weixin_gzh": "微信公众号",
    "taobao_guanghe": "淘宝光合", "jingmai": "京东京麦", "dayu": "大鱼号",
}

# SSE 订阅者
_sse_subscribers: list[queue.Queue] = []
_sse_lock = threading.Lock()


_tables_ensured = False


def _ensure_tables(conn):
    """确保 drafts 表存在（兼容旧版本数据库升级）。"""
    global _tables_ensured
    if _tables_ensured:
        return
    try:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS drafts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT DEFAULT 'video',
            title TEXT DEFAULT '',
            cover_path TEXT DEFAULT '',
            draft_data TEXT DEFAULT '{}',
            channels_summary TEXT DEFAULT '[]',
            video_duration REAL DEFAULT 0,
            video_file_size INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)
        # 迁移：为旧表添加 type 列
        try:
            conn.execute('ALTER TABLE drafts ADD COLUMN type TEXT DEFAULT "video"')
        except sqlite3.OperationalError:
            pass  # 列已存在
        conn.commit()
    except Exception:
        pass
    _tables_ensured = True


def _db_conn():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    _ensure_tables(conn)
    return conn


def _to_beijing_time(utc_str):
    """将 SQLite UTC 时间字符串转换为北京时间 ISO 格式"""
    if not utc_str:
        return utc_str
    try:
        dt = datetime.strptime(str(utc_str), '%Y-%m-%d %H:%M:%S')
        dt = dt + timedelta(hours=8)
        return dt.strftime('%Y-%m-%dT%H:%M:%S+08:00')
    except (ValueError, TypeError):
        return utc_str


def _resolve_cover_url(material_id: str) -> str:
    """解析 material_id → /api/materials/file/{stored_path} URL。失败返回空串。

    stored_path 可能是绝对路径。用 urllib.parse.quote 编码可避免前导 `/` 触发双斜杠。
    """
    if not material_id:
        return ''
    try:
        conn = _db_conn()
        row = conn.execute(
            "SELECT stored_path FROM materials WHERE id = ?", (material_id,)
        ).fetchone()
        conn.close()
        if not row:
            return ''
        return f"/api/materials/file/{urllib.parse.quote(row['stored_path'], safe='')}"
    except Exception:
        return ''


def _resolve_cover_from_path(stored_path) -> str:
    """直接用 stored_path 构造 /api/materials/file/{path} URL。空串/无法解析返回空。

    stored_path 可能是:
    - Linux 绝对路径:/home/.../data/materials/2026/06/13/uuid.jpg
    - Windows 绝对路径:D:\\...\\data\\materials\\2026\\06\\13\\uuid.jpg
      (数据从 Windows 同步过来时常见)
    - 相对路径(含 materials/ 前缀)
    - dict:某些路径(草稿批量发布等)会把 task.cover_landscape(dict)
      原样写进 account_configs,结构可能是 {stored_path|path|url: ...}
    - None / 空:返回空串

    任意输入都不应抛异常。
    """
    if isinstance(stored_path, dict):
        for key in ('stored_path', 'path', 'url', 'storedPath'):
            v = stored_path.get(key)
            if v:
                stored_path = v
                break
        else:
            return ''
    if not stored_path or not isinstance(stored_path, str):
        return ''
    # 跨平台:统一反斜杠为正斜杠,再找 materials/ | covers/ | videos/ 起始位置。
    # 用 find 而非 startswith:批量发布早期写入的 thumbnail_path 是绝对路径
    # (D:\...\data\covers\...),前缀不匹配会退化成 basename → 封面 404。
    normalized = stored_path.replace('\\', '/')
    relative = ''
    for prefix in ('materials/', 'covers/', 'videos/'):
        idx = normalized.find(prefix)
        if idx >= 0:
            relative = normalized[idx:]
            break
    if not relative:
        # 兜底:取 basename(用于纯文件名输入,虽然没法定位文件)
        relative = normalized.rsplit('/', 1)[-1]
    return f"/api/materials/file/{urllib.parse.quote(relative, safe='')}"


# ========== 任务管理 ==========

@ext_api.route('/tasks', methods=['GET'])
def get_tasks():
    """获取任务列表（读 publish_details，每行 = 1 个账号 × 1 个平台）"""
    status = request.args.get('status')
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    offset = (page - 1) * page_size

    try:
        conn = _db_conn()
        where = ""
        params = []
        if status and status != 'all':
            where = "WHERE d.status = ?"
            params.append(status)

        total = conn.execute(
            f"SELECT COUNT(*) FROM publish_details d {where}", params
        ).fetchone()[0]

        rows = conn.execute(
            f"""SELECT d.*, b.title AS batch_title, b.type AS batch_type
                FROM publish_details d
                LEFT JOIN publish_batches b ON d.batch_id = b.id
                {where}
                ORDER BY d.created_at DESC LIMIT ? OFFSET ?""",
            params + [page_size, offset]
        ).fetchall()

        tasks = []
        for row in rows:
            d = dict(row)
            try:
                d['account_configs'] = json.loads(d.get('account_configs', '{}'))
            except json.JSONDecodeError:
                d['account_configs'] = {}
            tasks.append(d)

        conn.close()
        return jsonify({"code": 200, "data": {"list": tasks, "total": total, "page": page, "pageSize": page_size}})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/tasks', methods=['POST'])
def create_task():
    """创建发布任务"""
    data = request.get_json()
    if not data:
        return jsonify({"code": 400, "msg": "请求数据不能为空"}), 400

    required = ['platformType', 'accountName', 'accountCookiePath', 'videoPath', 'title']
    for field in required:
        if not data.get(field):
            return jsonify({"code": 400, "msg": f"缺少必填字段: {field}"}), 400

    # 平台 id → 名称 完整映射(必须与 frontend config/platforms.js + impl/registry.py 一致)
    platform_map = {
        1: "小红书", 2: "视频号", 3: "抖音", 4: "快手", 5: "B站",
        6: "百家号", 7: "TikTok", 8: "YouTube", 9: "腾讯视频",
        10: "爱奇艺", 11: "微博", 12: "支付宝", 13: "今日头条", 14: "知乎",
        15: "CSDN",
    }
    platform_type = data['platformType']

    task = PublishTask(
        platform=platform_map.get(platform_type, "未知"),
        platform_type=platform_type,
        account_name=data['accountName'],
        account_cookie_path=data['accountCookiePath'],
        video_path=data['videoPath'],
        title=data['title'],
        description=data.get('description', ''),
        thumbnail_path=data.get('thumbnailPath', ''),
        tags=data.get('tags', []),
    )

    tq = get_task_queue()
    tq.add_task(task)

    return jsonify({"code": 200, "data": {"id": task.id, "status": task.status}})


@ext_api.route('/tasks/<detail_id>', methods=['GET'])
def get_task(detail_id):
    """获取单个任务（按 publish_details.id 查）"""
    try:
        conn = _db_conn()
        row = conn.execute(
            """SELECT d.*, b.title AS batch_title, b.type AS batch_type
               FROM publish_details d
               LEFT JOIN publish_batches b ON d.batch_id = b.id
               WHERE d.id = ?""",
            (detail_id,)
        ).fetchone()
        conn.close()
        if not row:
            return jsonify({"code": 404, "msg": "任务不存在"}), 404
        d = dict(row)
        try:
            d['account_configs'] = json.loads(d.get('account_configs', '{}'))
        except json.JSONDecodeError:
            d['account_configs'] = {}
        return jsonify({"code": 200, "data": d})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/tasks/<task_id>/cancel', methods=['POST'])
def cancel_task(task_id):
    """取消任务"""
    tq = get_task_queue()
    if tq.cancel_task(task_id):
        return jsonify({"code": 200, "msg": "任务已取消"})
    return jsonify({"code": 400, "msg": "无法取消该任务"}), 400


@ext_api.route('/tasks/cancel-batch', methods=['POST'])
def cancel_tasks_batch():
    """批量取消任务(一次请求全取消)。

    前端「取消所有剩余」以前逐个发 HTTP 请求,多任务时慢,还可能中途
    被打断留下半取消状态;改为服务端一次循环取消完再返回。
    """
    data = request.get_json(silent=True) or {}
    task_ids = data.get("task_ids") or []
    if not task_ids:
        return jsonify({"code": 400, "msg": "task_ids 不能为空"}), 400
    tq = get_task_queue()
    cancelled = 0
    for tid in task_ids:
        try:
            if tq.cancel_task(tid):
                cancelled += 1
        except Exception as exc:
            logger.warning("[TaskQueue] 批量取消 %s 失败: %s", tid, exc)
    return jsonify({
        "code": 200,
        "msg": f"已请求取消 {cancelled}/{len(task_ids)} 个任务",
        "data": {"cancelled": cancelled, "total": len(task_ids)},
    })


@ext_api.route('/tasks/<task_id>/retry', methods=['POST'])
def retry_task(task_id):
    """重试失败任务"""
    tq = get_task_queue()
    if tq.retry_task(task_id):
        return jsonify({"code": 200, "msg": "任务已重新入队"})
    return jsonify({"code": 400, "msg": "无法重试该任务"}), 400


# ========== SSE 实时推送 ==========

@ext_api.route('/tasks/stream', methods=['GET'])
def task_stream():
    """SSE 实时推送任务状态变更"""
    q = queue.Queue(maxsize=10)

    with _sse_lock:
        _sse_subscribers.append(q)

    def on_status(task: PublishTask):
        try:
            q.put_nowait(json.dumps({
                "id": task.id,
                "status": task.status,
                "platform": task.platform,
                "account": task.account_name,
                "title": task.title,
                "error": task.error_message,
                "timestamp": datetime.now().isoformat(),
            }, ensure_ascii=False))
        except queue.Full:
            pass

    tq = get_task_queue()
    tq.on_status_change(on_status)

    def generate():
        try:
            while True:
                try:
                    data = q.get(timeout=30)
                    yield f"data: {data}\n\n"
                except queue.Empty:
                    yield ": heartbeat\n\n"
        except GeneratorExit:
            with _sse_lock:
                if q in _sse_subscribers:
                    _sse_subscribers.remove(q)

    response = Response(generate(), mimetype='text/event-stream')
    response.headers['Cache-Control'] = 'no-cache'
    response.headers['X-Accel-Buffering'] = 'no'
    return response


# ========== 队列状态 ==========

@ext_api.route('/queue/status', methods=['GET'])
def queue_status():
    """获取任务队列状态"""
    tq = get_task_queue()
    return jsonify({"code": 200, "data": tq.get_status()})


# ========== 发布历史 ==========

def _normalize_detail_row(d):
    """把 publish_details 1 行 dict 规范化：JSON 反序列化 account_configs + 计算 duration"""
    try:
        d['account_configs'] = json.loads(d.get('account_configs', '{}'))
    except json.JSONDecodeError:
        d['account_configs'] = {}
    if d.get('started_at') and d.get('finished_at'):
        try:
            s = datetime.fromisoformat(d['started_at'])
            f = datetime.fromisoformat(d['finished_at'])
            d['duration'] = int((f - s).total_seconds())
        except (ValueError, TypeError):
            d['duration'] = None
    else:
        d['duration'] = None
    # 实时校正 platform 字段：旧数据可能因 platform_map 缺失被写成「未知」
    # 或被前端误写成拼音 key(如 iqiyi / tencent_video)。统一校正为中文名。
    plat = d.get('platform', '') or ''
    if not plat or plat == '未知':
        if d.get('account_id'):
            try:
                conn = _db_conn()
                row = conn.execute(
                    "SELECT type FROM user_info WHERE id = ?", (d['account_id'],)
                ).fetchone()
                conn.close()
                if row:
                    d['platform'] = _PLATFORM_ID_TO_NAME.get(row[0], plat)
            except Exception:
                pass
    elif plat in _PLATFORM_KEY_TO_NAME:
        # 是拼音 key,转成中文名
        d['platform'] = _PLATFORM_KEY_TO_NAME[plat]
    return d


def _serialize_batch_with_items(b, items):
    """把 publish_batches 1 行 + 关联的 publish_details 列表序列化成 API 响应

    列表端点 /history 和单批次端点 /history/<batch_id> 都通过此函数构造每条 batch 的数据。
    """
    # 给每个 detail 注入 personalized 派生字段（按 account_configs vs batch_row 公共值比较）
    for d_item in items:
        d_item['personalized'] = compute_personalized(
            d_item.get('account_configs') or {}, b
        )
    # 兜底：当 batch 列上的 material_id 都为空（封面是从视频抽帧得到的，没有 materials.id）时，
    # 从第一个 detail 的 account_configs 里取 coverLandscape / coverPortrait / thumbnail_path。
    fallback_cover_url = ''
    if items:
        first_cfg = items[0].get('account_configs') or {}
        fallback_cover_url = (
            _resolve_cover_from_path(first_cfg.get('coverLandscape', ''))
            or _resolve_cover_from_path(first_cfg.get('coverPortrait', ''))
            or _resolve_cover_from_path(first_cfg.get('thumbnail_path', ''))
        )
    return {
        'id': b['id'],
        'type': b['type'],
        'title': b.get('title', ''),
        'description': b.get('description', ''),
        'landscape_cover_material_id': b.get('landscape_cover_material_id', ''),
        'portrait_cover_material_id': b.get('portrait_cover_material_id', ''),
        'cover_url': _resolve_cover_url(b.get('landscape_cover_material_id', ''))
                    or _resolve_cover_url(b.get('portrait_cover_material_id', ''))
                    or fallback_cover_url,
        'account_count': b.get('account_count', 0),
        'success_count': b.get('success_count', 0),
        'failed_count': b.get('failed_count', 0),
        'status': b.get('status', 'pending'),
        'schedule_time': b.get('schedule_time', ''),
        # 发布链调度字段（视频间隔）：前端倒计时 = scheduled_at - 当前时间
        'scheduled_at': b.get('scheduled_at', '') or '',
        'interval_minutes': b.get('interval_minutes', 0) or 0,
        'created_at': _to_beijing_time(b.get('created_at')),
        'started_at': _to_beijing_time(b.get('started_at')),
        'finished_at': _to_beijing_time(b.get('finished_at')),
        'items': items,
    }


@ext_api.route('/history', methods=['GET'])
def get_history():
    """获取发布历史（按批次分组），支持分页、平台/状态/类型过滤

    Query: type=video|image (可选), page=1, pageSize=20, include_legacy=0|1
    默认过滤掉 v0.6.0 旧版本数据(account_configs 不含 coverLandscape /
    videoLandscape 任一字段且 source 为空),传 include_legacy=1 看全部。
    """
    type_ = request.args.get('type')
    status = request.args.get('status')
    platform = request.args.get('platform')  # 暂未使用，留扩展
    time_range = request.args.get('timeRange')
    start_date = request.args.get('startDate')
    end_date = request.args.get('endDate')
    include_legacy = request.args.get('include_legacy', '').lower() in ('1', 'true', 'yes')
    page = int(request.args.get('page', 1))
    page_size = int(request.args.get('pageSize', 20))
    offset = (page - 1) * page_size

    if time_range and not start_date:
        now = datetime.now()
        if time_range == 'today':
            start_date = now.strftime('%Y-%m-%d')
        elif time_range == '7days':
            start_date = (now - timedelta(days=7)).strftime('%Y-%m-%d')
        elif time_range == '30days':
            start_date = (now - timedelta(days=30)).strftime('%Y-%m-%d')

    conditions = []
    params = []
    if type_ in ('video', 'image'):
        conditions.append("type = ?")
        params.append(type_)
    if status:
        conditions.append("status = ?")
        params.append(status)
    if start_date:
        conditions.append("created_at >= ?")
        params.append(start_date)
    if end_date:
        conditions.append("created_at <= ?")
        params.append(end_date)
    # 默认过滤旧版本数据(v0.6.0 时代)。判断标准:batch 至少有一个 detail
    # 含 v0.7.0 新字段(coverLandscape / videoLandscape),或 batch.source 非空
    if not include_legacy:
        conditions.append("""EXISTS (
            SELECT 1 FROM publish_details d
            WHERE d.batch_id = publish_batches.id
              AND (
                json_extract(d.account_configs, '$.coverLandscape') IS NOT NULL
                OR json_extract(d.account_configs, '$.videoLandscape') IS NOT NULL
                OR publish_batches.source != ''
              )
        )""")
    where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    try:
        conn = _db_conn()
        total = conn.execute(f"SELECT COUNT(*) FROM publish_batches {where}", params).fetchone()[0]
        rows = conn.execute(
            f"SELECT * FROM publish_batches {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            params + [page_size, offset]
        ).fetchall()
        batches = [dict(r) for r in rows]

        # 拿当前页所有 batch_id 的明细，一次 IN 查询
        if batches:
            batch_ids = [b['id'] for b in batches]
            placeholders = ','.join('?' * len(batch_ids))
            detail_rows = conn.execute(
                f"SELECT * FROM publish_details WHERE batch_id IN ({placeholders}) ORDER BY created_at ASC",
                batch_ids
            ).fetchall()
            details_by_batch: dict[str, list] = {}
            for d in detail_rows:
                dd = _normalize_detail_row(dict(d))
                details_by_batch.setdefault(dd['batch_id'], []).append(dd)
        else:
            details_by_batch = {}

        items = []
        for b in batches:
            batch_details = details_by_batch.get(b['id'], [])
            items.append(_serialize_batch_with_items(b, batch_details))

        conn.close()
        return jsonify({
            "code": 200,
            "data": {"items": items, "total": total, "page": page, "pageSize": page_size}
        })
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/history/<batch_id>', methods=['GET'])
def get_history_batch(batch_id):
    """获取单个发布批次详情（含所有明细）

    Response 200:
        {"code": 200, "data": <Batch with items>}
    Response 404:
        {"code": 404, "msg": "记录不存在或已被删除"}
    """
    try:
        conn = _db_conn()
        row = conn.execute(
            "SELECT * FROM publish_batches WHERE id = ?", (batch_id,)
        ).fetchone()
        if not row:
            conn.close()
            return jsonify({"code": 404, "msg": "记录不存在或已被删除"}), 404

        b = dict(row)
        detail_rows = conn.execute(
            "SELECT * FROM publish_details WHERE batch_id = ? ORDER BY created_at ASC",
            (batch_id,)
        ).fetchall()
        items = [_normalize_detail_row(dict(d)) for d in detail_rows]
        conn.close()

        data = _serialize_batch_with_items(b, items)
        return jsonify({"code": 200, "data": data})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/history/batch', methods=['DELETE'])
def batch_delete_history():
    """发布历史批量删除。

    Body: {"batch_ids": [str, ...]}  (1-50 个批次 id)
    Response 200: {"code": 200, "deleted": [...], "failed": [{batch_id, reason}, ...]}
    Response 400: batch_ids 缺失/非列表/为空/超过 50

    注意：SQLite 默认未启用外键约束，ON DELETE CASCADE 不会触发，
    故需手动删除关联的 publish_details 行。
    """
    data = request.get_json() or {}
    batch_ids = data.get('batch_ids') or []
    if not isinstance(batch_ids, list) or not batch_ids or len(batch_ids) > 50:
        return jsonify({"code": 400, "msg": "batch_ids 数量必须 1-50"}), 400

    conn = _db_conn()
    try:
        placeholders = ','.join('?' * len(batch_ids))
        existing = {r[0] for r in conn.execute(
            f"SELECT id FROM publish_batches WHERE id IN ({placeholders})", batch_ids
        ).fetchall()}

        deleted = []
        failed = []
        for bid in batch_ids:
            if bid in existing:
                try:
                    # 外键约束未启用，手动级联删除明细
                    conn.execute("DELETE FROM publish_details WHERE batch_id = ?", (bid,))
                    conn.execute("DELETE FROM publish_batches WHERE id = ?", (bid,))
                    deleted.append(bid)
                except Exception as e:
                    failed.append({'batch_id': bid, 'reason': str(e)})
            else:
                failed.append({'batch_id': bid, 'reason': '记录不存在'})

        conn.commit()
        return jsonify({"code": 200, "deleted": deleted, "failed": failed}), 200
    except Exception as e:
        conn.rollback()
        return jsonify({"code": 500, "msg": str(e)}), 500
    finally:
        conn.close()


@ext_api.route('/history/<batch_id>', methods=['DELETE'])
def delete_history_batch(batch_id):
    """删除单条发布历史记录。

    Response 200: {"code": 200, "msg": "已删除"}
    Response 404: {"code": 404, "msg": "记录不存在或已被删除"}

    注意：SQLite 默认未启用外键约束，ON DELETE CASCADE 不会触发，
    故需手动删除关联的 publish_details 行。
    """
    conn = _db_conn()
    try:
        row = conn.execute(
            "SELECT id FROM publish_batches WHERE id = ?", (batch_id,)
        ).fetchone()
        if not row:
            return jsonify({"code": 404, "msg": "记录不存在或已被删除"}), 404

        conn.execute("DELETE FROM publish_details WHERE batch_id = ?", (batch_id,))
        conn.execute("DELETE FROM publish_batches WHERE id = ?", (batch_id,))
        conn.commit()
        return jsonify({"code": 200, "msg": "已删除"}), 200
    except Exception as e:
        conn.rollback()
        return jsonify({"code": 500, "msg": str(e)}), 500
    finally:
        conn.close()


# ========== 统计数据 ==========

@ext_api.route('/stats', methods=['GET'])
def get_stats():
    """获取统计数据（成功率、发布量趋势等）"""
    try:
        conn = _db_conn()

        # 总体统计（读 publish_batches：每次"发布"= 1 个 batch）
        total = conn.execute("SELECT COUNT(*) FROM publish_batches").fetchone()[0]
        success = conn.execute("SELECT COUNT(*) FROM publish_batches WHERE status='success'").fetchone()[0]
        failed = conn.execute("SELECT COUNT(*) FROM publish_batches WHERE status='failed'").fetchone()[0]
        running = conn.execute("SELECT COUNT(*) FROM publish_batches WHERE status IN ('pending','queued','running')").fetchone()[0]

        # 按平台统计（明细行才有 platform 字段，从 publish_details 聚合）
        platform_rows = conn.execute(
            "SELECT platform, COUNT(*) as count FROM publish_details GROUP BY platform"
        ).fetchall()
        by_platform = {row['platform']: row['count'] for row in platform_rows}

        # 最近7天趋势（以 batch 的 created_at 为口径）
        trend = []
        for i in range(6, -1, -1):
            date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
            next_date = (datetime.now() - timedelta(days=i-1)).strftime('%Y-%m-%d') if i > 0 else (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
            count = conn.execute(
                "SELECT COUNT(*) FROM publish_batches WHERE created_at >= ? AND created_at < ?",
                (date, next_date)
            ).fetchone()[0]
            trend.append({"date": date, "count": count})

        # 本月发布数
        month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0).strftime('%Y-%m-%d')
        monthly_total = conn.execute(
            "SELECT COUNT(*) FROM publish_batches WHERE created_at >= ?", (month_start,)
        ).fetchone()[0]

        # 账号统计
        account_count = conn.execute("SELECT COUNT(*) FROM user_info").fetchone()[0]
        account_normal = conn.execute("SELECT COUNT(*) FROM user_info WHERE status=1").fetchone()[0]

        # 素材统计
        material_count = conn.execute("SELECT COUNT(*) FROM file_records").fetchone()[0]

        conn.close()

        success_rate = round(success / total * 100, 1) if total > 0 else 0

        return jsonify({"code": 200, "data": {
            # 发布历史页面直接使用的字段
            "total": total,
            "successRate": success_rate,
            "monthlyTotal": monthly_total,
            # 详细任务统计
            "tasks": {"total": total, "success": success, "failed": failed, "running": running, "successRate": success_rate},
            "byPlatform": by_platform,
            "trend": trend,
            "accounts": {"total": account_count, "normal": account_normal},
            "materials": {"total": material_count},
        }})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


# ========== 系统设置 ==========


@ext_api.route('/settings', methods=['GET'])
def get_settings():
    """获取系统设置"""
    try:
        conn = _db_conn()
        rows = conn.execute("SELECT key, value FROM settings").fetchall()
        settings = {row['key']: row['value'] for row in rows}
        conn.close()

        # 默认值
        defaults = {
            "publishInterval": "30",
            "maxConcurrent": "2",
            "browserMode": "headed",
            "heartbeatInterval": "3600",
            "autoFillTitle": "true",
            "autoSaveDraft": "true",
            "autoSaveInterval": "10",
            "accountCheckMode": "pre-publish",
            "batchTaskInterval": "0",
        }
        defaults.update(settings)
        # 转换布尔值类型
        for key in ['autoFillTitle', 'autoSaveDraft']:
            if key in defaults:
                defaults[key] = defaults[key] in ('true', 'True', '1', True)
        # 转换数值类型
        for key in ['publishInterval', 'maxConcurrent', 'heartbeatInterval',
                    'autoSaveInterval', 'batchTaskInterval']:
            if key in defaults:
                try:
                    defaults[key] = int(defaults[key])
                except (ValueError, TypeError):
                    pass

        # storage / proxyUrl 从 SQLite 读取（JSON 类型字段需要解析）
        if 'storage' in defaults:
            try:
                defaults['storage'] = json.loads(defaults['storage'])
            except (json.JSONDecodeError, TypeError):
                defaults['storage'] = {'type': 'local', 's3': {}}
        else:
            defaults['storage'] = {'type': 'local', 's3': {}}
        if 'proxyUrl' not in defaults:
            defaults['proxyUrl'] = ''

        return jsonify({"code": 200, "data": defaults})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/settings', methods=['PUT'])
def update_settings():
    """更新系统设置"""
    data = request.get_json()
    if not data:
        return jsonify({"code": 400, "msg": "请求数据不能为空"}), 400

    try:
        need_reset_storage = 'storage' in data

        # 所有设置统一写入 SQLite（包括 storage / proxyUrl）
        conn = _db_conn()
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                value = json.dumps(value, ensure_ascii=False)
            else:
                value = str(value)
            conn.execute(
                """INSERT OR REPLACE INTO settings (key, value, updated_at)
                   VALUES (?, ?, ?)""",
                (key, value, datetime.now().isoformat())
            )
        conn.commit()
        conn.close()

        if need_reset_storage:
            from storage import reset_storage
            reset_storage()

        return jsonify({"code": 200, "msg": "设置已更新"})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


# ========== 草稿箱 ==========

# 平台 ID → (key, 名称) 映射。key 必须与 frontend config/platforms.js 一致,
# 否则草稿箱 getPlatformLogo() 匹配不到 logo。
_PLATFORM_ID_MAP = {
    1: ('xiaohongshu', '小红书'),
    2: ('channels', '视频号'),
    3: ('douyin', '抖音'),
    4: ('kuaishou', '快手'),
    5: ('bilibili', 'B站'),
    6: ('baijiahao', '百家号'),
    7: ('tiktok', 'TikTok'),
    8: ('youtube', 'YouTube'),
    9: ('tencent_video', '腾讯视频'),
    10: ('iqiyi', '爱奇艺'),
    11: ('weibo', '微博'),
    12: ('alipay', '支付宝'),
    13: ('toutiao', '今日头条'),
    14: ('zhihu', '知乎'),
    15: ('csdn', 'CSDN'),
    16: ('vivo', 'VIVO'),
    17: ('weixin_gzh', '微信公众号'),
    18: ('taobao_guanghe', '淘宝光合'),
    19: ('jingmai', '京东京麦'),
    # 注: jd (id=20) 与 jingmai 是同一产品,不单独映射
    21: ('dayu', '大鱼号'),
}


def _extract_image_channels_from_draft(conn, draft_data):
    """从图文草稿的 draft_data 中提取渠道摘要（兜底）"""
    account_ids = draft_data.get('publishAccountIds', [])
    if not account_ids:
        return []
    try:
        placeholders = ','.join(['?'] * len(account_ids))
        rows = conn.execute(
            f"SELECT type FROM user_info WHERE id IN ({placeholders})", account_ids
        ).fetchall()
        counts = {}
        for row in rows:
            key, name = _PLATFORM_ID_MAP.get(row['type'], (str(row['type']), f'平台{row["type"]}'))
            if key not in counts:
                counts[key] = {'name': name, 'count': 0}
            counts[key]['count'] += 1
        return [{"platform": k, "name": v['name'], "count": v['count']} for k, v in counts.items()]
    except Exception:
        return []


@ext_api.route('/drafts', methods=['GET'])
def get_drafts():
    """获取草稿列表（支持 type 过滤：video/image）"""
    draft_type = request.args.get('type')
    try:
        conn = _db_conn()
        if draft_type:
            rows = conn.execute(
                "SELECT id, type, title, cover_path, channels_summary, video_duration, video_file_size, draft_data, created_at, updated_at FROM drafts WHERE type = ? ORDER BY updated_at DESC",
                (draft_type,)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT id, type, title, cover_path, channels_summary, video_duration, video_file_size, draft_data, created_at, updated_at FROM drafts ORDER BY updated_at DESC"
            ).fetchall()
        drafts = []
        for row in rows:
            d = dict(row)
            try:
                d['channels_summary'] = json.loads(d.get('channels_summary', '[]'))
            except json.JSONDecodeError:
                d['channels_summary'] = []

            # 统一实时重算 channels_summary:存库快照可能在新增平台后过期
            # (例如之前漏了今日头条),从 draft_data.publishAccountIds 重算可保证
            # 历史草稿也能正确显示所有渠道。视频/图集共用同一段提取逻辑。
            if d.get('draft_data'):
                try:
                    dd = json.loads(d['draft_data'])
                    recomputed = _extract_image_channels_from_draft(conn, dd)
                    if recomputed:
                        d['channels_summary'] = recomputed
                except (json.JSONDecodeError, KeyError):
                    pass
            d.pop('draft_data', None)  # 不在列表接口返回完整 draft_data

            d['created_at'] = _to_beijing_time(d.get('created_at'))
            d['updated_at'] = _to_beijing_time(d.get('updated_at'))
            drafts.append(d)
        conn.close()
        return jsonify({"code": 200, "data": drafts})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/drafts', methods=['POST'])
def create_draft():
    """创建草稿"""
    data = request.get_json()
    if not data or not data.get('draft_data'):
        return jsonify({"code": 400, "msg": "草稿数据不能为空"}), 400

    draft_data = data['draft_data']
    draft_type = data.get('type', 'video')  # 默认视频类型
    title = _extract_draft_title(draft_data)
    cover_path = _extract_draft_cover(draft_data)
    channels_summary = _extract_channels_summary(draft_data)
    video_duration = _extract_video_duration(draft_data)
    video_file_size = _extract_video_file_size(draft_data)

    try:
        conn = _db_conn()
        cursor = conn.execute(
            """INSERT INTO drafts (type, title, cover_path, draft_data, channels_summary, video_duration, video_file_size)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (draft_type, title, cover_path, json.dumps(draft_data, ensure_ascii=False),
             json.dumps(channels_summary, ensure_ascii=False),
             video_duration, video_file_size)
        )
        conn.commit()
        draft_id = cursor.lastrowid
        conn.close()
        return jsonify({"code": 200, "data": {"id": draft_id, "title": title}})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/drafts/<int:draft_id>', methods=['GET'])
def get_draft(draft_id):
    """获取草稿详情"""
    try:
        conn = _db_conn()
        row = conn.execute("SELECT * FROM drafts WHERE id = ?", (draft_id,)).fetchone()
        conn.close()
        if not row:
            return jsonify({"code": 404, "msg": "草稿不存在"}), 404
        d = dict(row)
        try:
            d['channels_summary'] = json.loads(d.get('channels_summary', '[]'))
        except json.JSONDecodeError:
            d['channels_summary'] = []
        try:
            d['draft_data'] = json.loads(d.get('draft_data', '{}'))
        except json.JSONDecodeError:
            d['draft_data'] = {}
        d['created_at'] = _to_beijing_time(d.get('created_at'))
        d['updated_at'] = _to_beijing_time(d.get('updated_at'))
        return jsonify({"code": 200, "data": d})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/drafts/<int:draft_id>', methods=['PUT'])
def update_draft(draft_id):
    """更新草稿"""
    data = request.get_json()
    if not data or not data.get('draft_data'):
        return jsonify({"code": 400, "msg": "草稿数据不能为空"}), 400

    draft_data = data['draft_data']
    title = _extract_draft_title(draft_data)
    cover_path = _extract_draft_cover(draft_data)
    channels_summary = _extract_channels_summary(draft_data)
    video_duration = _extract_video_duration(draft_data)
    video_file_size = _extract_video_file_size(draft_data)

    try:
        conn = _db_conn()
        changes = conn.execute(
            """UPDATE drafts SET title=?, cover_path=?, draft_data=?, channels_summary=?,
               video_duration=?, video_file_size=?, updated_at=CURRENT_TIMESTAMP WHERE id=?""",
            (title, cover_path, json.dumps(draft_data, ensure_ascii=False),
             json.dumps(channels_summary, ensure_ascii=False),
             video_duration, video_file_size, draft_id)
        ).rowcount
        conn.commit()
        conn.close()
        if changes == 0:
            return jsonify({"code": 404, "msg": "草稿不存在"}), 404
        return jsonify({"code": 200, "data": {"id": draft_id, "title": title}})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


@ext_api.route('/drafts/<int:draft_id>', methods=['DELETE'])
def delete_draft(draft_id):
    """删除草稿"""
    try:
        conn = _db_conn()
        changes = conn.execute("DELETE FROM drafts WHERE id = ?", (draft_id,)).rowcount
        conn.commit()
        conn.close()
        if changes == 0:
            return jsonify({"code": 404, "msg": "草稿不存在"}), 404
        return jsonify({"code": 200, "msg": "草稿已删除"})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)}), 500


# ---------- Draft metadata extraction helpers ----------

def _active_draft_view(draft_data):
    """v2 批量草稿（version=2, videos[]）→ 当前视频的单视频视图；v1 原样返回。"""
    if isinstance(draft_data, dict) and draft_data.get('version') == 2:
        videos = draft_data.get('videos') or []
        idx = draft_data.get('currentIndex') or 0
        if 0 <= idx < len(videos):
            return videos[idx] or {}
        return videos[0] if videos else {}
    return draft_data


def _extract_draft_title(draft_data):
    """从草稿数据中提取标题（第一个非空的平台标题）"""
    draft_data = _active_draft_view(draft_data)
    pc = draft_data.get('platformConfigs', {})
    for key in ['douyin', 'xiaohongshu', 'kuaishou', 'bilibili', 'channels',
                'baijiahao', 'tiktok', 'youtube', 'iqiyi', 'tencent_video']:
        title = pc.get(key, {}).get('title', '')
        if title and title.strip():
            return title.strip()[:100]
    return '无标题'


def _extract_draft_cover(draft_data):
    """从草稿数据中提取封面路径或URL"""
    draft_data = _active_draft_view(draft_data)
    cc = draft_data.get('commonConfig', {})
    for key in ['coverPortrait', 'coverLandscape']:
        cover = cc.get(key)
        if cover:
            if cover.get('path'):
                return cover['path']
            if cover.get('url'):
                return cover['url']
    return ''


def _extract_channels_summary(draft_data):
    """从草稿数据中提取渠道摘要（按平台分组计数）"""
    draft_data = _active_draft_view(draft_data)
    account_ids = draft_data.get('publishAccountIds', [])
    if not account_ids:
        return []

    platform_map = {
        'xiaohongshu': '小红书', 'channels': '视频号', 'douyin': '抖音',
        'kuaishou': '快手', 'bilibili': 'B站', 'baijiahao': '百家号',
        'tiktok': 'TikTok', 'youtube': 'YouTube', 'iqiyi': '爱奇艺',
        'tencent_video': '腾讯视频',
        'weibo': '微博', 'alipay': '支付宝', 'toutiao': '今日头条', 'zhihu': '知乎',
        'csdn': 'CSDN', 'vivo': 'VIVO', 'weixin_gzh': '微信公众号',
        'taobao_guanghe': '淘宝光合', 'jingmai': '京东京麦', 'dayu': '大鱼号',
    }

    try:
        conn = _db_conn()
        placeholders = ','.join(['?'] * len(account_ids))
        rows = conn.execute(
            f"SELECT id, type FROM user_info WHERE id IN ({placeholders})",
            account_ids
        ).fetchall()
        conn.close()

        type_to_platform = {v: k for k, v in {
            'xiaohongshu': 1, 'channels': 2, 'douyin': 3,
            'kuaishou': 4, 'bilibili': 5,
            'baijiahao': 6, 'tiktok': 7, 'youtube': 8,
            'tencent_video': 9, 'iqiyi': 10,
            'weibo': 11, 'alipay': 12, 'toutiao': 13, 'zhihu': 14, 'csdn': 15,
            'vivo': 16, 'weixin_gzh': 17,
            'taobao_guanghe': 18, 'jingmai': 19, 'dayu': 21,
        }.items()}

        platform_counts = {}
        for row in rows:
            pkey = type_to_platform.get(row['type'])
            if pkey:
                platform_counts[pkey] = platform_counts.get(pkey, 0) + 1

        return [{"platform": k, "name": platform_map.get(k, k), "count": v}
                for k, v in platform_counts.items()]
    except Exception:
        return []


def _extract_video_duration(draft_data):
    """从草稿数据中提取视频时长（暂存0，后续可从抽帧结果中获取）"""
    return 0


def _extract_video_file_size(draft_data):
    """从草稿数据中提取视频文件大小"""
    draft_data = _active_draft_view(draft_data)
    cc = draft_data.get('commonConfig', {})
    for key in ['videoPortrait', 'videoLandscape']:
        video = cc.get(key)
        if video and video.get('size'):
            return video['size']
    return 0


# ========== 更新日志 ==========

@ext_api.route('/changelog', methods=['GET'])
def get_changelog():
    """获取更新日志列表（按文件名倒序）"""
    import os
    changelog_dir = Path(__file__).parent.parent.parent / "changelog"
    if not changelog_dir.exists():
        changelog_dir = BASE_DIR / "changelog"
    if not changelog_dir.exists():
        return jsonify({"code": 200, "data": []})

    files = []
    for f in sorted(changelog_dir.iterdir()):
        if f.is_file() and f.suffix == '.html':
            # 从文件名提取日期 (20260525.html -> 2026-05-25)
            name = f.stem
            if len(name) == 8 and name.isdigit():
                date_str = f"{name[:4]}-{name[4:6]}-{name[6:8]}"
            else:
                date_str = name
            files.append({
                "filename": f.name,
                "date": date_str,
                "url": f"/changelog/{f.name}",
            })

    files.sort(key=lambda x: x['date'], reverse=True)
    return jsonify({"code": 200, "data": files})


# ========== 平台元数据（MCP / AI 自描述） ==========

@ext_api.route('/platforms', methods=['GET'])
def get_platforms():
    """平台清单 + 各平台发布配置元数据。

    registry 自动枚举平台（新平台注册后本端点自动可见），impl.platform_meta
    补充发布字段定义（default_config / fields / schedule）。
    """
    from impl.registry import iter_platforms
    from impl.platform_meta import build_platform_entry

    platforms = [
        build_platform_entry(p["platform_id"], p["platform_key"], p["platform_name"])
        for p in iter_platforms()
    ]
    return jsonify({"code": 200, "data": {"platforms": platforms}})


# ========== API 目录自省（MCP / AI 自动发现新端点） ==========

@ext_api.route('/api-catalog', methods=['GET'])
def get_api_catalog():
    """枚举当前应用全部 HTTP 路由（path/methods/doc）。

    后端新增任何路由，本端点自动可见——MCP 的 api_catalog / api_call
    工具据此发现并调用未封装为专用工具的新能力。
    Query: prefix（可选，按路径前缀过滤）
    """
    from flask import current_app

    prefix = (request.args.get('prefix') or '').strip()
    skip_paths = {'/', '/favicon.ico', '/vite.svg'}
    skip_prefixes = ('/assets/', '/changelog/', '/static/')

    items = []
    for rule in current_app.url_map.iter_rules():
        if rule.endpoint == 'static':
            continue
        path = rule.rule
        if path in skip_paths or path.startswith(skip_prefixes):
            continue
        if prefix and not path.startswith(prefix):
            continue
        view = current_app.view_functions.get(rule.endpoint)
        doc = ''
        if view is not None and getattr(view, '__doc__', None):
            # 首行文档（多行 docstring 取第一非空行）
            doc = next((ln.strip() for ln in view.__doc__.splitlines() if ln.strip()), '')
        items.append({
            "path": path,
            "methods": sorted(m for m in rule.methods if m not in ('HEAD', 'OPTIONS')),
            "endpoint": rule.endpoint,
            "doc": doc,
        })

    items.sort(key=lambda it: (it['path'], ','.join(it['methods'])))
    return jsonify({"code": 200, "data": {"total": len(items), "apis": items}})


# ========== 一键填写模板 ==========

@ext_api.route('/publish-templates', methods=['GET'])
def get_publish_templates():
    """一键填写：从历史成功/部分成功批次里取可复用的 per-channel 配置。

    Query: type=video|image (必填), page=1, page_size=20
    """
    type_ = request.args.get('type', '').strip()
    if type_ not in ('video', 'image'):
        return jsonify({"code": 400, "msg": "type 必须是 video 或 image"}), 400

    try:
        page = int(request.args.get('page', 1))
        page_size = min(int(request.args.get('page_size', 20)), 100)
    except ValueError:
        return jsonify({"code": 400, "msg": "page / page_size 必须是整数"}), 400

    offset = (page - 1) * page_size
    conn = _db_conn()

    # 主查询：所有有 detail 带 account_configs 的成功/部分成功 batch
    rows = conn.execute(
        """SELECT b.id, b.type, b.title, b.description,
                  b.landscape_cover_material_id, b.portrait_cover_material_id,
                  b.video_material_id, b.image_material_ids,
                  b.created_at
           FROM publish_batches b
           WHERE b.type = ?
             AND b.status IN ('success', 'partial')
             AND EXISTS (SELECT 1 FROM publish_details d
                         WHERE d.batch_id = b.id AND d.account_configs != '{}')
           ORDER BY b.created_at DESC
           LIMIT ? OFFSET ?""",
        (type_, page_size, offset)
    ).fetchall()
    total = conn.execute(
        """SELECT COUNT(*) FROM publish_batches b
           WHERE b.type = ? AND b.status IN ('success', 'partial')
             AND EXISTS (SELECT 1 FROM publish_details d
                         WHERE d.batch_id = b.id AND d.account_configs != '{}')""",
        (type_,)
    ).fetchone()[0]

    # 解析 cover material_id → stored_path（thumbnail_path 必须是真实文件路径，
    # 前端 OneClickFillDialog 会拼到 /uploads/<path> 上）
    cover_ids = [
        r['landscape_cover_material_id'] or r['portrait_cover_material_id'] or ''
        for r in rows
    ]
    cover_ids = [cid for cid in cover_ids if cid]
    if cover_ids:
        placeholders = ','.join('?' * len(cover_ids))
        cover_rows = conn.execute(
            f"SELECT id, stored_path FROM materials WHERE id IN ({placeholders})",
            cover_ids
        ).fetchall()
        cover_path_map = {r['id']: r['stored_path'] for r in cover_rows}
    else:
        cover_path_map = {}

    conn.close()

    items = []
    for r in rows:
        # 拿第一个 detail 的 account_configs（用作可复用模板）
        # 单次小查询，按 batch_id 升序拿第一条
        dconn = _db_conn()
        first_detail = dconn.execute(
            "SELECT account_configs, platform FROM publish_details WHERE batch_id = ? "
            "AND account_configs != '{}' ORDER BY created_at ASC LIMIT 1",
            (r['id'],)
        ).fetchone()
        # 拿所有 platform 作 channels 列表
        all_platforms = dconn.execute(
            "SELECT DISTINCT platform FROM publish_details WHERE batch_id = ?",
            (r['id'],)
        ).fetchall()
        dconn.close()

        configs = json.loads((first_detail['account_configs'] if first_detail else None) or '{}')
        channels = [{'platform': p['platform']} for p in all_platforms if p['platform']]

        # cover 优先 landscape，回落 portrait；material_id 解析到 stored_path
        cover_id = r['landscape_cover_material_id'] or r['portrait_cover_material_id'] or ''
        thumbnail_path = cover_path_map.get(cover_id, '')

        # image_material_ids 是 JSON 数组字符串，取第一个元素作为 first_image_id
        img_ids_raw = r['image_material_ids'] or '[]'
        try:
            img_ids_list = json.loads(img_ids_raw)
            first_image_id = img_ids_list[0] if img_ids_list else None
        except (json.JSONDecodeError, TypeError):
            first_image_id = None

        items.append({
            "id": r['id'],
            "type": r['type'],
            "title": r['title'] or '',
            "description": r['description'] or '',
            "thumbnail_path": thumbnail_path,
            "first_image_id": first_image_id,
            "video_material_id": r['video_material_id'] or '',
            "channels": channels,
            "account_configs": configs,
            "created_at": r['created_at'],
        })

    return jsonify({
        "code": 200,
        "data": {
            "list": items,
            "total": total,
            "page": page,
            "page_size": page_size,
        }
    })


# ========== 草稿批量发布 ==========
@ext_api.route('/drafts/batch-publish', methods=['POST'])
def batch_publish_drafts():
    """视频草稿批量发布：每个 (draft, account) 入队 1 个 task。

    Body: {"draft_ids": [int, ...]}  (1-30 个视频草稿 id)
    v2 批量草稿（videos[]）按视频拆分，每个视频独立校验 + 独立 batch。
    Response: {"code": 200, "task_ids": [...], "failed": [...]}
    """
    data = request.get_json() or {}
    draft_ids = data.get('draft_ids') or []
    if not isinstance(draft_ids, list) or not draft_ids or len(draft_ids) > 30:
        return jsonify({"code": 400, "msg": "draft_ids 数量必须 1-30"}), 400

    from app import _get_db_path, PLATFORM_ID_TO_KEY, PLATFORM_MAP
    db_path = _get_db_path()
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    placeholders = ','.join('?' * len(draft_ids))
    rows = conn.execute(
        f"SELECT id, type, draft_data FROM drafts WHERE id IN ({placeholders})",
        draft_ids
    ).fetchall()
    conn.close()

    found_ids = {r['id'] for r in rows}
    missing_ids = [i for i in draft_ids if i not in found_ids]
    if missing_ids:
        return jsonify({"code": 404, "msg": "草稿不存在", "missing_ids": missing_ids}), 404

    wrong_type = [r['id'] for r in rows if r['type'] != 'video']
    if wrong_type:
        return jsonify({"code": 400, "msg": "包含非视频草稿", "wrong_type_ids": wrong_type}), 400

    # 反向映射：platform key → 整数平台 id（给 PublishTask.platform_type）
    KEY_TO_PLATFORM_ID = {v: k for k, v in PLATFORM_ID_TO_KEY.items()}

    # 通过模块属性查找 get_task_queue，让 monkeypatch.setattr(tq, 'get_task_queue', ...)
    # 能生效（直接调用本模块的 get_task_queue 会绕过 patch）。
    from . import task_queue as _tq
    task_queue = _tq.get_task_queue()
    task_ids = []
    failed = []
    # batch_key → batch_id 映射，让同一 draft/视频 的多个 detail 共享一个 batch
    task_batch_id_by_draft = {}

    def _draft_video_views(draft_data):
        """v2 批量草稿 → videos[] 单视频视图列表；v1 → [draft_data] 自身。"""
        if isinstance(draft_data, dict) and draft_data.get('version') == 2:
            return list(draft_data.get('videos') or []) or [{}]
        return [draft_data]

    for r in rows:
        raw_data = json.loads(r['draft_data'] or '{}')
        views = _draft_video_views(raw_data)
        for vi, view in enumerate(views):
            # v2 多视频：每个视频独立 batch；v1 单视频：整个草稿一个 batch
            batch_key = str(r['id']) if len(views) == 1 else f"{r['id']}:{vi}"
            draft = {'id': r['id'], 'type': r['type'], 'draft_data': view}
            try:
                errs = validate_draft_for_publish(draft)
                if errs:
                    failed.append({'draft_id': r['id'], 'reason': '; '.join(errs)})
                    continue

                draft_data = draft['draft_data']
                common = draft_data.get('commonConfig') or {}
                platform_configs = draft_data.get('platformConfigs') or {}
                account_overrides = draft_data.get('accountOverrides') or {}
                publish_account_ids = draft_data.get('publishAccountIds') or []

                for account_id in publish_account_ids:
                    # 查 user_info（生产 schema: id, type INTEGER, filePath TEXT）
                    acc_conn = sqlite3.connect(str(db_path))
                    acc_conn.row_factory = sqlite3.Row
                    acc_row = acc_conn.execute(
                        "SELECT id, type, filePath, userName FROM user_info WHERE id = ?",
                        (account_id,),
                    ).fetchone()
                    acc_conn.close()
                    if not acc_row:
                        failed.append({'draft_id': r['id'], 'reason': f'账号 {account_id} 不存在'})
                        continue

                    account_platform = PLATFORM_ID_TO_KEY.get(acc_row['type'], '')
                    platform_default = platform_configs.get(account_platform) or {}
                    account_ov = account_overrides.get(str(account_id)) or {}

                    platform_overrides = draft_data.get('platformOverrides') or {}
                    merged = merge_config(
                        common, platform_default,
                        platform_overrides.get(account_platform),
                        account_ov,
                    )

                    account_obj = type('Account', (), {})()
                    account_obj.id = acc_row['id']
                    account_obj.platform = account_platform
                    account_obj.file_path = acc_row['filePath']

                    payload = build_platform_kwargs(merged, common, account_obj)

                    ptype = KEY_TO_PLATFORM_ID.get(account_platform)
                    if not ptype:
                        failed.append({'draft_id': r['id'], 'reason': f'未知平台: {account_platform}'})
                        continue

                    task_id = str(uuid.uuid4())
                    # 草稿批量发布：每个 (draft, account) 一个 detail，但同一 draft 的所有 detail 共享一个 batch_id
                    # （task.batch_id 第一次循环时初始化，后续同 draft 共享；这里每个 draft_id 只一次循环无问题）
                    if not task_batch_id_by_draft.get(batch_key):
                        task_batch_id_by_draft[batch_key] = str(uuid.uuid4())
                    # 把 stored_path 相对路径转成绝对路径（与 postVideo 的 _resolve_material_path 一致）
                    # 否则 worker 拿相对路径去 set_input_files，Playwright 找不到文件，会触发 3 次重试。
                    from storage import resolve_material_path
                    raw_video = (payload.get('files') or [''])[0]
                    raw_thumbnail = payload.get('thumbnail_path', '') or ''
                    resolved_video = resolve_material_path(raw_video)
                    resolved_thumbnail = resolve_material_path(raw_thumbnail)
                    if not resolved_video:
                        # 文件解析失败（草稿里引用了已被用户从磁盘删除的文件），直接标记失败，
                        # 避免 worker 重复开浏览器重试 3 次。
                        failed.append({
                            'draft_id': r['id'],
                            'reason': f'账号 {account_id} 视频文件不存在: {raw_video}',
                        })
                        continue
                    task = PublishTask(
                        id=task_id,
                        batch_id=task_batch_id_by_draft[batch_key],
                        # platform 列存中文名(与 /postVideo 链路一致)。拼音 key 会让
                        # 发布历史 platformList 按名匹配失败 → 显示拼音且无 logo。
                        platform=PLATFORM_MAP.get(acc_row['type'], account_platform),
                        platform_type=ptype,
                        account_name=acc_row['userName'] or '',
                        account_cookie_path=acc_row['filePath'] or '',
                        video_path=resolved_video,
                        title=payload.get('title', ''),
                        description=payload.get('desc', ''),
                        thumbnail_path=resolved_thumbnail,
                        tags=payload.get('tags') or [],
                        # 媒体/定时个性化字段：写入 account_configs 供发布历史还原封面
                        video_landscape=merged.get('videoLandscape'),
                        video_portrait=merged.get('videoPortrait'),
                        cover_landscape=merged.get('coverLandscape'),
                        cover_portrait=merged.get('coverPortrait'),
                        enable_timer=payload.get('enableTimer'),
                        schedule_time=payload.get('schedule_time_str'),
                        ai_content=payload.get('ai_content'),
                        is_original=payload.get('is_original'),
                        source='draft',
                        draft_id=r['id'],
                        account_id=account_id,
                        payload=payload,
                        # 草稿批量发布:失败立即标记 FAILED,不重试(用户需求)
                        max_retries=0,
                    )
                    try:
                        task_queue.add_task(task)
                        task_ids.append(task_id)
                    except Exception as e:
                        failed.append({'draft_id': r['id'], 'reason': f'入队失败: {e}'})
            except Exception as e:
                failed.append({'draft_id': r['id'], 'reason': str(e)})

    return jsonify({"code": 200, "task_ids": task_ids, "failed": failed}), 200


# ========== 批量视频发布（发布页视频队列） ==========

def _lookup_material_duration_size(stored_path: str):
    """按 stored_path 查素材表 duration/file_size。查不到返回 (None, None)。

    duration<=0 时尝试同步补全（与 app._validate_publish_video 同语义），
    补全失败则跳过校验（返回 None）。
    """
    if not stored_path:
        return None, None
    try:
        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT duration, file_size FROM materials WHERE stored_path = ?",
            (stored_path,),
        ).fetchone()
        if row and (not row["duration"] or row["duration"] <= 0):
            conn.close()
            try:
                from services.duration_repair import ensure_duration_or_probe
                ensure_duration_or_probe(stored_path, row["duration"])
            except Exception:
                pass
            conn = sqlite3.connect(str(DB_PATH))
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT duration, file_size FROM materials WHERE stored_path = ?",
                (stored_path,),
            ).fetchone()
        conn.close()
    except Exception:
        return None, None
    if row is None:
        return None, None
    return row["duration"], row["file_size"]


def _validate_batch_account(platform_key: str, merged: dict) -> list:
    """批量发布逐账号补充校验：标题/描述长度 + 视频时长/大小。

    与 /postVideo 的校验同源（util/video_limits）。返回错误消息列表。
    """
    from util.video_limits import (
        validate_title_for_platform, validate_desc_for_platform,
        validate_video_for_platform,
    )
    errs = []

    ok, err = validate_title_for_platform(platform_key, merged.get('title') or '')
    if not ok:
        errs.append(err)

    ok, err = validate_desc_for_platform(platform_key, merged.get('description') or '')
    if not ok:
        errs.append(err)

    video = merged.get('videoLandscape') or merged.get('videoPortrait') or {}
    stored = video.get('stored_path') if isinstance(video, dict) else ''
    duration, size = _lookup_material_duration_size(stored or '')
    if duration:
        ok, err = validate_video_for_platform(platform_key, duration, size or 0)
        if not ok:
            errs.append(err)
    return errs


@ext_api.route('/videos/batch-publish', methods=['POST'])
def videos_batch_publish():
    """批量视频发布：videos[] 为发布页每个视频的完整 draft_data 快照。

    Body: {"videos": [ {commonConfig, platformConfigs, platformOverrides,
                        accountOverrides, publishAccountIds, ...}, ... ],
           "interval_minutes": <可选, 数字, 仅本次批量生效>}
    每个视频 × 其账号集合 → 逐账号 1 个 PublishTask；同一视频的任务共享
    1 个 batch_id（发布历史按视频聚合）。source='batch'，失败不自动重试，
    可在任务中心手动重试。数量不限。

    interval_minutes：发布页「视频发布间隔」输入框的值，单位分钟。
    0 = 发布完一个视频立即开始下一个；>0 = 等满分钟再发下一个视频。
    仅本次批量生效，覆盖全局 settings.batchTaskInterval。

    Response: {"code": 200, "data": {"task_ids": [...], "batch_ids": [...],
               "failed": [{"video": <下标>, "reason": "..."}]}}
    """
    data = request.get_json() or {}
    videos = data.get('videos')
    if not isinstance(videos, list) or not videos:
        return jsonify({"code": 400, "msg": "videos 必须是非空数组"}), 400

    # 间隔（分钟）：缺省 / 非法值 / 负数都规整为 0（= 不等待，立即发下一个）。
    raw_interval = data.get('interval_minutes')
    try:
        batch_interval_minutes = max(0.0, float(raw_interval)) if raw_interval is not None else 0.0
    except (TypeError, ValueError):
        batch_interval_minutes = 0.0

    from app import PLATFORM_ID_TO_KEY, PLATFORM_MAP
    KEY_TO_PLATFORM_ID = {v: k for k, v in PLATFORM_ID_TO_KEY.items()}

    from . import task_queue as _tq
    task_queue = _tq.get_task_queue()
    task_ids = []
    batch_ids = []
    failed = []
    # 发布链：本批次有效视频的 batch_id 顺序表（链头立即发布，其余按间隔排程）
    chain = []
    pending_chain_started = False
    video_tasks_pending = []

    for idx, vd in enumerate(videos):
        if not isinstance(vd, dict):
            failed.append({'video': idx, 'reason': '视频配置格式错误'})
            continue
        try:
            draft = {'id': idx, 'type': 'video', 'draft_data': vd}
            errs = validate_draft_for_publish(draft)
            if errs:
                failed.append({'video': idx, 'reason': '; '.join(errs)})
                continue

            common = vd.get('commonConfig') or {}
            platform_configs = vd.get('platformConfigs') or {}
            platform_overrides = vd.get('platformOverrides') or {}
            account_overrides = vd.get('accountOverrides') or {}
            publish_account_ids = vd.get('publishAccountIds') or []
            batch_id = str(uuid.uuid4())
            video_tasks_pending = []  # 本视频暂存的待排程任务（非链头时）

            for account_id in publish_account_ids:
                conn = sqlite3.connect(str(DB_PATH))
                conn.row_factory = sqlite3.Row
                acc_row = conn.execute(
                    "SELECT id, type, filePath, userName FROM user_info WHERE id = ?",
                    (account_id,),
                ).fetchone()
                conn.close()
                if not acc_row:
                    failed.append({'video': idx, 'reason': f'账号 {account_id} 不存在'})
                    continue

                account_platform = PLATFORM_ID_TO_KEY.get(acc_row['type'], '')
                platform_default = platform_configs.get(account_platform) or {}
                account_ov = account_overrides.get(str(account_id)) or {}

                merged = merge_config(
                    common, platform_default,
                    platform_overrides.get(account_platform),
                    account_ov,
                )

                # 逐账号补充校验（标题/描述长度、视频时长/大小）
                acc_errs = _validate_batch_account(account_platform, merged)
                if acc_errs:
                    failed.append({
                        'video': idx,
                        'reason': f'{acc_row["userName"] or account_id}({account_platform}): '
                                  + '; '.join(acc_errs),
                    })
                    continue

                account_obj = type('Account', (), {})()
                account_obj.id = acc_row['id']
                account_obj.platform = account_platform
                account_obj.file_path = acc_row['filePath']

                payload = build_platform_kwargs(merged, common, account_obj)

                ptype = KEY_TO_PLATFORM_ID.get(account_platform)
                if not ptype:
                    failed.append({'video': idx, 'reason': f'未知平台: {account_platform}'})
                    continue

                from storage import resolve_material_path
                raw_video = (payload.get('files') or [''])[0]
                resolved_video = resolve_material_path(raw_video) if raw_video else ''
                if not resolved_video:
                    failed.append({
                        'video': idx,
                        'reason': f'账号 {account_id} 视频文件不存在: {raw_video}',
                    })
                    continue

                task = PublishTask(
                    id=str(uuid.uuid4()),
                    batch_id=batch_id,
                    # platform 列存中文名(与 /postVideo 链路一致),发布历史按名匹配 logo
                    platform=PLATFORM_MAP.get(acc_row['type'], account_platform),
                    platform_type=ptype,
                    account_name=acc_row['userName'] or '',
                    account_cookie_path=acc_row['filePath'] or '',
                    video_path=resolved_video,
                    title=payload.get('title', ''),
                    description=payload.get('desc', ''),
                    thumbnail_path=payload.get('thumbnail_path', '') or '',
                    tags=payload.get('tags') or [],
                    # 媒体/定时个性化字段：写入 publish_details.account_configs，
                    # 发布历史据此还原封面/视频缩略图（否则历史卡片无封面）
                    video_landscape=merged.get('videoLandscape'),
                    video_portrait=merged.get('videoPortrait'),
                    cover_landscape=merged.get('coverLandscape'),
                    cover_portrait=merged.get('coverPortrait'),
                    enable_timer=payload.get('enableTimer'),
                    schedule_time=payload.get('schedule_time_str'),
                    ai_content=payload.get('ai_content'),
                    is_original=payload.get('is_original'),
                    source='batch',
                    account_id=account_id,
                    payload=payload,
                    # 批量发布:失败立即标记 FAILED,不自动重试(与草稿批量发布一致)
                    max_retries=0,
                    # 本次批量发布间隔（分钟）；worker 优先取该值再回退全局设置
                    batch_interval_minutes=batch_interval_minutes,
                )
                try:
                    # 发布链调度：链头视频立即入队；后续视频只写库（details=pending）
                    # 并暂存到 TaskQueue，等前驱视频完成后按间隔排程入队。
                    if not pending_chain_started:
                        task_queue.add_task(task)
                    else:
                        task_queue._insert_db(task)
                        video_tasks_pending.append(task)
                    task_ids.append(task.id)
                    if batch_id not in batch_ids:
                        batch_ids.append(batch_id)
                except Exception as e:
                    failed.append({'video': idx, 'reason': f'入队失败: {e}'})

            # 本视频有成功入队的任务 → 记入链；链头之后的视频暂存待排程
            if batch_id in batch_ids:
                if not pending_chain_started:
                    pending_chain_started = True  # 第一个有效视频已入队
                elif video_tasks_pending:
                    task_queue.add_pending_batch(batch_id, video_tasks_pending)
                chain.append(batch_id)
        except Exception as e:
            failed.append({'video': idx, 'reason': str(e)})

    # 写发布链：每个视频记录间隔 + 指向下一个视频（用户设计的链式调度）
    # 前驱视频全部任务终态后，_on_batch_maybe_finished 会把
    # next.scheduled_at 置为 完成时刻 + interval_minutes，调度器到点入队。
    if len(chain) > 1:
        try:
            with sqlite3.connect(str(DB_PATH)) as conn:
                for i, bid in enumerate(chain):
                    nxt = chain[i + 1] if i + 1 < len(chain) else ''
                    conn.execute(
                        "UPDATE publish_batches SET interval_minutes=?, next_batch_id=?,"
                        " updated_at=? WHERE id=?",
                        (batch_interval_minutes, nxt,
                         datetime.now().isoformat(), bid),
                    )
        except Exception as e:
            print(f"[videos/batch-publish] 写发布链失败: {e}")

    return jsonify({
        "code": 200,
        "data": {"task_ids": task_ids, "batch_ids": batch_ids, "failed": failed},
    }), 200


# ========== 视频草稿批量删除 ==========

@ext_api.route('/drafts/batch', methods=['DELETE'])
def batch_delete_drafts():
    """视频草稿批量删除。

    Body: {"draft_ids": [int, ...]}  (1-30 个草稿 id)
    Response 200: {"code": 200, "deleted": [...], "failed": [{draft_id, reason}, ...]}
    Response 400: draft_ids 缺失/非列表/为空/超过 30
    """
    from flask import request
    data = request.get_json() or {}
    draft_ids = data.get('draft_ids') or []
    if not isinstance(draft_ids, list) or not draft_ids or len(draft_ids) > 30:
        return jsonify({"code": 400, "msg": "draft_ids 数量必须 1-30"}), 400

    from app import _get_db_path
    db_path = _get_db_path()
    conn = sqlite3.connect(str(db_path))
    placeholders = ','.join('?' * len(draft_ids))

    existing = {r[0] for r in conn.execute(
        f"SELECT id FROM drafts WHERE id IN ({placeholders})", draft_ids
    ).fetchall()}

    deleted = []
    failed = []
    for did in draft_ids:
        if did in existing:
            try:
                conn.execute("DELETE FROM drafts WHERE id = ?", (did,))
                deleted.append(did)
            except Exception as e:
                failed.append({'draft_id': did, 'reason': str(e)})
        else:
            failed.append({'draft_id': did, 'reason': '草稿不存在'})

    conn.commit()
    conn.close()

    return jsonify({"code": 200, "deleted": deleted, "failed": failed}), 200


# ========== 测试用 Flask app ==========
# 测试代码（test_publish_templates.py）通过 `ext_api.app.test_request_context()` 推请求上下文调用
# 路由函数。这个独立 Flask app 让 Blueprint 可独立测试，不污染 backend/app.py 的主 app。
from flask import Flask
app = Flask(__name__)
app.register_blueprint(ext_api)


# ========== 解决 `import ext_api` 与 `import ext_api.__init__` 是不同模块对象的问题 ==========
# Python 在 `import ext_api` 时把 `__init__.py` 注册为 `sys.modules['ext_api']`，
# 但 `import ext_api.__init__` 会把同一个文件再注册为 `sys.modules['ext_api.__init__']`。
# 两个条目指向不同 module 对象，导致测试中 patch `_db_conn` 不生效（route 函数的
# __globals__ 仍指向 `ext_api`，而 patch 修改的是 `ext_api.__init__`）。
# 这里把 `ext_api.__init__` 重定向到 `ext_api`，让两种 import 路径拿到同一个对象。
import sys as _sys
_sys.modules.setdefault('ext_api.__init__', _sys.modules[__name__])

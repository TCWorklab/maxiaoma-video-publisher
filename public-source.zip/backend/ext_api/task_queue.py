"""
任务队列系统 - asyncio Queue + Worker 模式
支持并发控制、失败重试（指数退避）、进度追踪
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from conf import BASE_DIR
from util._logger import get_channel_logger
from impl.registry import get_platform

logger = get_channel_logger("task_queue")

DB_PATH = BASE_DIR / "db" / "database.db"

# 同步平台(publish_video 内部自己 asyncio.run)的执行线程池。
# 必须自持有 CF future:同步线程无法强杀,取消时要能等它自然收尾。
_SYNC_EXEC = ThreadPoolExecutor(max_workers=2, thread_name_prefix="sync-publish")


def _refresh_batch_status(conn, batch_id: str):
    """按 detail 行重算 batch 聚合状态(与 _update_db 内逻辑一致)。"""
    counts = conn.execute(
        """SELECT COUNT(*),
                  SUM(CASE WHEN status='success' THEN 1 ELSE 0 END),
                  SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END),
                  SUM(CASE WHEN status IN ('running', 'queued', 'waiting_auth', 'unknown') THEN 1 ELSE 0 END)
           FROM publish_details WHERE batch_id=?""",
        (batch_id,),
    ).fetchone()
    total, succ, fail, in_flight = counts[0], counts[1] or 0, counts[2] or 0, counts[3] or 0
    bs = aggregate_batch_status(succ=succ, fail=fail, in_flight=in_flight, total=total)
    now = datetime.now().isoformat()
    conn.execute(
        """UPDATE publish_batches
           SET status=?, success_count=?, failed_count=?, account_count=?,
               finished_at=COALESCE(finished_at, ?), updated_at=?
           WHERE id=?""",
        (bs, succ, fail, total, now, now, batch_id),
    )


def _cleanup_orphaned_tasks() -> int:
    """启动时清理孤儿任务:上次进程退出时仍卡在 running/queued 的行。

    这些任务随旧进程消亡:永远不会执行,内存里也不存在 → cancel_task
    找不到只能回 400「无法取消」,而 DB/前端会永远显示「排队中」。
    启动时统一落 cancelled + 中断说明,状态诚实可见。
    """
    now = datetime.now().isoformat()
    try:
        with sqlite3.connect(str(DB_PATH)) as conn:
            rows = conn.execute(
                "SELECT id, batch_id FROM publish_details"
                " WHERE status IN ('running', 'queued')"
            ).fetchall()
            if conn.execute("SELECT 1 FROM sqlite_master WHERE name='guarded_publications'").fetchone():
                managed_ids = {detail for record in conn.execute('SELECT details FROM guarded_publications')
                               for detail in json.loads(record[0])}
                rows = [row for row in rows if row[0] not in managed_ids]
            if not rows:
                return 0
            ids = [r[0] for r in rows]
            batch_ids = sorted({r[1] for r in rows if r[1]})
            ph = ",".join("?" * len(ids))
            conn.execute(
                f"UPDATE publish_details SET status='cancelled',"
                f" error_message='服务重启,任务已中断', finished_at=?"
                f" WHERE id IN ({ph})",
                (now, *ids),
            )
            for bid in batch_ids:
                _refresh_batch_status(conn, bid)
            logger.info(
                "[TaskQueue] 启动清理: %d 个孤儿任务(重启前残留 running/queued)已标记取消",
                len(ids),
            )
            return len(ids)
    except Exception as e:
        logger.info("[TaskQueue] 启动清理孤儿任务失败: %s", e)
        return 0

# 任务间隔设置缓存（settings.batchTaskInterval，分钟）。worker 每次取任务前读取，
# 30s 缓存避免频繁开 DB；异常一律回退 0（= 连续发布，与旧行为一致）。
_interval_cache = {"value": 0.0, "fetched_at": 0.0}


def _get_interval_minutes() -> float:
    now = time.time()
    if now - _interval_cache["fetched_at"] < 30:
        return _interval_cache["value"]
    try:
        with sqlite3.connect(str(DB_PATH)) as conn:
            row = conn.execute(
                "SELECT value FROM settings WHERE key = 'batchTaskInterval'"
            ).fetchone()
        val = float(row[0]) if row and row[0] not in (None, "") else 0.0
    except Exception:
        val = 0.0
    val = max(0.0, val)
    _interval_cache["value"] = val
    _interval_cache["fetched_at"] = now
    return val


def _friendly_error(exc: Exception) -> str:
    """把原始异常转成用户可读的错误信息。

    用户手动关闭浏览器时，未被页面级守卫捕获的 await 会抛 Playwright 原文
    （如 "Target page, context or browser has been closed"），展示给用户很困惑，
    这里统一归一化为「浏览器/页面已被用户关闭」。
    """
    msg = str(exc)
    low = msg.lower()
    if (
        "target page, context or browser has been closed" in low
        or "browser has been closed" in low
        or "target closed" in low
        or "execution context was destroyed" in low
    ):
        return "浏览器/页面已被用户关闭，发布中止"
    return msg


class TaskStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    WAITING_AUTH = "waiting_auth"
    UNKNOWN = "unknown"


def aggregate_batch_status(*, succ: int, fail: int, in_flight: int, total: int) -> str:
    """根据 detail 状态聚合 batch 状态。

    优先级：
      1. total == 0            -> 'pending'    （无 detail，理论不该发生）
      2. in_flight > 0         -> 'running'    （仍有 queued/running detail 未结束）
      3. fail == 0             -> 'success'    （全部成功）
      4. succ == 0             -> 'failed'     （全部失败）
      5. 其余                  -> 'partial'    （混合成功+失败）
    """
    if total == 0:
        return 'pending'
    if in_flight > 0:
        return 'running'
    if fail == 0:
        return 'success'
    if succ == 0:
        return 'failed'
    return 'partial'


@dataclass
class PublishTask:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    batch_id: str = ''                       # 新增
    platform: str = ""
    platform_type: int = 0  # 1=小红书 2=视频号 3=抖音 4=快手 5=B站
    account_name: str = ""
    account_cookie_path: str = ""
    video_path: str = ""
    title: str = ""
    description: str = ""
    thumbnail_path: str = ""
    tags: list = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    retry_count: int = 0
    max_retries: int = 3
    error_message: str = ""
    publish_url: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    started_at: Optional[str] = None
    finished_at: Optional[str] = None

    # 新增：个性化配置字段
    video_landscape: dict | None = None
    video_portrait: dict | None = None
    cover_landscape: dict | None = None
    cover_portrait: dict | None = None
    video_format: str | None = None
    enable_timer: int | None = None
    schedule_time: str | None = None
    ai_content: str | None = None
    is_original: bool | None = None

    # 草稿批量发布溯源字段（Task 10 扩展）
    source: str = ''                # '' | 'draft' | 'normal'
    draft_id: int = 0
    account_id: int = 0
    detail_id: str = ''            # publish_details.id
    payload: dict = field(default_factory=dict)

    # 本次批量发布的视频间隔（分钟）。仅本次批量生效，覆盖全局
    # settings.batchTaskInterval；None/0 表示不等待，立即开始下一个任务。
    # 不持久化（属于一次性执行参数）。
    batch_interval_minutes: float | None = None

    def to_dict(self):
        d = asdict(self)
        d['tags'] = json.dumps(self.tags, ensure_ascii=False)
        # payload 不持久化（仅 in-memory 透传），不写入 d
        return d

    @classmethod
    def from_row(cls, row_dict):
        """从数据库行构造"""
        tags = row_dict.get('tags', '[]')
        if isinstance(tags, str):
            try:
                tags = json.loads(tags)
            except json.JSONDecodeError:
                tags = []
        return cls(
            id=row_dict['id'],
            batch_id=row_dict.get('batch_id', ''),
            platform=row_dict['platform'],
            platform_type=row_dict.get('platform_type', 0),
            account_name=row_dict['account_name'],
            account_cookie_path=row_dict.get('account_cookie_path', ''),
            video_path=row_dict['video_path'],
            title=row_dict['title'],
            description=row_dict.get('description', ''),
            thumbnail_path=row_dict.get('thumbnail_path', ''),
            tags=tags,
            status=row_dict['status'],
            retry_count=row_dict.get('retry_count', 0),
            max_retries=row_dict.get('max_retries', 3),
            error_message=row_dict.get('error_message', ''),
            publish_url=row_dict.get('publish_url', ''),
            created_at=row_dict['created_at'],
            started_at=row_dict.get('started_at'),
            finished_at=row_dict.get('finished_at'),
            source=row_dict.get('source', ''),
            draft_id=row_dict.get('draft_id', 0),
            account_id=row_dict.get('account_id', 0),
            detail_id=row_dict.get('detail_id', ''),
        )


def _build_account_configs(task: 'PublishTask') -> dict:
    """构造写入 publish_details.account_configs 的 dict。
    含全 per-platform form 字段，让历史卡片能完整还原发布时的内容。"""
    return {
        'title': task.title,
        'description': task.description,
        'tags': task.tags,
        'thumbnail_path': task.thumbnail_path,
        'platform_type': task.platform_type,
        'videoLandscape': task.video_landscape,
        'videoPortrait': task.video_portrait,
        'coverLandscape': task.cover_landscape,
        'coverPortrait': task.cover_portrait,
        'videoFormat': task.video_format,
        'enableTimer': task.enable_timer,
        'scheduleTime': task.schedule_time,
        'aiContent': task.ai_content,
        'isOriginal': task.is_original,
    }


class TaskQueue:
    """基于 asyncio 的任务队列，在后台线程中运行"""

    def __init__(self, max_concurrent: int = 2):
        self.queue: asyncio.Queue = None
        self.running: dict[str, PublishTask] = {}
        self.completed: list[PublishTask] = []
        self.max_concurrent = max_concurrent
        self._workers: list[asyncio.Task] = []
        self._loop: asyncio.AbstractEventLoop = None
        self._thread: threading.Thread = None
        self._started = False
        self._status_callbacks = []  # 状态变更回调
        # ===== 发布链调度（DB 驱动，用户设计）=====
        # 提交批量发布时：只有链头视频的任务立即入队；后续视频的任务暂存于
        # pending_batches，等前驱视频全部完成后按间隔排程（写 scheduled_at），
        # 由 _scheduler_loop 轮询到点入队执行。
        self._pending_batches: dict[str, list[PublishTask]] = {}
        self._pending_lock = threading.Lock()
        self._scheduler_thread: threading.Thread = None
        # 全局间隔回退（settings.batchTaskInterval，任务未带 batch_interval_minutes
        # 时使用，如草稿批量）：batch_id → 最近完成时刻，worker 开始前分段等待。
        self._batch_last_finished: dict[str, float] = {}
        # 取消支持：running 的 asyncio task 句柄 / 队列中待取消的 id / 已取消集合
        self._running_tasks: dict[str, asyncio.Task] = {}
        self._queued_ids: set[str] = set()
        self._cancelled_ids: set[str] = set()
        self._cancel_lock = threading.Lock()

    def start(self):
        """在后台线程中启动事件循环"""
        if self._started:
            return
        # 先清掉上次进程遗留的孤儿任务,避免前端永远显示「排队中」且无法取消
        _cleanup_orphaned_tasks()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        # 发布链调度轮询：到点的待发布视频入队执行
        self._scheduler_thread = threading.Thread(
            target=self._scheduler_loop, daemon=True, name="interval-scheduler"
        )
        self._scheduler_thread.start()
        self._started = True
        logger.info(f"[TaskQueue] 启动，并发数={self.max_concurrent}")

    # ===== 发布链调度（DB 驱动）=====

    def add_pending_batch(self, batch_id: str, tasks: list) -> None:
        """暂存一个待排程视频的任务（由 videos/batch-publish 路由调用）。"""
        for task in tasks:
            self._prepare_managed_task(task)
        with self._pending_lock:
            self._pending_batches[batch_id] = list(tasks)

    def cancel_pending_batch(self, batch_id: str) -> bool:
        """取消一个尚未排程入队的待发布视频：内存任务全部标记取消并落库。"""
        with self._pending_lock:
            tasks = self._pending_batches.pop(batch_id, None)
        if not tasks:
            return False
        now = datetime.now().isoformat()
        for t in tasks:
            self._cancel_managed_task(t)
            t.status = TaskStatus.CANCELLED
            t.error_message = "用户取消发布"
            t.finished_at = now
            self.completed.append(t)
            self._update_db(t)
            self._notify_status(t)
        self._finish_batch_row(batch_id, 'cancelled')
        logger.info("[TaskQueue] 待发布视频 %s 已取消（未入队直接落 cancelled）", batch_id)
        return True

    def _finish_batch_row(self, batch_id: str, status: str) -> None:
        try:
            with sqlite3.connect(str(DB_PATH)) as conn:
                conn.execute(
                    "UPDATE publish_batches SET status=?, finished_at=?, updated_at=?"
                    " WHERE id=?",
                    (status, datetime.now().isoformat(),
                     datetime.now().isoformat(), batch_id),
                )
        except Exception as e:
            logger.info("[TaskQueue] 更新批次 %s 状态失败: %s", batch_id, e)

    def _on_batch_maybe_finished(self, task: PublishTask) -> None:
        """task 落终态后调用：若所属视频（batch）全部终态且有后继，按间隔排程下一个。

        用户设计的链式规则：
          本视频全部账号任务完成（无论成功/失败/取消）→ 读取 interval_minutes
          和 next_batch_id → UPDATE 下一个视频 scheduled_at = now + interval。
        interval=0 时直接置 now（立即可被调度器入队）。
        """
        try:
            with sqlite3.connect(str(DB_PATH)) as conn:
                row = conn.execute(
                    "SELECT interval_minutes, next_batch_id FROM publish_batches"
                    " WHERE id=?",
                    (task.batch_id,),
                ).fetchone()
                if not row or not row[1]:
                    return
                interval_min, next_id = float(row[0] or 0), row[1]
                # 本视频是否全部终态（queued/running 视为未完成）
                unfinished = conn.execute(
                    "SELECT COUNT(*) FROM publish_details"
                    " WHERE batch_id=? AND status IN ('pending','queued','running','waiting_auth','unknown')",
                    (task.batch_id,),
                ).fetchone()[0]
                if unfinished > 0:
                    return
                # 排程下一个视频：仅当它还在等待（pending 且未排程），保证只排一次
                due = datetime.now() + timedelta(minutes=interval_min)
                cur = conn.execute(
                    "UPDATE publish_batches SET scheduled_at=?, updated_at=?"
                    " WHERE id=? AND status='pending' AND scheduled_at=''",
                    (due.isoformat(), datetime.now().isoformat(), next_id),
                )
                if cur.rowcount > 0:
                    logger.info(
                        "[TaskQueue] 视频 %s 已完成，下一个视频 %s 排程于 %s（间隔 %.1f 分钟）",
                        task.batch_id, next_id, due.strftime('%H:%M:%S'), interval_min,
                    )
        except Exception as e:
            logger.info("[TaskQueue] 排程下一个视频失败(%s): %s", task.batch_id, e)

    def _scheduler_loop(self):
        """轮询 DB：预定发布时间已到的待发布视频 → 任务入队执行。"""
        while True:
            time.sleep(2.0)
            self._scheduler_tick()

    def _scheduler_tick(self):
        """调度一轮：到点的待发布视频入队；断链（重启丢暂存）标 failed 提示重发。"""
        try:
            now_iso = datetime.now().isoformat()
            with sqlite3.connect(str(DB_PATH)) as conn:
                rows = conn.execute(
                    "SELECT id FROM publish_batches"
                    " WHERE status='pending' AND scheduled_at != ''"
                    " AND scheduled_at <= ? ORDER BY scheduled_at LIMIT 10",
                    (now_iso,),
                ).fetchall()
            for (bid,) in rows:
                with self._pending_lock:
                    tasks = self._pending_batches.pop(bid, None)
                if not tasks:
                    # 重启断链：暂存任务丢失，无法继续发布，明确标记让用户重发
                    self._finish_batch_row(bid, 'failed')
                    with sqlite3.connect(str(DB_PATH)) as conn:
                        conn.execute(
                            "UPDATE publish_details SET status='failed',"
                            " error_message='服务重启导致发布链中断，请重新发布',"
                            " finished_at=? WHERE batch_id=? AND status='pending'",
                            (datetime.now().isoformat(), bid),
                        )
                    logger.info("[TaskQueue] 待发布视频 %s 因重启断链标记失败", bid)
                    continue
                logger.info("[TaskQueue] 视频间隔到达，视频 %s 开始发布（%d 个任务）",
                            bid, len(tasks))
                for t in tasks:
                    self.add_task(t)
        except Exception as e:
            logger.info("[TaskQueue] 调度轮询异常: %s", e)

    def _run_loop(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self.queue = asyncio.Queue()
        for i in range(self.max_concurrent):
            self._loop.create_task(self._worker(f"worker-{i}"))
        self._loop.run_forever()

    async def _wait_batch_interval(self, task: PublishTask, interval_min: float) -> None:
        """等待本批次的发布间隔（可被取消打断）。

        语义：本批次上一个 task 完成后需间隔 interval_min 分钟才能开始下一个。
        分段 sleep（每段 ≤1s）并在每段之间检查 task 是否已被用户取消，
        取消则立即返回（后续的出队取消检查会把它落成 cancelled）。
        第一个 task（本批次无完成记录）不等待，立即执行。
        """
        last_fin = self._batch_last_finished.get(task.batch_id)
        if last_fin is None:
            return
        target = last_fin + interval_min * 60
        while True:
            remaining = target - time.time()
            if remaining <= 0:
                return
            with self._cancel_lock:
                if task.id in self._cancelled_ids:
                    return  # 已取消，跳过等待走取消分支
            await asyncio.sleep(min(remaining, 1.0))

    async def _worker(self, name: str):
        while True:
            task = await self.queue.get()
            self._queued_ids.discard(task.id)
            # 任务间隔（分钟）：
            # - 任务级 batch_interval_minutes（发布页视频间隔）：不在 worker 等待，
            #   由 DB 发布链调度（前驱视频完成后写 next.scheduled_at，调度器到点入队）。
            # - 未带（如草稿批量发布）：回退全局 settings.batchTaskInterval，
            #   worker 开始前按批次完成记录分段等待。
            chain_mode = task.batch_interval_minutes is not None
            if chain_mode:
                interval_min = max(0.0, float(task.batch_interval_minutes))
            else:
                interval_min = _get_interval_minutes()
                if interval_min > 0:
                    await self._wait_batch_interval(task, interval_min)

            # 用户取消：出队前被标记取消 → 直接落 cancelled（不执行）
            with self._cancel_lock:
                was_cancelled = task.id in self._cancelled_ids
                if was_cancelled:
                    self._cancelled_ids.discard(task.id)
            if was_cancelled:
                self._cancel_managed_task(task)
                task.status = TaskStatus.CANCELLED
                task.error_message = "用户取消发布"
                task.finished_at = datetime.now().isoformat()
                self.completed.append(task)
                self._update_db(task)
                self._notify_status(task)
                if chain_mode:
                    # 排队中取消也可能是视频的最后一个任务：同样检查是否该排程下一个
                    self._on_batch_maybe_finished(task)
                self.queue.task_done()
                continue

            task.status = TaskStatus.RUNNING
            task.started_at = datetime.now().isoformat()
            self.running[task.id] = task
            self._running_tasks[task.id] = asyncio.current_task()
            self._update_db(task)
            self._notify_status(task)

            cancelled_by_user = False
            try:
                await self._execute(task)
                task.status = TaskStatus.SUCCESS
            except asyncio.CancelledError:
                logger.info(
                    "[TaskQueue] 任务取消完成: %s (%s)", task.id, task.platform
                )
                task.status = TaskStatus.CANCELLED
                task.error_message = "用户取消发布"
                if task.payload.get('_guard_id'):
                    from services.publication_guard import job as guarded_job
                    record = guarded_job(task.payload['_guard_id'])
                    if record and record['state'] == 'unknown':
                        task.status = TaskStatus.UNKNOWN
                        task.error_message = record['message']
                    else:
                        self._cancel_managed_task(task)
                cancelled_by_user = True
                # 同步平台（如微博）在 executor 线程里跑，无法强杀，要等线程自然
                # 收尾（_execute 里 while not cf.done(): await sleep）。但这段时间
                # 任务在 DB 里仍是 running，前端看不到 cancel 信号，会以为「点了
                # 没反应」。这里先把状态写库 + 推 SSE，让前端立刻看到 cancelled。
                task.started_at = task.started_at or datetime.now().isoformat()
                task.finished_at = datetime.now().isoformat()
                self._update_db(task)
                self._notify_status(task)
            except Exception as e:
                # 重试逻辑已禁用 — 长耗时任务(如视频上传)失败立即标记 FAILED,
                # 避免误触发「同一任务再次开浏览器重新上传」
                from services.publication_guard import PublishDeferred, job as guarded_job
                if isinstance(e, PublishDeferred):
                    held = guarded_job(e.job_id)
                    task.status = TaskStatus.UNKNOWN if held and held['state'] == 'unknown' else TaskStatus.WAITING_AUTH
                else:
                    task.status = TaskStatus.FAILED
                task.error_message = _friendly_error(e)

            finally:
                task.finished_at = datetime.now().isoformat()
                if task.id in self.running:
                    del self.running[task.id]
                self._running_tasks.pop(task.id, None)
                if not cancelled_by_user:
                    # 正常完成/失败：进 completed 列表 + 写库 + 推 SSE。
                    self.completed.append(task)
                    self._update_db(task)
                    self._notify_status(task)
                    if not chain_mode and interval_min > 0:
                        # 全局间隔回退路径：记录批次完成时刻（下一个 task 据此等待）
                        self._batch_last_finished[task.batch_id] = time.time()
                else:
                    # 用户取消：上面已经写过库/推过 SSE；不进 completed（重试会
                    # 用到），也不更新批次完成时刻 —— 取消不该让后续 task 白等间隔。
                    self._update_db(task)
                if chain_mode:
                    # 发布链调度：本视频（batch）全部账号任务终态后，
                    # 按间隔排程下一个视频（写 next.scheduled_at，调度器到点入队）。
                    self._on_batch_maybe_finished(task)
                self.queue.task_done()

    async def _execute(self, task: PublishTask):
        """调用上游 uploader 执行上传。

        新逻辑：当 task.payload 非空时，调 platform.publish_video(**payload)（splat）。
        旧逻辑（task.payload 为空时）：保留原 myUtils.postVideo 模块函数调用（向后兼容）。
        """
        # 新逻辑：payload 透传到 platform.publish_video
        if task.payload:
            platform = get_platform(task.platform_type)
            if not platform:
                raise ValueError(f"不支持的平台类型: {task.platform_type}")
            publish_fn = platform.publish_video
            if task.platform_type in (1, 2, 3):
                from services.publication_guard import prepare
                if '_guard_id' not in task.payload:
                    task.payload['_guard_id'] = prepare(task.platform_type, 'publish_video', task.payload,
                                                       [task.detail_id or task.id])
            if asyncio.iscoroutinefunction(publish_fn):
                return await publish_fn(**task.payload)
            loop = asyncio.get_event_loop()
            cf = _SYNC_EXEC.submit(lambda: publish_fn(**task.payload))
            try:
                return await asyncio.wrap_future(cf)
            except asyncio.CancelledError:
                # 同步平台跑在独立线程里,无法强杀:取消只是不再等它。
                # 必须等该线程自然收尾后再放行 worker —— 否则 worker 立刻
                # 取下一个任务开浏览器,多次取消会变成「所有平台浏览器同时
                # 发布」。收尾期间不再启动任何新任务。
                logger.info(
                    "[TaskQueue] 任务 %s (%s) 已取消,等待其发布线程收尾(收尾前不启动后续任务)...",
                    task.id, task.platform,
                )
                while not cf.done():
                    await asyncio.sleep(0.5)
                logger.info("[TaskQueue] 任务 %s 发布线程已收尾", task.id)
                raise

        if task.platform_type in (1, 2, 3):
            task.payload = dict(title=task.title, files=[task.video_path], tags=task.tags,
                                account_file=[task.account_cookie_path], desc=task.description,
                                thumbnail_path=task.thumbnail_path)
            return await self._execute(task)

        # 旧逻辑：保留原代码不动
        from myUtils.postVideo import (
            post_video_DouYin, post_video_ks,
            post_video_tencent, post_video_xhs,
            post_video_bilibili
        )

        file_list = [task.video_path]
        account_list = [task.account_cookie_path]
        tags = task.tags
        title = task.title
        thumbnail_path = task.thumbnail_path
        desc = task.description

        # 在 executor 中运行同步的上传函数
        loop = asyncio.get_event_loop()
        match task.platform_type:
            case 1:
                await loop.run_in_executor(
                    None, lambda: post_video_xhs(
                        title, file_list, tags, account_list, None, 0, 1, ['10:00'], 0,
                        thumbnail_path=thumbnail_path, desc=desc
                    )
                )
            case 2:
                await loop.run_in_executor(
                    None, lambda: post_video_tencent(
                        title, file_list, tags, account_list, None, 0, 1, ['10:00'], 0, False,
                        thumbnail_path=thumbnail_path, desc=desc
                    )
                )
            case 3:
                await loop.run_in_executor(
                    None, lambda: post_video_DouYin(
                        title, file_list, tags, account_list, None, 0, 1, ['10:00'], 0,
                        thumbnail_landscape_path='', thumbnail_portrait_path=thumbnail_path,
                        productLink='', productTitle='', desc=desc
                    )
                )
            case 4:
                await loop.run_in_executor(
                    None, lambda: post_video_ks(
                        title, file_list, tags, account_list, None, 0, 1, ['10:00'], 0,
                        thumbnail_path=thumbnail_path, desc=desc
                    )
                )
            case 5:
                await loop.run_in_executor(
                    None, lambda: post_video_bilibili(
                        title, file_list, tags, account_list, None, 0, 1, ['10:00'], 0,
                        desc=desc
                    )
                )
            case _:
                raise ValueError(f"不支持的平台类型: {task.platform_type}")

    @staticmethod
    def _prepare_managed_task(task):
        if task.platform_type not in (1, 2, 3) or task.payload.get('_guard_id'):
            return
        from services.publication_guard import prepare
        if not task.payload:
            task.payload = dict(title=task.title, files=[task.video_path], tags=task.tags,
                                account_file=[task.account_cookie_path], desc=task.description,
                                thumbnail_path=task.thumbnail_path)
        task.payload['_guard_id'] = prepare(task.platform_type, 'publish_video', task.payload,
                                           [task.detail_id or task.id])

    @staticmethod
    def _cancel_managed_task(task):
        if task.payload.get('_guard_id'):
            from services import session_store
            with session_store.connect() as db:
                db.execute("UPDATE guarded_publications SET state='cancelled',message='用户取消尚未执行的任务' WHERE id=? AND state IN ('pending','ready','waiting')",
                           (task.payload['_guard_id'],))

    def add_task(self, task: PublishTask):
        """线程安全地添加任务到队列"""
        if not self._started:
            self.start()
        task.status = TaskStatus.QUEUED
        self._insert_db(task)
        self._prepare_managed_task(task)
        self._queued_ids.add(task.id)
        asyncio.run_coroutine_threadsafe(self.queue.put(task), self._loop)
        logger.info(f"[TaskQueue] 任务已入队: {task.id} ({task.platform}/{task.account_name})")

    def cancel_task(self, task_id: str) -> bool:
        """取消任务：支持 running / queued / 待排程（发布链暂存）/ 孤儿任务。

        - queued（还在队列里）：标记取消，worker 出队时直接落 cancelled；
        - running：cancel 对应 asyncio task → worker 捕获 CancelledError 落 cancelled；
        - 待排程（发布链 _pending_batches 里，视频间隔还没到）：取消整个视频；
        - 已完成的任务不可取消，返回 False。
        """
        with self._cancel_lock:
            if task_id in self.running:
                if task_id in self._cancelled_ids:
                    # 已在取消流程中(同步平台正在等线程收尾):不重复 cancel,
                    # 否则会打断收尾等待,worker 提前放行 → 并发开浏览器
                    return True
                self._cancelled_ids.add(task_id)
                at = self._running_tasks.get(task_id)
                if at is not None and not at.done():
                    self._loop.call_soon_threadsafe(at.cancel)
                return True
            if task_id in self._queued_ids or task_id in self._cancelled_ids:
                self._cancelled_ids.add(task_id)
                return True
        # 发布链待排程：task 还没入队（前驱视频的间隔没到）→ 取消整个待发布视频。
        # 注意：只在锁内查 batch_id，取消动作放锁外（cancel_pending_batch 自己
        # 也要拿 _pending_lock，threading.Lock 不可重入，锁内直调会死锁）。
        pending_bid = None
        with self._pending_lock:
            for bid, tasks in self._pending_batches.items():
                if any(t.id == task_id for t in tasks):
                    pending_bid = bid
                    break
        if pending_bid is not None:
            return self.cancel_pending_batch(pending_bid)
        # 内存里找不到:可能是服务重启后 DB 残留的孤儿任务(永远不会执行),
        # 直接在 DB 落 cancelled —— 否则前端永远「排队中」且取消报 400
        return self._cancel_orphan_in_db(task_id)

    def _cancel_orphan_in_db(self, task_id: str) -> bool:
        """孤儿任务兜底取消:DB 里仍是 running/queued/pending 但内存无此任务。"""
        now = datetime.now().isoformat()
        try:
            with sqlite3.connect(str(DB_PATH)) as conn:
                row = conn.execute(
                    "SELECT batch_id FROM publish_details"
                    " WHERE id=? AND status IN ('running', 'queued', 'pending')",
                    (task_id,),
                ).fetchone()
                if not row:
                    return False
                conn.execute(
                    "UPDATE publish_details SET status='cancelled',"
                    " error_message='任务已失效(服务重启),现已取消', finished_at=?"
                    " WHERE id=?",
                    (now, task_id),
                )
                if row[0]:
                    _refresh_batch_status(conn, row[0])
            logger.info("[TaskQueue] 孤儿任务 %s 已在 DB 直接标记取消", task_id)
            return True
        except Exception as e:
            logger.info("[TaskQueue] 取消孤儿任务 %s 失败: %s", task_id, e)
            return False

    def retry_task(self, task_id: str) -> bool:
        """重试失败的任务"""
        for task in list(self.completed):
            if task.id == task_id and task.status == TaskStatus.FAILED:
                task.retry_count = 0
                task.error_message = ""
                task.status = TaskStatus.QUEUED
                self.completed.remove(task)
                asyncio.run_coroutine_threadsafe(self.queue.put(task), self._loop)
                self._update_db(task)
                return True
        return False

    def get_status(self) -> dict:
        """获取队列状态"""
        pending = self.queue.qsize() if self.queue else 0
        running_tasks = [
            {"id": t.id, "platform": t.platform, "account": t.account_name, "title": t.title}
            for t in self.running.values()
        ]
        return {
            "pending": pending,
            "running": len(self.running),
            "completed": len(self.completed),
            "running_tasks": running_tasks,
        }

    def on_status_change(self, callback):
        """注册状态变更回调"""
        self._status_callbacks.append(callback)

    def _notify_status(self, task: PublishTask):
        for cb in self._status_callbacks:
            try:
                cb(task)
            except Exception as e:
                logger.info(f"[TaskQueue] 回调错误: {e}")

    # ========== 数据库操作 ==========

    def _insert_db(self, task: PublishTask):
        """插 1 行 publish_batches（如果不存在）+ 1 行 publish_details"""
        try:
            with sqlite3.connect(str(DB_PATH)) as conn:
                # 素材 dict → id（cover 可能是抽帧封面，不在 materials 表，id 仅为溯源）
                def _mat_id(m):
                    return m.get('id', '') if isinstance(m, dict) else ''
                video_mat_id = _mat_id(task.video_landscape) or _mat_id(task.video_portrait)
                cover_l_id = _mat_id(task.cover_landscape)
                cover_p_id = _mat_id(task.cover_portrait)
                # batch 插一次，多次同 batch_id 跳过
                # 草稿批量发布时填 source='draft' + draft_id 溯源到草稿
                conn.execute(
                    """INSERT OR IGNORE INTO publish_batches
                       (id, type, title, description, video_material_id,
                        landscape_cover_material_id, portrait_cover_material_id,
                        account_count, status, created_at, updated_at,
                        source, draft_id)
                       VALUES (?, 'video', ?, ?, ?, ?, ?, 0, 'pending', ?, ?,
                               ?, ?)""",
                    (task.batch_id or task.id, task.title, task.description,
                     video_mat_id, cover_l_id, cover_p_id,
                     task.created_at, task.created_at,
                     task.source or '', task.draft_id or 0)
                )
                # 同 batch 后续任务带上了素材 ID 而首任务没有时补写（INSERT OR IGNORE 跳过行）
                conn.execute(
                    """UPDATE publish_batches
                       SET video_material_id=?, landscape_cover_material_id=?, portrait_cover_material_id=?
                       WHERE id=? AND COALESCE(landscape_cover_material_id, '')=''
                         AND COALESCE(portrait_cover_material_id, '')=''""",
                    (video_mat_id, cover_l_id, cover_p_id, task.batch_id or task.id)
                )
                # account_configs：把 task 字段打包成 JSON
                cfg = _build_account_configs(task)
                conn.execute(
                    """INSERT INTO publish_details
                       (id, batch_id, account_id, account_name, platform, account_configs,
                        status, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (task.id, task.batch_id or task.id, task.account_id or None,
                     task.account_name, task.platform,
                     json.dumps(cfg, ensure_ascii=False), task.status, task.created_at)
                )
        except Exception as e:
            logger.info(f"[TaskQueue] 插入数据库失败: {e}")

    def _update_db(self, task: PublishTask):
        """更新 1 行 publish_details + 聚合 publish_batches 状态"""
        try:
            with sqlite3.connect(str(DB_PATH)) as conn:
                conn.execute(
                    """UPDATE publish_details
                       SET status=?, retry_count=?, error_message=?, publish_url=?,
                           started_at=?, finished_at=?
                       WHERE id=?""",
                    (task.status, task.retry_count, task.error_message, task.publish_url,
                     task.started_at, task.finished_at, task.id)
                )
                # 聚合
                row = conn.execute(
                    "SELECT batch_id FROM publish_details WHERE id=?", (task.id,)
                ).fetchone()
                if not row: return
                batch_id = row[0]
                counts = conn.execute(
                    """SELECT COUNT(*),
                              SUM(CASE WHEN status='success' THEN 1 ELSE 0 END),
                              SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END),
                              SUM(CASE WHEN status IN ('running', 'queued', 'waiting_auth', 'unknown') THEN 1 ELSE 0 END)
                       FROM publish_details WHERE batch_id=?""",
                    (batch_id,)
                ).fetchone()
                total, succ, fail, in_flight = counts[0], counts[1] or 0, counts[2] or 0, counts[3] or 0
                bs = aggregate_batch_status(succ=succ, fail=fail, in_flight=in_flight, total=total)
                detail_states = {r[0] for r in conn.execute('SELECT status FROM publish_details WHERE batch_id=?', (batch_id,))}
                if 'unknown' in detail_states:
                    bs = 'unknown'
                elif 'waiting_auth' in detail_states:
                    bs = 'waiting_auth'
                now = datetime.now().isoformat()
                conn.execute(
                    """UPDATE publish_batches
                       SET status=?, success_count=?, failed_count=?, account_count=?,
                           finished_at=?, updated_at=?
                       WHERE id=?""",
                    (bs, succ, fail, total, task.finished_at or now, now, batch_id)
                )
        except Exception as e:
            logger.info(f"[TaskQueue] 更新数据库失败: {e}")


# 全局单例
# 并发数=1：严格串行执行（一个任务（=一个视频×一个账号）发布完才轮到下一个），
# 避免多浏览器并发发布触发平台风控；配合 settings.batchTaskInterval 还能在任务间加等待。
task_queue = TaskQueue(max_concurrent=1)

# 进程启动即清理孤儿任务(不等第一次 add_task,前端进度弹窗才能立刻看到真实状态)
_cleanup_orphaned_tasks()


def get_task_queue() -> TaskQueue:
    return task_queue

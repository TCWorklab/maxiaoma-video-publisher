"""douyin platform implementation."""

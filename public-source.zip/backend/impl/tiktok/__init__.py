"""tiktok platform implementation."""

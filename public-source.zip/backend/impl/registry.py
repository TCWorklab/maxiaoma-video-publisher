"""Platform registry and factory."""

from __future__ import annotations

from util._logger import get_channel_logger

from .base_platform import BasePlatform

logger = get_channel_logger("registry")

_registry: dict[int, type[BasePlatform]] = {}


def register(platform_id: int, cls: type[BasePlatform]) -> None:
    """Register a platform implementation under *platform_id*."""
    _registry[platform_id] = cls


def get_platform(platform_id: int) -> BasePlatform | None:
    """Return an *instance* of the registered platform, or *None*."""
    cls = _registry.get(platform_id)
    return cls() if cls is not None else None


def get_platform_by_key(key: str) -> BasePlatform | None:
    """Return an *instance* of the platform matching *key*, or *None*."""
    for cls in _registry.values():
        if cls.platform_key == key:
            return cls()
    return None


def is_supported(platform_id: int) -> bool:
    """Return True if *platform_id* has a registered implementation."""
    return platform_id in _registry


def iter_platforms() -> list[dict]:
    """枚举已注册平台（按 id 升序），供 /api/v2/platforms 等自描述端点使用。

    新平台在 _populate_registry 注册后即自动出现在枚举结果中，
    无需改动任何调用方（MCP 据此自动识别新平台）。
    """
    return [
        {
            "platform_id": pid,
            "platform_key": getattr(cls, "platform_key", "") or "",
            "platform_name": getattr(cls, "platform_name", "") or "",
        }
        for pid, cls in sorted(_registry.items())
    ]


# ---------------------------------------------------------------------------
# Populate registry -- late imports so modules can be added incrementally.
# ---------------------------------------------------------------------------

def _populate_registry() -> None:
    imports = [
        (1, ".xiaohongshu.platform", "XiaohongshuPlatform"),
        (2, ".channels.platform", "ChannelsPlatform"),
        (3, ".douyin.platform", "DouyinPlatform"),
        (4, ".kuaishou.platform", "KuaishouPlatform"),
        (5, ".bilibili.platform", "BilibiliPlatform"),
        (6, ".baijiahao.platform", "BaijiahaoPlatform"),
        (7, ".tiktok.platform", "TiktokPlatform"),
        (8, ".youtube.platform", "YoutubePlatform"),
        (9, ".tencent_video.platform", "TencentVideoPlatform"),
        (10, ".iqiyi.platform", "IqiyiPlatform"),
        (11, ".weibo.platform", "WeiboPlatform"),
        (12, ".alipay.platform", "AlipayPlatform"),
        (13, ".toutiao.platform", "ToutiaoPlatform"),
        (14, ".zhihu.platform", "ZhihuPlatform"),
        (15, ".csdn.platform", "CsdnPlatform"),
        (16, ".vivo.platform", "VivoPlatform"),
        (17, ".weixin_gzh.platform", "WeixinGzhPlatform"),
        (18, ".taobao_guanghe.platform", "TaobaoGuanghePlatform"),
        (19, ".jingmai.platform", "JingmaiPlatform"),
        # jd (platform_id=20) 不单独注册 — jingmai 与 jd 是同一个产品(dr.jd.com/jm/),
        # jingmai 平台的 publish_video 委托给 jd/platform.py 的 JdPlatform 实现。
        (21, ".dayu.platform", "DayuPlatform"),
    ]

    import importlib

    for pid, mod_path, cls_name in imports:
        try:
            mod = importlib.import_module(mod_path, package=__package__)
            cls = getattr(mod, cls_name)
            register(pid, cls)
        except (ImportError, AttributeError) as e:
            logger.warning("Platform %d (%s) skipped: %s", pid, mod_path, e)


_populate_registry()

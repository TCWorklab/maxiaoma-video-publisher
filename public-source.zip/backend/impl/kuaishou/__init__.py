"""kuaishou platform implementation."""

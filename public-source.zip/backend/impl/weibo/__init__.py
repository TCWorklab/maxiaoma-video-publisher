"""Weibo platform package."""

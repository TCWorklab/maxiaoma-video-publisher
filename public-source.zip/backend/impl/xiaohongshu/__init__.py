"""xiaohongshu platform implementation."""
